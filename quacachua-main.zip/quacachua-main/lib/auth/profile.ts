import type { User } from '@supabase/supabase-js'
import { normalizeGmail } from '@/lib/email/normalize'
import { generateSecureToken } from '@/lib/tokens/crypto'
import type { createAdminClient } from '@/lib/supabase/server'

export type PendingRegistrationData = {
  canonical: string
  referrerId: string | null
  displayName?: string
  username?: string
  ip?: string
  deviceId?: string
  browserId?: string
}

type SupabaseAdmin = ReturnType<typeof createAdminClient>

function normalizeProfileUsername(value: string | null | undefined, fallback: string) {
  const normalized = (value || fallback)
    .trim()
    .toLowerCase()
    .replace(/^@+/, '')
    .replace(/[^a-z0-9_]/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 24)

  if (normalized.length >= 3) return normalized
  return `${normalized || 'user'}_${fallback.slice(0, 6)}`.slice(0, 24)
}

function getEmailLocalPart(email: string | undefined) {
  return email?.split('@')[0] || ''
}

function getUserMeta(user: User) {
  return (user.user_metadata || {}) as Record<string, unknown>
}

function getMetaString(meta: Record<string, unknown>, key: string) {
  const value = meta[key]
  return typeof value === 'string' && value.trim() ? value.trim() : null
}

function generateReferralCode() {
  return generateSecureToken(8).substring(0, 12).toUpperCase()
}

async function resolveUniqueUsername(supabaseAdmin: SupabaseAdmin, requested: string, userId: string) {
  const base = normalizeProfileUsername(requested, userId.replace(/-/g, ''))
  const candidates = [
    base,
    `${base}_${userId.slice(0, 4)}`.slice(0, 24),
    `${base}_${generateSecureToken(2).toLowerCase()}`.slice(0, 24),
  ]

  for (const candidate of candidates) {
    const { data } = await supabaseAdmin
      .from('profiles')
      .select('id')
      .ilike('username', candidate)
      .maybeSingle()

    if (!data || data.id === userId) return candidate
  }

  return `user_${userId.replace(/-/g, '').slice(0, 18)}`
}

export async function ensureUserProfile(
  supabaseAdmin: SupabaseAdmin,
  user: User,
  pendingData?: PendingRegistrationData | null
) {
  const { data: existingProfile, error: existingError } = await supabaseAdmin
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .maybeSingle()

  if (existingError) {
    return { profile: null, created: false, error: existingError, code: 'lookup_failed' as const }
  }

  if (existingProfile) {
    return { profile: existingProfile, created: false, error: null, code: null }
  }

  const meta = getUserMeta(user)
  const canonical =
    pendingData?.canonical ||
    getMetaString(meta, 'registration_email_canonical') ||
    normalizeGmail(user.email || '') ||
    user.email ||
    ''

  if (!canonical) {
    return { profile: null, created: false, error: new Error('Missing canonical email'), code: 'missing_email' as const }
  }

  const requestedUsername =
    pendingData?.username ||
    getMetaString(meta, 'registration_username') ||
    getEmailLocalPart(user.email) ||
    `${user.id.slice(0, 8)}user`

  const username = await resolveUniqueUsername(supabaseAdmin, requestedUsername, user.id)
  const displayName =
    pendingData?.displayName ||
    getMetaString(meta, 'registration_display_name') ||
    username ||
    'Thanh vien moi'
  let referrerId = pendingData?.referrerId || getMetaString(meta, 'registration_referrer_id')

  for (let attempt = 0; attempt < 6; attempt++) {
    const { data: profile, error } = await supabaseAdmin
      .from('profiles')
      .insert({
        id: user.id,
        username,
        display_name: displayName,
        email_canonical: canonical,
        referral_code: generateReferralCode(),
        referred_by: referrerId || null,
        cam_balance: 0,
      })
      .select('*')
      .single()

    if (!error && profile) {
      return { profile, created: true, error: null, code: null }
    }

    if (error?.code === '23505' && error.message.includes('referral_code')) {
      continue
    }

    if (error?.code === '23503' && referrerId) {
      referrerId = null
      continue
    }

    if (error?.code === '23505' && error.message.includes('email_canonical')) {
      return { profile: null, created: false, error, code: 'email_canonical_exists' as const }
    }

    if (error?.code === '23505' && error.message.includes('username')) {
      return { profile: null, created: false, error, code: 'username_exists' as const }
    }

    return { profile: null, created: false, error, code: 'insert_failed' as const }
  }

  return { profile: null, created: false, error: new Error('Referral code collision'), code: 'referral_collision' as const }
}
