import 'server-only'

const ALLOWED_HOSTNAMES = new Set(
  (process.env.TURNSTILE_ALLOWED_HOSTNAMES || '')
    .split(',')
    .map((h) => h.trim().toLowerCase())
    .filter(Boolean)
)

export async function verifyTurnstile(token: string, ip?: string) {
  const secret = process.env.CF_TURNSTILE_SECRET_KEY
  if (!secret) {
    console.error('[SECURITY] Missing CF_TURNSTILE_SECRET_KEY')
    return false
  }

  try {
    const res = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: `secret=${secret}&response=${token}${ip ? `&remoteip=${ip}` : ''}`,
    })
    const data = await res.json()

    if (!data.success) {
      return false
    }

    // Verify hostname khi cau hinh ALLOWED_HOSTNAMES
    if (ALLOWED_HOSTNAMES.size > 0 && data.hostname) {
      const hostname = String(data.hostname).toLowerCase()
      if (!ALLOWED_HOSTNAMES.has(hostname)) {
        console.error('[SECURITY] Turnstile hostname mismatch:', hostname)
        return false
      }
    }

    return true
  } catch (error) {
    console.error('Turnstile verification error:', error)
    return false
  }
}
