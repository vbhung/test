import { redirect } from 'next/navigation'
import { createAdminClient, createClient } from '@/lib/supabase/server'

export async function getAuthenticatedUser() {
  const supabase = createClient()
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()

  if (error || !user) {
    return null
  }

  return user
}

export async function requireAuthenticatedUser() {
  const user = await getAuthenticatedUser()
  if (!user) {
    throw new Error('UNAUTHORIZED')
  }
  return user
}

export async function getCurrentUserRole(userId: string) {
  const supabaseAdmin = createAdminClient()
  const { data: profile } = await supabaseAdmin
    .from('profiles')
    .select('role')
    .eq('id', userId)
    .maybeSingle()

  return profile?.role ?? null
}

export async function requireAdminUser() {
  const user = await requireAuthenticatedUser()
  const role = await getCurrentUserRole(user.id)

  if (role !== 'admin') {
    throw new Error('FORBIDDEN')
  }

  return user
}

export async function requireAdminPageAccess() {
  const user = await getAuthenticatedUser()
  if (!user) {
    redirect('/login')
  }

  const role = await getCurrentUserRole(user.id)
  if (role !== 'admin') {
    redirect('/dashboard')
  }

  return user
}
