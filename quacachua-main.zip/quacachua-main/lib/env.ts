export function requireServerEnv(key: string): string {
  if (typeof window !== 'undefined') {
    throw new Error(`[SECURITY] ${key} accessed on client side!`)
  }
  const value = process.env[key]
  if (!value) throw new Error(`[CONFIG] Missing server env: ${key}`)
  return value
}

export const serverEnv = {
  supabaseServiceKey: () => requireServerEnv('SUPABASE_SERVICE_ROLE_KEY'),
  cfTurnstileSecret:  () => requireServerEnv('CF_TURNSTILE_SECRET_KEY'),
  tokenMasterSecret:  () => requireServerEnv('TOKEN_MASTER_SECRET'),
  emergencyAdminKey:  () => requireServerEnv('EMERGENCY_ADMIN_KEY'),
  battleshipSecret:   () => requireServerEnv('BATTLESHIP_INTEGRATION_SECRET'),
  battleshipPartnerId:() => process.env.BATTLESHIP_PARTNER_ID || 'quacachua',
  phienchosoToken:    () => requireServerEnv('PHIENCHOSO_TOKEN'),
}
