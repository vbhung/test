export function normalizeGmail(email: string): string | null {
  const lower = email.toLowerCase().trim()
  const atIndex = lower.lastIndexOf('@')
  if (atIndex === -1) return null

  const local = lower.slice(0, atIndex)
  const domain = lower.slice(atIndex + 1)

  if (!['gmail.com', 'googlemail.com'].includes(domain)) return null

  const cleanLocal = local
    .split('+')[0]       
    .replace(/\./g, '')  

  if (!cleanLocal) return null

  return `${cleanLocal}@gmail.com`
}
