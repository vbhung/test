'use client'

const DEVICE_KEY = 'camlink_device_id'
const BROWSER_KEY = 'camlink_browser_id'

function getOrCreate(key: string) {
  let value = window.localStorage.getItem(key)
  if (!value) {
    value = crypto.randomUUID().replace(/-/g, '')
    window.localStorage.setItem(key, value)
  }
  return value
}

export function getClientIdentityHeaders() {
  return {
    'x-client-device-id': getOrCreate(DEVICE_KEY),
    'x-client-browser-id': getOrCreate(BROWSER_KEY),
  }
}

export function getRegistrationIdentity() {
  return {
    deviceId: getOrCreate(DEVICE_KEY),
    browserId: getOrCreate(BROWSER_KEY),
  }
}
