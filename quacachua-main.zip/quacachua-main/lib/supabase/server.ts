import { createServerClient, type CookieOptions } from '@supabase/ssr'
import { cookies } from 'next/headers'

function requireEnv(key: string): string {
  const value = process.env[key]
  if (!value) {
    throw new Error(`[CONFIG] Missing required env var: ${key}`)
  }
  return value
}

export function createClient() {
  return createServerClient(requireEnv('NEXT_PUBLIC_SUPABASE_URL'), requireEnv('NEXT_PUBLIC_SUPABASE_ANON_KEY'), {
    cookies: {
      async get(name: string) {
        const cookieStore = await cookies()
        return cookieStore.get(name)?.value
      },
      async set(name: string, value: string, options: CookieOptions) {
        try {
          const cookieStore = await cookies()
          cookieStore.set({ name, value, ...options })
        } catch {
          // Ignore when called in a server component without mutable cookies.
        }
      },
      async remove(name: string, options: CookieOptions) {
        try {
          const cookieStore = await cookies()
          cookieStore.set({ name, value: '', ...options })
        } catch {
          // Ignore when called in a server component without mutable cookies.
        }
      },
    },
  })
}

export function createAdminClient() {
  return createServerClient(requireEnv('NEXT_PUBLIC_SUPABASE_URL'), requireEnv('SUPABASE_SERVICE_ROLE_KEY'), {
    cookies: {
      get() {
        return undefined
      },
      set() {},
      remove() {},
    },
  })
}
