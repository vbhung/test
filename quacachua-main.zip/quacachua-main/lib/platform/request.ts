import 'server-only'

/**
 * Hosting-neutral request metadata. Set TRUSTED_PROXY_HEADERS=false when a
 * self-hosted server is directly internet-facing; keep it true only behind a
 * proxy that overwrites forwarding headers (Cloudflare/Nginx/Caddy/Vercel).
 */
export function getPlatformRequestInfo(request: Request) {
  const trustProxy = process.env.TRUSTED_PROXY_HEADERS !== 'false'
  const forwarded = trustProxy ? request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() : null
  const ip = request.headers.get('cf-connecting-ip') || forwarded || request.headers.get('x-real-ip') || 'unknown'
  const country = request.headers.get('cf-ipcountry') || request.headers.get('x-app-country') || null
  const protocol = request.headers.get('x-forwarded-proto') || new URL(request.url).protocol.replace(':', '')
  const host = request.headers.get('x-forwarded-host') || request.headers.get('host') || new URL(request.url).host

  return { ip, country, origin: `${protocol}://${host}` }
}
