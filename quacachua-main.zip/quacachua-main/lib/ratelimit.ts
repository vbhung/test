import { headers } from 'next/headers'
import { kv } from '@/lib/kv'

export async function checkRateLimit(
  action: string,
  limit: number,
  windowSecs: number,
  identifier?: string
): Promise<{ success: boolean; current: number }> {
  const headerStore = await headers()
  if (process.env.NODE_ENV === 'production' && (!process.env.UPSTASH_REDIS_REST_URL || !process.env.UPSTASH_REDIS_REST_TOKEN)) {
    throw new Error('[SECURITY] Persistent Redis is required in production')
  }
  const forwardedIp = headerStore.get('cf-connecting-ip') || headerStore.get('x-forwarded-for')?.split(',')[0]?.trim()
    || headerStore.get('x-real-ip') || 'anonymous'
  const ip = identifier || forwardedIp
  const key = `ratelimit:${action}:${ip}`

  const current = await kv.incr(key)
  if (current === 1) {
    await kv.expire(key, windowSecs)
  }

  return { success: current <= limit, current }
}

export async function getIp() {
  const headerStore = await headers()
  return headerStore.get('cf-connecting-ip') || headerStore.get('x-forwarded-for')?.split(',')[0]?.trim()
    || headerStore.get('x-real-ip') || 'anonymous'
}
