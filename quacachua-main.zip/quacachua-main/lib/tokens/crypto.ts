import 'server-only'
import {
  createHmac, createCipheriv, createDecipheriv,
  randomBytes, timingSafeEqual, createHash,
} from 'crypto'

const ALGORITHM  = 'aes-256-gcm'
const IV_LENGTH  = 12
const TAG_LENGTH = 16

function deriveKey(purpose: string): Buffer {
  const master = process.env.TOKEN_MASTER_SECRET!
  if (!master || master.length < 32) {
    throw new Error('[SECURITY] TOKEN_MASTER_SECRET too short or missing')
  }
  return createHmac('sha256', master)
    .update(`${purpose}:v1`)
    .digest()
}

const KEYS = {
  encrypt:    () => deriveKey('encrypt'),
  sign:       () => deriveKey('sign'),
  session:    () => deriveKey('session'),
  reset:      () => deriveKey('reset'),
  idempotent: () => deriveKey('idempotent'),
  link:       () => deriveKey('link'),
  admin:      () => deriveKey('admin'),
  csrf:       () => deriveKey('csrf'),
}

export function encrypt(plaintext: string, purpose: keyof typeof KEYS): string {
  const key = KEYS[purpose]()
  const iv  = randomBytes(IV_LENGTH)

  const cipher = createCipheriv(ALGORITHM, key, iv, { authTagLength: TAG_LENGTH })
  const encrypted = Buffer.concat([
    cipher.update(plaintext, 'utf8'),
    cipher.final(),
  ])
  const tag = cipher.getAuthTag()

  const result = Buffer.concat([iv, tag, encrypted])
  return result.toString('base64url')
}

export function decrypt(token: string, purpose: keyof typeof KEYS): string | null {
  try {
    const buf = Buffer.from(token, 'base64url')
    if (buf.length < IV_LENGTH + TAG_LENGTH + 1) return null

    const iv         = buf.subarray(0, IV_LENGTH)
    const tag        = buf.subarray(IV_LENGTH, IV_LENGTH + TAG_LENGTH)
    const ciphertext = buf.subarray(IV_LENGTH + TAG_LENGTH)

    const key = KEYS[purpose]()
    const decipher = createDecipheriv(ALGORITHM, key, iv, { authTagLength: TAG_LENGTH })
    decipher.setAuthTag(tag)

    const decrypted = Buffer.concat([
      decipher.update(ciphertext),
      decipher.final(),
    ])
    return decrypted.toString('utf8')
  } catch {
    return null
  }
}

export function sign(payload: string, purpose: keyof typeof KEYS): string {
  return createHmac('sha256', KEYS[purpose]())
    .update(payload)
    .digest('base64url')
}

export function safeEqual(a: string, b: string): boolean {
  try {
    return timingSafeEqual(Buffer.from(a), Buffer.from(b))
  } catch {
    return false
  }
}

export function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex')
}

export function generateSecureToken(bytes = 32): string {
  return randomBytes(bytes).toString('base64url')
}

export function generateOpaqueId(bytes = 16): string {
  return randomBytes(bytes).toString('hex')
}
