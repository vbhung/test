import crypto from 'crypto'
import { serverEnv } from '@/lib/env'

const VERIFY_ENTRY_TTL_MS = 20 * 60 * 1000

function base64UrlEncode(value: string) {
  return Buffer.from(value, 'utf8').toString('base64url')
}

function base64UrlDecode(value: string) {
  return Buffer.from(value, 'base64url').toString('utf8')
}

function signPayload(payload: string) {
  return crypto.createHmac('sha256', serverEnv.tokenMasterSecret()).update(payload).digest('base64url')
}

function normalizeHost(hostname: string) {
  return hostname.toLowerCase().replace(/^www\./, '')
}

function getRootDomain(hostname: string) {
  const normalized = normalizeHost(hostname)
  const parts = normalized.split('.')
  if (parts.length <= 2) {
    return normalized
  }
  return parts.slice(-2).join('.')
}

export function getUserAgentHash(userAgent: string) {
  return crypto.createHash('sha256').update(userAgent).digest('hex').slice(0, 24)
}

export function createVerifyEntryCookieValue(input: { userId: string; token: string; userAgent: string; proof: string }) {
  const payload = JSON.stringify({
    userId: input.userId,
    token: input.token,
    ua: getUserAgentHash(input.userAgent),
    ts: Date.now(),
    proof: input.proof,
  })

  const encodedPayload = base64UrlEncode(payload)
  const signature = signPayload(encodedPayload)
  return `${encodedPayload}.${signature}`
}

export function validateVerifyEntryCookie(
  cookieValue: string | undefined,
  input: { userId: string; token: string; userAgent: string }
) {
  if (!cookieValue) {
    return { valid: false, reason: 'missing_cookie' as const, entryTs: 0 }
  }

  const [encodedPayload, signature] = cookieValue.split('.')
  if (!encodedPayload || !signature) {
    return { valid: false, reason: 'invalid_format' as const, entryTs: 0 }
  }

  const expectedSignature = signPayload(encodedPayload)
  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature))) {
    return { valid: false, reason: 'invalid_signature' as const, entryTs: 0 }
  }

  let payload: { userId: string; token: string; ua: string; ts: number; proof: string }
  try {
    payload = JSON.parse(base64UrlDecode(encodedPayload))
  } catch {
    return { valid: false, reason: 'invalid_payload' as const, entryTs: 0 }
  }

  if (payload.userId !== input.userId || payload.token !== input.token) {
    return { valid: false, reason: 'mismatch' as const, entryTs: 0 }
  }

  if (payload.ua !== getUserAgentHash(input.userAgent)) {
    return { valid: false, reason: 'user_agent_mismatch' as const, entryTs: 0 }
  }

  if (Date.now() - payload.ts > VERIFY_ENTRY_TTL_MS) {
    return { valid: false, reason: 'expired' as const, entryTs: 0 }
  }

  return { valid: true as const, entryTs: payload.ts, proof: payload.proof }
}

export function isValidShortlinkEntryReferrer(referer: string | null, shortenedUrl: string) {
  if (!referer) {
    return false
  }

  try {
    const refererUrl = new URL(referer)
    const shortened = new URL(shortenedUrl)

    const refererHost = normalizeHost(refererUrl.hostname)
    const shortenedHost = normalizeHost(shortened.hostname)

    return refererHost === shortenedHost || getRootDomain(refererHost) === getRootDomain(shortenedHost)
  } catch {
    return false
  }
}

export const EARN_VERIFY_ENTRY_COOKIE = 'earn_verify_entry'
