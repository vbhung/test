import 'server-only'
import crypto from 'crypto'
import { serverEnv } from '@/lib/env'
import { extractClientIp } from '@/lib/security/vpn-check'

export const DEVICE_HEADER = 'x-client-device-id'
export const BROWSER_HEADER = 'x-client-browser-id'

function normalize(value: string | null, min = 16) {
  const result = (value || '').trim()
  return result.length >= min && result.length <= 512 ? result : null
}

function hash(kind: string, value: string) {
  return crypto.createHmac('sha256', serverEnv.tokenMasterSecret()).update(`${kind}:${value}`).digest('hex')
}

export function getClientIdentity(request: Request) {
  const ip = extractClientIp(request)
  const deviceId = normalize(request.headers.get(DEVICE_HEADER))
  const browserId = normalize(request.headers.get(BROWSER_HEADER))
  const userAgent = request.headers.get('user-agent') || 'unknown'
  const acceptLanguage = request.headers.get('accept-language') || 'unknown'

  if (ip === 'unknown' || !deviceId || !browserId) return null

  return {
    ip,
    ipHash: hash('ip', ip),
    deviceHash: hash('device', deviceId),
    browserHash: hash('browser', `${browserId}:${userAgent}:${acceptLanguage}`),
  }
}

export async function enforceClientIdentity(
  request: Request,
  userId: string,
  action: string,
  admin: { rpc: (name: string, args: Record<string, unknown>) => PromiseLike<{ error: { message?: string } | null }> }
) {
  const identity = getClientIdentity(request)
  if (!identity) return { allowed: false as const, error: 'Không thể xác minh thiết bị/trình duyệt.' }

  // Salt IP hash với user_id để tránh conflict giữa người dùng khác nhau trên cùng IP (NAT, WiFi chung)
  const userSpecificIpHash = hash('ip', `${identity.ip}:${userId}`)

  const { error } = await admin.rpc('claim_abuse_identity', {
    p_user_id: userId,
    p_ip_hash: userSpecificIpHash,
    p_device_hash: identity.deviceHash,
    p_browser_hash: identity.browserHash,
    p_action: action,
  })

  if (error) {
    return {
      allowed: false as const,
      error: error.message?.includes('IDENTITY_CONFLICT')
        ? 'IP, thiết bị hoặc trình duyệt này đã được gắn với tài khoản khác.'
        : 'Không thể xác minh danh tính thiết bị.',
    }
  }

  return { allowed: true as const, identity }
}
