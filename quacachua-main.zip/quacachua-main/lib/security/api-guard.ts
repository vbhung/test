import 'server-only'
import { NextResponse } from 'next/server'
import { requireAuthenticatedUser } from '@/lib/authz'
import { checkRateLimit } from '@/lib/ratelimit'
import { createAdminClient } from '@/lib/supabase/server'

export interface ApiUser {
  id: string
  email: string
}

/**
 * Helper cho API routes: xac thuc user + check ban + rate limit.
 * Tra ve { user, admin } neu OK, hoac NextResponse loi neu fail.
 */
export async function guardApi(
  request: Request,
  action: string,
  limit: number,
  windowSecs: number
): Promise<{ user: ApiUser; admin: ReturnType<typeof createAdminClient> } | NextResponse> {
  try {
    const user = await requireAuthenticatedUser()
    const supabaseAdmin = createAdminClient()

    // Check ban (RLS khong ap dung cho admin client, nen phai check tay)
    const { data: profile } = await supabaseAdmin
      .from('profiles')
      .select('is_banned')
      .eq('id', user.id)
      .maybeSingle()

    if (profile?.is_banned) {
      return NextResponse.json({ error: 'Tài khoản của bạn đã bị khóa.' }, { status: 403 })
    }

    // Rate limit
    const rl = await checkRateLimit(action, limit, windowSecs, user.id)
    if (!rl.success) {
      return NextResponse.json({ error: 'Thao tác quá nhanh, vui lòng thử lại sau.' }, { status: 429 })
    }

    return { user: { id: user.id, email: user.email ?? '' }, admin: supabaseAdmin }
  } catch (error) {
    if (error instanceof Error && error.message === 'UNAUTHORIZED') {
      return NextResponse.json({ error: 'Bạn cần đăng nhập để thực hiện.' }, { status: 401 })
    }
    if (error instanceof Error && error.message === 'FORBIDDEN') {
      return NextResponse.json({ error: 'Bạn không có quyền thực hiện thao tác này.' }, { status: 403 })
    }
    throw error
  }
}

/** Helper cho admin API routes */
export async function guardAdminApi(
  action: string,
  limit: number,
  windowSecs: number
): Promise<{ admin: ReturnType<typeof createAdminClient> } | NextResponse> {
  try {
    const { requireAdminUser } = await import('@/lib/authz')
    await requireAdminUser()
    const supabaseAdmin = createAdminClient()

    const rl = await checkRateLimit(action, limit, windowSecs)
    if (!rl.success) {
      return NextResponse.json({ error: 'Thao tác quá nhanh, vui lòng thử lại sau.' }, { status: 429 })
    }

    return { admin: supabaseAdmin }
  } catch (error) {
    if (error instanceof Error && error.message === 'UNAUTHORIZED') {
      return NextResponse.json({ error: 'Bạn cần đăng nhập để thực hiện.' }, { status: 401 })
    }
    if (error instanceof Error && error.message === 'FORBIDDEN') {
      return NextResponse.json({ error: 'Bạn không có quyền thực hiện thao tác này.' }, { status: 403 })
    }
    throw error
  }
}
