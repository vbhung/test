import crypto from 'crypto'
import { createAdminClient } from '@/lib/supabase/server'
import { serverEnv } from '@/lib/env'

export function hashRegistrationIdentifier(kind: 'ip' | 'device' | 'browser', value: string) {
  const secret = serverEnv.tokenMasterSecret()
  return crypto
    .createHmac('sha256', secret)
    .update(`${kind}:${value.trim()}`)
    .digest('hex')
}

export function normalizeDeviceId(deviceId: string | null | undefined) {
  const normalized = (deviceId || '').trim()
  if (!normalized) {
    return null
  }

  if (!/^[a-zA-Z0-9_-]{16,128}$/.test(normalized)) {
    return null
  }

  return normalized
}

export async function findRegistrationConflict(ip: string, deviceId: string, browserId?: string) {
  const supabaseAdmin = createAdminClient()
  const ipHash = hashRegistrationIdentifier('ip', ip)
  const deviceHash = hashRegistrationIdentifier('device', deviceId)
  const browserHash = hashRegistrationIdentifier('browser', browserId || deviceId)

  const { data, error } = await supabaseAdmin
    .from('registration_limits')
    .select('id, user_id, ip_hash, device_hash')
    .or(`ip_hash.eq.${ipHash},device_hash.eq.${deviceHash},browser_hash.eq.${browserHash}`)
    .limit(1)

  if (error) {
    throw error
  }

  return {
    conflict: (data?.length ?? 0) > 0,
    ipHash,
    deviceHash,
    browserHash,
  }
}
