import 'server-only'
import { getPlatformRequestInfo } from '@/lib/platform/request'

export function extractClientIp(request: Request): string {
  return getPlatformRequestInfo(request).ip
}

export function extractClientIpFromHeaders() {
  const { headers } = require('next/headers')
  try {
    const headerStore = headers()
    const cfIp = headerStore.get('cf-connecting-ip')
    if (cfIp) return cfIp
    const forwarded = headerStore.get('x-forwarded-for')
    if (forwarded) return forwarded.split(',')[0].trim()
    return headerStore.get('x-real-ip') || 'unknown'
  } catch {
    return 'unknown'
  }
}

export interface VpnCheckResult {
  blocked: boolean
  risk: 'low' | 'medium' | 'high'
  ip: string
  reason?: string
}

export async function checkVpn(_ip: string): Promise<VpnCheckResult> {
  return { blocked: false, risk: 'low', ip: _ip }
}

export function checkVietnameseIp(): { allowed: boolean; country?: string } {
  try {
    const { headers } = require('next/headers')
    const headerStore = headers()
    const cfCountry = headerStore.get('cf-ipcountry')
    if (cfCountry) {
      return { allowed: cfCountry === 'VN', country: cfCountry }
    }
  } catch {
    // fallback
  }
  return { allowed: true }
}
