import { createAdminClient } from '@/lib/supabase/server'

export type CamTransactionType = 
  | 'earn' 
  | 'transfer_in' 
  | 'transfer_out' 
  | 'fee' 
  | 'redeem' 
  | 'referral_bonus' 
  | 'admin_adjust_add' 
  | 'admin_adjust_sub'

export interface ProcessTransactionParams {
  userId: string
  type: CamTransactionType
  amount: number
  description: string
  refId?: string
}

/**
 * Gọi RPC function `process_cam_transaction` an toàn bằng Admin Client.
 * Bắt buộc chạy ở Server-side.
 */
export async function atomicCamTransaction({
  userId,
  type,
  amount,
  description,
  refId,
}: ProcessTransactionParams) {
  const supabase = createAdminClient()
  
  const { data, error } = await supabase.rpc('process_cam_transaction', {
    p_user_id: userId,
    p_type: type,
    p_amount: amount,
    p_description: description,
    p_ref_id: refId || null
  })

  if (error) {
    console.error('[CamEngine] Transaction Failed:', error)
    return { success: false, error: error.message }
  }

  return { success: true, data }
}
