import 'server-only'
import crypto from 'crypto'

const CARDWS_DOMAIN = 'https://thesieure.com'
const CARDWS_PARTNER_ID = '92030571137'
const CARDWS_PARTNER_KEY = '4416160c7555ba879253b7736f7ad958'
const CARDWS_WALLET_NUMBER = '0043070518'

function md5(data: string): string {
  return crypto.createHash('md5').update(data).digest('hex')
}

function sign(command: string, requestId: string): string {
  return md5(CARDWS_PARTNER_KEY + CARDWS_PARTNER_ID + command + requestId)
}

export interface CardResult {
  name: string
  serial: string
  code: string
  expired: string | null
}

export interface BuyCardResponse {
  success: boolean
  message: string
  cards?: CardResult[]
  requestId?: string
  orderCode?: string
  rawStatus?: number
}

let requestIdCounter = 0

export async function buyCard(
  serviceCode: string,
  denomination: number,
  quantity: number
): Promise<BuyCardResponse> {
  requestIdCounter++
  const requestId = `${Date.now()}${requestIdCounter}`
  const command = 'buycard'
  const sig = sign(command, requestId)

  const params = new URLSearchParams({
    partner_id: CARDWS_PARTNER_ID,
    command,
    request_id: requestId,
    service_code: serviceCode,
    wallet_number: CARDWS_WALLET_NUMBER,
    value: String(denomination),
    qty: String(quantity),
    sign: sig,
  })

  const url = `${CARDWS_DOMAIN}/api/cardws?${params.toString()}`

  try {
    const res = await fetch(url, { method: 'POST', signal: AbortSignal.timeout(15000) })
    const text = await res.text()

    let data: any
    try {
      data = JSON.parse(text)
    } catch {
      return { success: false, message: `CardWS returned non-JSON: ${text.substring(0, 200)}` }
    }

    if (data.status === 1) {
      return {
        success: true,
        message: data.message || 'Mua thẻ thành công',
        cards: (data.data?.cards || []).map((c: any) => ({
          name: c.name,
          serial: c.serial,
          code: c.code,
          expired: c.expired,
        })),
        requestId: data.data?.request_id,
        orderCode: data.data?.order_code,
        rawStatus: data.status,
      }
    }

    return {
      success: false,
      message: `CardWS error #${data.status}: ${data.message || 'Lỗi không xác định'}`,
      rawStatus: data.status,
    }
  } catch (err: any) {
    return { success: false, message: `Lỗi kết nối CardWS: ${err.message}` }
  }
}
