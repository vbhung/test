import 'server-only'
import { Redis } from '@upstash/redis'

type KvValue = string | number | Record<string, unknown> | unknown[] | null

interface KvAdapter {
  get<T>(key: string): Promise<T | null>
  set(key: string, value: KvValue, options?: { ex?: number }): Promise<string>
  del(key: string): Promise<number>
  incr(key: string): Promise<number>
  expire(key: string, seconds: number): Promise<number>
}

// ─── Production: Upstash Redis (HTTP-based, Netlify-compatible) ────────────
function createUpstashClient(): KvAdapter {
  const url = process.env.UPSTASH_REDIS_REST_URL
  const token = process.env.UPSTASH_REDIS_REST_TOKEN
  if (!url || !token) {
    throw new Error('[CONFIG] Missing UPSTASH_REDIS_REST_URL or UPSTASH_REDIS_REST_TOKEN')
  }
  const redis = new Redis({ url, token })

  return {
    async get<T>(key: string) {
      return (await redis.get<T>(key)) ?? null
    },
    async set(key: string, value: KvValue, options?: { ex?: number }) {
      if (options?.ex) {
        await redis.set(key, value as never, { ex: options.ex })
      } else {
        await redis.set(key, value as never)
      }
      return 'OK'
    },
    async del(key: string) {
      return await redis.del(key)
    },
    async incr(key: string) {
      return await redis.incr(key)
    },
    async expire(key: string, seconds: number) {
      return await redis.expire(key, seconds)
    },
  }
}

// ─── Dev fallback: in-memory Map (single-process only) ─────────────────────
function createMemoryClient(): KvAdapter {
  const store = new Map<string, { value: KvValue; expiresAt: number | null }>()

  const isAlive = (entry: { value: KvValue; expiresAt: number | null }) =>
    entry.expiresAt === null || Date.now() < entry.expiresAt

  return {
    async get<T>(key: string) {
      const entry = store.get(key)
      if (!entry) return null
      if (!isAlive(entry)) {
        store.delete(key)
        return null
      }
      return entry.value as T
    },
    async set(key: string, value: KvValue, options?: { ex?: number }) {
      const expiresAt = options?.ex ? Date.now() + options.ex * 1000 : null
      store.set(key, { value, expiresAt })
      return 'OK'
    },
    async del(key: string) {
      return store.delete(key) ? 1 : 0
    },
    async incr(key: string) {
      const entry = store.get(key)
      let val = 1
      if (entry && isAlive(entry) && typeof entry.value === 'number') {
        val = entry.value + 1
      }
      store.set(key, { value: val, expiresAt: entry?.expiresAt ?? null })
      return val
    },
    async expire(key: string, seconds: number) {
      const entry = store.get(key)
      if (entry) {
        entry.expiresAt = Date.now() + seconds * 1000
        store.set(key, entry)
        return 1
      }
      return 0
    },
  }
}

const client: KvAdapter =
  process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN
    ? createUpstashClient()
    : createMemoryClient()

export const kv = client
