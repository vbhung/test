import React from "react";
import { cx } from "@/lib/utils";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary-pill" | "utility" | "icon-circular";
  isLoading?: boolean;
}

export function Button({
  className,
  variant = "primary",
  isLoading,
  children,
  disabled,
  ...props
}: ButtonProps) {
  const variantClass = {
    primary: "btn-primary",
    "secondary-pill": "btn-secondary-pill",
    utility: "btn-utility",
    "icon-circular": "btn-icon-circular",
  }[variant];

  return (
    <button
      className={cx(variantClass, isLoading && "opacity-70 pointer-events-none", className)}
      disabled={isLoading || disabled}
      {...props}
    >
      {isLoading ? <span className="btn-spinner" /> : children}
    </button>
  );
}
