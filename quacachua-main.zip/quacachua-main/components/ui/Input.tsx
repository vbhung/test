import React, { forwardRef } from "react";
import { cx } from "@/lib/utils";

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ className, label, error, ...props }, ref) => {
    return (
      <div className="input-wrapper">
        {label && <label className="input-label text-caption-strong">{label}</label>}
        <input
          ref={ref}
          className={cx("input-field", error && "input-error", className)}
          {...props}
        />
        {error && <span className="input-error-text text-caption">{error}</span>}
      </div>
    );
  }
);

Input.displayName = "Input";
