"use client"

import React from 'react'
import { Modal } from './Modal'

interface ConfirmModalProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: () => void
  title: string
  message: React.ReactNode
  confirmText?: string
  cancelText?: string
  isDanger?: boolean
  loading?: boolean
}

export function ConfirmModal({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmText = 'Đồng ý',
  cancelText = 'Hủy',
  isDanger = false,
  loading = false
}: ConfirmModalProps) {
  return (
    <Modal isOpen={isOpen} onClose={onClose} title={title}>
      <div style={{ marginBottom: '24px', font: 'var(--text-body)', color: 'var(--color-ink-muted-80)' }}>
        {message}
      </div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
        <button 
          onClick={onClose} 
          disabled={loading}
          className="dash-btn"
          style={{ 
            backgroundColor: 'transparent', 
            border: '1px solid var(--color-hairline)', 
            color: 'var(--color-ink)',
            padding: '8px 16px',
            borderRadius: 'var(--rounded-md)'
          }}
        >
          {cancelText}
        </button>
        <button 
          onClick={onConfirm}
          disabled={loading}
          className="dash-btn"
          style={{ 
            backgroundColor: isDanger ? 'var(--color-error)' : 'var(--color-primary)', 
            border: 'none', 
            color: 'white',
            padding: '8px 16px',
            borderRadius: 'var(--rounded-md)'
          }}
        >
          {loading ? 'Đang xử lý...' : confirmText}
        </button>
      </div>
    </Modal>
  )
}
