import React from "react";
import { cx } from "@/lib/utils";

interface AvatarProps {
  src?: string | null;
  alt?: string;
  fallback?: string;
  size?: "sm" | "md" | "lg";
  className?: string;
}

export function Avatar({ src, alt, fallback, size = "md", className }: AvatarProps) {
  return (
    <div className={cx("avatar", `avatar-${size}`, className)}>
      {src ? (
        <img src={src} alt={alt || "Avatar"} className="avatar-img" />
      ) : (
        <span className="avatar-fallback text-caption-strong">
          {fallback?.charAt(0).toUpperCase() || "?"}
        </span>
      )}
    </div>
  );
}
