import React from "react";
import { cx } from "@/lib/utils";

interface BadgeProps {
  children: React.ReactNode;
  variant?: "success" | "warning" | "error" | "neutral";
  className?: string;
}

export function Badge({ children, variant = "neutral", className }: BadgeProps) {
  return (
    <span className={cx("badge", `badge-${variant}`, className)}>
      {children}
    </span>
  );
}
