import React from "react";
import { cx } from "@/lib/utils";

export function UtilityCard({
  className,
  children,
}: {
  className?: string;
  children: React.ReactNode;
}) {
  return <div className={cx("utility-card", className)}>{children}</div>;
}

export function ProductTileDark({
  className,
  children,
}: {
  className?: string;
  children: React.ReactNode;
}) {
  return <div className={cx("product-tile-dark", className)}>{children}</div>;
}

export function ProductTileLight({
  className,
  children,
}: {
  className?: string;
  children: React.ReactNode;
}) {
  return <div className={cx("product-tile-light", className)}>{children}</div>;
}
