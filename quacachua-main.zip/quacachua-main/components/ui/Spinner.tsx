import React from "react";
import { cx } from "@/lib/utils";

export function Spinner({ className }: { className?: string }) {
  return <div className={cx("app-spinner", className)} />;
}
