"use client"

import React, { useState, useRef, useEffect } from 'react'
import { Modal } from './Modal'
import { Turnstile } from '@marsidev/react-turnstile'

interface TermsModalProps {
  isOpen: boolean
  onClose: () => void
  onAccept: (token: string) => void
}

export function TermsModal({ isOpen, onClose, onAccept }: TermsModalProps) {
  const [isScrolledToBottom, setIsScrolledToBottom] = useState(false)
  const [captchaToken, setCaptchaToken] = useState<string | null>(null)
  const contentRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (isOpen) {
      setIsScrolledToBottom(false)
      setCaptchaToken(null)
    }
  }, [isOpen])

  const handleScroll = () => {
    if (!contentRef.current) return
    const { scrollTop, scrollHeight, clientHeight } = contentRef.current
    if (Math.ceil(scrollTop + clientHeight) >= scrollHeight - 20) {
      setIsScrolledToBottom(true)
    }
  }

  const siteKey = process.env.NEXT_PUBLIC_CF_TURNSTILE_SITE_KEY
  const captchaDisabled = !siteKey

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Điều khoản Sử dụng Dịch vụ" maxWidth="600px">
      <div 
        ref={contentRef}
        onScroll={handleScroll}
        style={{ 
          maxHeight: '300px', 
          overflowY: 'auto', 
          padding: '16px',
          border: '1px solid var(--color-hairline)',
          borderRadius: 'var(--rounded-md)',
          backgroundColor: 'var(--color-surface-pearl)',
          marginBottom: '24px',
          fontSize: '14px',
          lineHeight: '1.6'
        }}
      >
        <h4 style={{ marginTop: 0 }}>1. Quy định chung</h4>
        <p>Bằng việc đăng ký tài khoản và sử dụng dịch vụ của CamLink, bạn đồng ý tuân thủ mọi quy định dưới đây. Nếu bạn không đồng ý, vui lòng ngừng sử dụng dịch vụ.</p>
        
        <h4>2. Cấm gian lận (Anti-Abuse)</h4>
        <p>CamLink nghiêm cấm mọi hành vi lạm dụng hệ thống để trục lợi, bao gồm nhưng không giới hạn:</p>
        <ul>
          <li>Sử dụng các công cụ (tool), phần mềm, tiện ích mở rộng (extension) để vượt qua (bypass) shortlink tự động.</li>
          <li>Sử dụng VPN/Proxy nhằm thay đổi địa chỉ IP với mục đích gian lận số lượt xem.</li>
          <li>Tạo nhiều tài khoản (clone) để tự giới thiệu (referral) và nhận hoa hồng bất chính.</li>
        </ul>

        <h4>3. Xử lý vi phạm</h4>
        <p>Admin có toàn quyền kiểm tra, rà soát lịch sử giao dịch và lịch sử truy cập của bạn.</p>
        <p>Nếu phát hiện có dấu hiệu gian lận, Admin có quyền <strong>Khóa tài khoản vĩnh viễn</strong> và <strong>Thu hồi toàn bộ số dư Cam</strong> mà không cần báo trước. Quyết định của Admin là quyết định cuối cùng.</p>

        <h4>4. Yêu cầu Rút Cam</h4>
        <p>Khi yêu cầu rút thẻ hoặc rút tiền mặt, bạn cần đảm bảo thông tin cung cấp là hoàn toàn chính xác. Nếu thông tin sai sót dẫn đến giao dịch thất bại, bạn có thể bị trừ một khoản phí làm phiền (ví dụ: 1 Cam) khi được hoàn tiền.</p>

        <h4>5. Hỗ trợ</h4>
        <p>Luôn tôn trọng đội ngũ quản trị. Mọi vấn đề kỹ thuật hoặc nạp rút, vui lòng liên hệ Admin qua kênh hỗ trợ chính thức. Cố tình gây rối hoặc xúc phạm Admin sẽ dẫn đến khóa tài khoản.</p>
        
        <div style={{ height: '50px' }}></div>
        <p style={{ textAlign: 'center', color: 'var(--color-ink-muted-48)', fontStyle: 'italic' }}>--- Vui lòng cuộn đến cuối để đồng ý ---</p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px' }}>
        {captchaDisabled ? (
          <div style={{ padding: '12px', color: 'var(--color-error)', font: 'var(--text-fine-print)', textAlign: 'center' }}>
            CAPTCHA chưa được cấu hình. Vui lòng liên hệ quản trị viên.
          </div>
        ) : (
          <Turnstile 
            siteKey={siteKey}
            onSuccess={(token) => setCaptchaToken(token)}
            options={{ theme: 'auto' }}
          />
        )}

        <button 
          onClick={() => captchaToken && onAccept(captchaToken)}
          disabled={!isScrolledToBottom || !captchaToken}
          className="dash-btn"
          style={{ 
            width: '100%',
            backgroundColor: (isScrolledToBottom && captchaToken) ? 'var(--color-primary)' : 'var(--color-hairline)', 
            border: 'none', 
            color: (isScrolledToBottom && captchaToken) ? 'white' : 'var(--color-ink-muted-48)',
            padding: '12px',
            borderRadius: 'var(--rounded-md)',
            fontWeight: 600,
            cursor: (isScrolledToBottom && captchaToken) ? 'pointer' : 'not-allowed',
            transition: 'all 0.2s'
          }}
        >
          {!isScrolledToBottom ? 'Vui lòng cuộn đọc hết điều khoản' : (!captchaToken ? 'Vui lòng xác thực Captcha' : 'Tôi Đồng Ý')}
        </button>
      </div>
    </Modal>
  )
}
