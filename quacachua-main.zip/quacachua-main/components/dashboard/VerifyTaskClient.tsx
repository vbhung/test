'use client'

import React, { useState } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { Turnstile } from '@marsidev/react-turnstile'
import { CheckCircle2, ShieldCheck, AlertCircle } from 'lucide-react'
import { getClientIdentityHeaders } from '@/lib/client/identity'

export function VerifyTaskClient() {
  const searchParams = useSearchParams()
  const token = searchParams.get('token')
  const entryStatus = searchParams.get('entry')
  const router = useRouter()

  const [status, setStatus] = useState<'idle' | 'verifying' | 'success' | 'error'>('idle')
  const [errorMessage, setErrorMessage] = useState('')
  const [reward, setReward] = useState(0)

  React.useEffect(() => {
    if (entryStatus === 'blocked') {
      setStatus('error')
      setErrorMessage('Liên kết này phải được mở trực tiếp từ shortlink nhiệm vụ. Vui lòng quay lại và bấm lại link rút gọn gốc.')
    }
  }, [entryStatus])

  const handleVerify = async (captchaToken: string) => {
    if (!token) {
      setStatus('error')
      setErrorMessage('Mã token không hợp lệ.')
      return
    }

    setStatus('verifying')
    try {
      const res = await fetch('/api/earn/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getClientIdentityHeaders() },
        body: JSON.stringify({ token, captchaToken })
      })
      const data = await res.json()
      
      if (!res.ok) {
        setStatus('error')
        setErrorMessage(data.error || 'Có lỗi xảy ra trong quá trình xác minh.')
      } else {
        setStatus('success')
        setReward(data.reward)
      }
    } catch (err) {
      setStatus('error')
      setErrorMessage('Lỗi mạng. Vui lòng tải lại trang và thử lại.')
    }
  }

  if (!token) {
    return (
      <div className="bg-[var(--color-surface-pearl)] border border-[var(--color-hairline)] p-8 rounded-[var(--rounded-lg)] shadow-sm max-w-md w-full text-center">
        <AlertCircle className="mx-auto text-red-500 mb-4" width={48} height={48} />
        <h2 className="text-xl font-bold mb-2">Đường dẫn không hợp lệ</h2>
        <p className="text-ink-muted-80 mb-6">Không tìm thấy mã xác minh nhiệm vụ trong URL.</p>
        <button onClick={() => router.push('/dashboard/earn')} className="dash-btn dash-btn-primary w-full justify-center">
          Về trang Kiếm Cam
        </button>
      </div>
    )
  }

  return (
    <div style={{ backgroundColor: 'var(--color-surface-pearl)', border: '1px solid var(--color-hairline)', padding: '32px', borderRadius: 'var(--rounded-lg)', boxShadow: '0 1px 2px rgba(0,0,0,0.05)', maxWidth: '28rem', width: '100%', margin: '0 auto' }}>
      <div style={{ textAlign: 'center', marginBottom: '24px' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: '64px', height: '64px', borderRadius: '50%', backgroundColor: 'rgba(238,108,77,0.1)', color: 'var(--color-primary)', marginBottom: '16px' }}>
          <ShieldCheck width={32} height={32} />
        </div>
        <h1 style={{ fontSize: '24px', fontWeight: 'bold' }}>Xác nhận hoàn thành</h1>
        <p style={{ color: 'var(--color-ink-muted-80)', marginTop: '8px' }}>Vui lòng xác minh Captcha bên dưới để hệ thống đối chiếu và trả thưởng cho bạn.</p>
      </div>

      {status === 'error' && (
        <div style={{ padding: '16px', backgroundColor: 'var(--color-error-bg)', color: 'var(--color-error)', borderRadius: '6px', fontSize: '14px', border: '1px solid var(--color-error)', marginBottom: '24px', textAlign: 'center' }}>
          {errorMessage}
        </div>
      )}

      {status === 'success' ? (
        <div style={{ textAlign: 'center', animation: 'fadeIn 0.5s ease-out' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: '64px', height: '64px', borderRadius: '50%', backgroundColor: 'var(--color-success-bg)', color: 'var(--color-success)', marginBottom: '16px' }}>
            <CheckCircle2 width={32} height={32} />
          </div>
          <h2 style={{ fontSize: '20px', fontWeight: 'bold', color: '#22c55e', marginBottom: '8px' }}>Nhận thưởng thành công!</h2>
          <p style={{ color: 'var(--color-ink-muted-80)', marginBottom: '24px' }}>
            Tuyệt vời! Bạn đã nhận được <strong style={{ color: 'var(--color-primary)' }}>+{reward} Cam</strong> vào tài khoản.
          </p>
          <button 
            onClick={() => router.push('/dashboard/earn')}
            className="dash-btn dash-btn-primary"
            style={{ width: '100%', justifyContent: 'center' }}
          >
            Làm nhiệm vụ khác
          </button>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <div style={{ minHeight: '65px', display: 'flex', alignItems: 'center', justifyContent: 'center', width: '100%', backgroundColor: 'var(--color-canvas-parchment)', borderRadius: '6px', border: '1px solid var(--color-hairline)', padding: '16px' }}>
            {status === 'verifying' ? (
              <span style={{ color: 'var(--color-ink-muted-80)' }}>Đang xử lý...</span>
            ) : (
              <Turnstile 
                siteKey={process.env.NEXT_PUBLIC_CF_TURNSTILE_SITE_KEY!} 
                onSuccess={handleVerify}
                options={{ theme: 'auto' }}
              />
            )}
          </div>
          
          <button 
            onClick={() => router.push('/dashboard/earn')}
            style={{ marginTop: '24px', fontSize: '14px', color: 'var(--color-ink-muted-48)', background: 'transparent', border: 'none', cursor: 'pointer' }}
          >
            Hủy và quay về Dashboard
          </button>
        </div>
      )}
    </div>
  )
}
