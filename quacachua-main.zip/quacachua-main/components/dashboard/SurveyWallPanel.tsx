'use client'

import React, { useEffect, useState } from 'react'
import { ClipboardCheck, ExternalLink, Loader2, RefreshCw, ShieldCheck } from 'lucide-react'

interface SurveyWallResponse {
  surveyUrl?: string
  error?: string
}

export function SurveyWallPanel() {
  const [surveyUrl, setSurveyUrl] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)

  const loadSurveyWall = async () => {
    setLoading(true)
    setError('')

    try {
      const res = await fetch('/api/surveys/cpx/wall', { cache: 'no-store' })
      const data = (await res.json()) as SurveyWallResponse

      if (!res.ok || !data.surveyUrl) {
        setError(data.error || 'Không tải được tường khảo sát.')
        setSurveyUrl('')
        return
      }

      setSurveyUrl(data.surveyUrl)
    } catch (err) {
      setError('Lỗi kết nối khi tải khảo sát. Vui lòng thử lại.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    let active = true

    async function guardedLoad() {
      setLoading(true)
      setError('')

      try {
        const res = await fetch('/api/surveys/cpx/wall', { cache: 'no-store' })
        const data = (await res.json()) as SurveyWallResponse

        if (!active) return

        if (!res.ok || !data.surveyUrl) {
          setError(data.error || 'Không tải được tường khảo sát.')
          setSurveyUrl('')
          return
        }

        setSurveyUrl(data.surveyUrl)
      } catch (err) {
        if (active) setError('Lỗi kết nối khi tải khảo sát. Vui lòng thử lại.')
      } finally {
        if (active) setLoading(false)
      }
    }

    guardedLoad()

    return () => {
      active = false
    }
  }, [])

  if (loading) {
    return (
      <div className="stats-card" style={{ minHeight: '260px', display: 'grid', placeItems: 'center', gap: '12px' }}>
        <Loader2 width={28} height={28} style={{ color: 'var(--color-primary)', animation: 'spin 1s linear infinite' }} />
        <p style={{ font: 'var(--text-body)', color: 'var(--color-ink-muted-80)' }}>Đang tải tường khảo sát...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="stats-card" style={{ borderColor: 'var(--color-error)', backgroundColor: 'var(--color-error-bg)' }}>
        <h2 style={{ font: 'var(--text-body-strong)', color: 'var(--color-error)', marginBottom: '8px' }}>Chưa mở được khảo sát</h2>
        <p style={{ font: 'var(--text-body)', color: 'var(--color-ink-muted-80)', marginBottom: '16px' }}>{error}</p>
        <button type="button" className="dash-btn dash-btn-primary" onClick={loadSurveyWall}>
          <RefreshCw width={16} height={16} />
          Thử lại
        </button>
      </div>
    )
  }

  return (
    <div className="stats-card" style={{ display: 'grid', gap: '14px' }}>
      <h2 style={{ font: 'var(--text-body-strong)', display: 'flex', alignItems: 'center', gap: '10px' }}>
        <ClipboardCheck width={20} height={20} style={{ color: 'var(--color-primary)' }} />
        Làm khảo sát CPX Research
      </h2>
      <p style={{ font: 'var(--text-body)', color: 'var(--color-ink-muted-80)' }}>
        Chọn khảo sát phù hợp trong CPX Research. Khi CPX xác nhận hoàn thành qua postback, Cam sẽ được cộng tự động vào ví.
      </p>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: 'var(--color-success)', font: 'var(--text-body)' }}>
        <ShieldCheck width={18} height={18} />
        Link khảo sát được ký riêng cho tài khoản của bạn, không dùng chung với người khác.
      </div>

      <a
        href={surveyUrl}
        target="_blank"
        rel="noreferrer"
        className="dash-btn dash-btn-primary"
        style={{ justifyContent: 'center', width: '100%', marginTop: '4px' }}
      >
        <ExternalLink width={16} height={16} />
        Mở tường khảo sát
      </a>
    </div>
  )
}
