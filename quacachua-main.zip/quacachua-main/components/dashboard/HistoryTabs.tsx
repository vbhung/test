'use client'

import { useState } from 'react'
import { TransactionItem } from './TransactionItem'
import { Link, Sparkles, Gift, ArrowUpRight, ClipboardList, Coins } from 'lucide-react'

const CATEGORIES = [
  { key: 'shortlink', label: 'Shortlink', icon: Link, color: '#05B169' },
  { key: 'referral', label: 'Hoa Hồng', icon: Sparkles, color: '#F0AD4E' },
  { key: 'redeem', label: 'Duyệt / Rút', icon: Gift, color: '#DF2935' },
  { key: 'transfer', label: 'Chuyển Tiền', icon: ArrowUpRight, color: '#0052FF' },
  { key: 'survey', label: 'Khảo Sát', icon: ClipboardList, color: '#5B616E' },
  { key: 'other', label: 'Khác', icon: Coins, color: '#8A919E' },
]

function categorizeTx(tx: any): string {
  const desc = (tx.description || '').toLowerCase()
  if (tx.type === 'referral_bonus') return 'referral'
  if (tx.type === 'redeem') return 'redeem'
  if (['transfer_in', 'transfer_out', 'fee'].includes(tx.type)) return 'transfer'
  if (tx.type === 'earn' && (desc.includes('khảo sát') || desc.includes('khao sat') || desc.includes('survey'))) return 'survey'
  if (tx.type === 'earn') return 'shortlink'
  return 'other'
}

export function HistoryTabs({ transactions }: { transactions: any[] }) {
  const [activeTab, setActiveTab] = useState('all')

  const grouped: Record<string, any[]> = {}
  for (const tx of transactions) {
    const cat = categorizeTx(tx)
    if (!grouped[cat]) grouped[cat] = []
    grouped[cat].push(tx)
  }

  const filtered = activeTab === 'all' ? transactions : (grouped[activeTab] || [])

  return (
    <div>
      <div style={{ display: 'flex', gap: '4px', marginBottom: '16px', flexWrap: 'wrap' }}>
        <button
          onClick={() => setActiveTab('all')}
          style={{
            padding: '8px 16px', borderRadius: '8px', border: '1px solid var(--color-hairline)',
            background: activeTab === 'all' ? 'var(--color-primary)' : 'transparent',
            color: activeTab === 'all' ? 'white' : 'var(--color-ink)',
            font: 'var(--text-caption-strong)', cursor: 'pointer',
          }}
        >
          Tất cả ({transactions.length})
        </button>
        {CATEGORIES.map(cat => {
          const count = (grouped[cat.key] || []).length
          if (count === 0) return null
          const Icon = cat.icon
          return (
            <button
              key={cat.key}
              onClick={() => setActiveTab(cat.key)}
              style={{
                display: 'inline-flex', alignItems: 'center', gap: '6px',
                padding: '8px 16px', borderRadius: '8px', border: '1px solid var(--color-hairline)',
                background: activeTab === cat.key ? cat.color : 'transparent',
                color: activeTab === cat.key ? 'white' : 'var(--color-ink)',
                font: 'var(--text-caption-strong)', cursor: 'pointer', transition: 'all 0.15s',
              }}
            >
              <Icon width={16} height={16} />
              {cat.label} ({count})
            </button>
          )
        })}
      </div>

      <div className="bg-canvas border border-[var(--color-hairline)] rounded-[12px] overflow-hidden">
        {filtered.length === 0 ? (
          <div className="empty-state-box border-0">
            Không có giao dịch nào trong danh mục này.
          </div>
        ) : (
          <div className="divide-y divide-[var(--color-hairline)]">
            {filtered.map((tx: any) => (
              <TransactionItem key={tx.id} tx={tx} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
