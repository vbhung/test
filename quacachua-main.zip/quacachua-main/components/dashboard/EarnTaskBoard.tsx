'use client'

import React, { useState, useEffect } from 'react'
import { Link2, ArrowRight, CheckCircle2, ShieldCheck, AlertCircle, Clock } from 'lucide-react'
import { Turnstile } from '@marsidev/react-turnstile'
import { Modal } from '@/components/ui/Modal'
import { getClientIdentityHeaders } from '@/lib/client/identity'

interface Provider {
  id: string
  name: string
  code: string
  reward_cam: number
  daily_limit: number
}

const ProviderImage = ({ providerCode, providerName }: { providerCode: string, providerName: string }) => {
  // Gom chung các mã Linktot về một file ảnh linktot.png
  const imageBaseName = providerCode.startsWith('linktot_')
    ? 'linktot'
    : providerCode.startsWith('uptolink_')
      ? 'uptolink'
      : providerCode.startsWith('phienchoso_')
        ? 'phienchoso'
        : providerCode;
  
  const [imgSrc, setImgSrc] = useState(`/images/providers/${imageBaseName}.png`);
  const [errorCount, setErrorCount] = useState(0);

  if (errorCount >= 2) return null;

  return (
    <img 
      src={imgSrc} 
      alt={`Banner ${providerName}`}
      style={{ width: '100%', maxHeight: '120px', objectFit: 'cover', borderRadius: '6px' }}
      onError={() => {
        if (errorCount === 0) {
          setImgSrc('/default.png');
          setErrorCount(1);
        } else {
          setErrorCount(2);
        }
      }}
    />
  );
};

export function EarnTaskBoard({ providers }: { providers: Provider[] }) {
  const [selectedProvider, setSelectedProvider] = useState<Provider | null>(null)
  const [captchaToken, setCaptchaToken] = useState<string>('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [shortenedUrl, setShortenedUrl] = useState('')

  // Pending Task & Stats State
  const [pendingTask, setPendingTask] = useState<any>(null)
  const [completedCounts, setCompletedCounts] = useState<Record<string, number>>({})
  const [pendingReviews, setPendingReviews] = useState<any[]>([])
  const [isPendingLoading, setIsPendingLoading] = useState(true)
  const [cancelModalOpen, setCancelModalOpen] = useState(false)
  const [cancelling, setCancelling] = useState(false)

  const fetchPendingTask = async () => {
    try {
      const [pendingRes, reviewsRes] = await Promise.all([
        fetch('/api/earn/pending', { headers: getClientIdentityHeaders() }),
        fetch('/api/earn/reviews/pending', { headers: getClientIdentityHeaders() }),
      ])
      const pendingData = await pendingRes.json()
      const reviewsData = await reviewsRes.json()
      setPendingTask(pendingData.task || null)
      setCompletedCounts(pendingData.completedCounts || {})
      setPendingReviews(reviewsData.reviews || [])
    } catch (e) {
      console.error(e)
    } finally {
      setIsPendingLoading(false)
    }
  }

  useEffect(() => {
    fetchPendingTask()
  }, [])

  const handleOpenTask = (provider: Provider) => {
    if (pendingTask) {
      setError('')
      setCancelModalOpen(true)
      return
    }
    setError('')
    setSelectedProvider(provider)
    setCaptchaToken('')
    setShortenedUrl('')
  }

  const handleCancelPending = async () => {
    if (!pendingTask) return
    setCancelling(true)
    try {
      const res = await fetch('/api/earn/cancel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getClientIdentityHeaders() },
        body: JSON.stringify({ taskId: pendingTask.id })
      })
      if (res.ok) {
        setPendingTask(null)
        setCancelModalOpen(false)
      }
    } catch (e) {
      console.error(e)
    } finally {
      setCancelling(false)
    }
  }

  const handleGenerate = async () => {
    if (!captchaToken || !selectedProvider) return
    setLoading(true)
    setError('')

    try {
      const res = await fetch('/api/earn/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getClientIdentityHeaders() },
        body: JSON.stringify({
          providerCode: selectedProvider.code,
          captchaToken
        })
      })
      const data = await res.json()
      if (!res.ok) {
        if (data.error === 'pending_task_exists') {
          fetchPendingTask()
          setSelectedProvider(null)
          setCancelModalOpen(true)
        } else {
          setError(data.error || 'Có lỗi xảy ra.')
        }
      } else {
        setShortenedUrl(data.shortenedUrl)
        fetchPendingTask() // refresh pending state
      }
    } catch (err) {
      setError('Lỗi kết nối. Vui lòng thử lại.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      {pendingTask && (
        <div style={{ backgroundColor: 'rgba(234,179,8,0.1)', border: '1px solid rgba(234,179,8,0.2)', borderRadius: '8px', padding: '16px', marginBottom: '24px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#ca8a04', font: 'var(--text-body-strong)' }}>
            <AlertCircle width={20} height={20} />
            Bạn đang có nhiệm vụ chưa hoàn thành
          </div>
          <p style={{ font: 'var(--text-body)', color: 'var(--color-ink)' }}>
            Bạn chưa hoàn thành nhiệm vụ của nhà cung cấp: <strong>{pendingTask.providerName}</strong>
          </p>
          <div style={{ display: 'flex', gap: '12px', marginTop: '4px' }}>
            <a 
              href={pendingTask.shortenedUrl} 
              target="_blank" 
              rel="noreferrer"
              className="dash-btn dash-btn-primary"
              style={{ fontSize: '14px', padding: '8px 16px' }}
            >
              Làm tiếp nhiệm vụ
            </a>
            <button 
              onClick={() => setCancelModalOpen(true)}
              className="dash-btn"
              style={{ fontSize: '14px', padding: '8px 16px', backgroundColor: 'transparent', border: '1px solid var(--color-ink-muted-24)' }}
            >
              Hủy nhiệm vụ
            </button>
          </div>
        </div>
      )}

      {pendingReviews.length > 0 && (
        <div style={{ marginBottom: '24px' }}>
          <h3 style={{ font: 'var(--text-body-strong)', fontSize: '16px', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Clock size={18} /> Cam chờ duyệt
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {pendingReviews.map((r: any) => (
              <div key={r.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-hairline)', borderRadius: '8px' }}>
                <div>
                  <div style={{ fontSize: '14px', fontWeight: 600 }}>Phienchoso review</div>
                  <div style={{ fontSize: '12px', color: 'var(--color-ink-muted-80)' }}>Đã ứng {r.advanced_cam} / {r.total_cam} Cam</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: '14px', fontWeight: 600, color: 'var(--color-primary)' }}>+{r.pending_cam} Cam</div>
                  <div style={{ fontSize: '12px', color: 'var(--color-ink-muted-60)' }}>Chờ duyệt</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {error && !selectedProvider && (
        <div style={{ padding: '12px', backgroundColor: 'var(--color-error-bg)', color: 'var(--color-error)', borderRadius: '8px', marginBottom: '24px', font: 'var(--text-body)', border: '1px solid var(--color-error)' }}>
          {error}
        </div>
      )}

      <div className="stats-grid">
        {providers.length === 0 ? (
          <p className="text-ink-muted-48">Hiện tại không có nhiệm vụ nào khả dụng.</p>
        ) : (
          providers.map(p => {
            const isDailyLimitReached = (completedCounts[p.code] || 0) >= p.daily_limit

            return (
            <div key={p.id} className="stats-card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <div>
                <h3 className="stats-card-title" style={{ display: 'flex', alignItems: 'center', marginBottom: '8px' }}>
                  <Link2 width={18} height={18} style={{ color: 'var(--color-primary)', marginRight: '8px' }} />
                  {p.name}
                </h3>
                <div className="stats-card-value" style={{ color: 'var(--color-primary)', marginTop: '8px' }}>
                  +{p.reward_cam} Cam
                </div>
                
                <div style={{ marginTop: '12px' }}>
                  <ProviderImage providerCode={p.code} providerName={p.name} />
                </div>
                
                <div style={{ marginTop: '16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', marginBottom: '6px', color: 'var(--color-ink-muted-80)' }}>
                    <span>Đã làm hôm nay</span>
                    <span>{completedCounts[p.code] || 0} / {p.daily_limit}</span>
                  </div>
                  <div style={{ height: '6px', backgroundColor: 'var(--color-surface-sunken)', borderRadius: '3px', overflow: 'hidden' }}>
                    <div style={{ 
                      height: '100%', 
                      backgroundColor: ((completedCounts[p.code] || 0) >= p.daily_limit) ? 'var(--color-success)' : 'var(--color-primary)', 
                      width: `${Math.min(100, Math.round(((completedCounts[p.code] || 0) / p.daily_limit) * 100))}%`, 
                      transition: 'width 0.3s ease' 
                    }}></div>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => handleOpenTask(p)}
                disabled={loading || isDailyLimitReached}
                className="dash-btn dash-btn-primary"
                style={{ width: '100%', justifyContent: 'center', marginTop: '16px' }}
              >
                {isDailyLimitReached ? 'Đã hết lượt' : 'Lấy Nhiệm Vụ'}
              </button>
            </div>
          )})
        )}
      </div>

      <div className="stats-card" style={{ marginTop: '24px' }}>
        <h2 style={{ font: 'var(--text-body-strong)', marginBottom: '16px' }}>Hướng dẫn Kiếm Cam</h2>
        <ul style={{ display: 'flex', flexDirection: 'column', gap: '16px', font: 'var(--text-body)', color: 'var(--color-ink-muted-80)', padding: 0, listStyle: 'none' }}>
          <li style={{ display: 'flex', alignItems: 'flex-start' }}>
            <CheckCircle2 style={{ width: '20px', height: '20px', color: 'var(--color-success)', marginRight: '12px', marginTop: '2px' }} />
            <span>Chọn nhà cung cấp và bấm "Lấy Nhiệm Vụ".</span>
          </li>
          <li style={{ display: 'flex', alignItems: 'flex-start' }}>
            <ShieldCheck style={{ width: '20px', height: '20px', color: 'var(--color-success)', marginRight: '12px', marginTop: '2px' }} />
            <span>Xác minh Captcha để lấy đường dẫn an toàn dành riêng cho bạn.</span>
          </li>
          <li style={{ display: 'flex', alignItems: 'flex-start' }}>
            <CheckCircle2 style={{ width: '20px', height: '20px', color: 'var(--color-success)', marginRight: '12px', marginTop: '2px' }} />
            <span>Truy cập vào đường dẫn đó, hoàn thành vượt link và nhận Cam tự động. (Link có thời hạn tùy nhà cung cấp).</span>
          </li>
        </ul>
      </div>

      <Modal isOpen={!!selectedProvider} onClose={() => { setSelectedProvider(null); setError('') }} title={selectedProvider?.name || 'Lấy nhiệm vụ'}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {!shortenedUrl ? (
            <>
              <p style={{ font: 'var(--text-body)', color: 'var(--color-ink-muted-80)', marginBottom: '16px' }}>
                Phần thưởng: <strong style={{ color: 'var(--color-primary)' }}>+{selectedProvider?.reward_cam} Cam</strong>
              </p>
              
              {error && (
                <div style={{ padding: '12px', backgroundColor: 'var(--color-error-bg)', color: 'var(--color-error)', borderRadius: '8px', font: 'var(--text-body)', border: '1px solid var(--color-error)' }}>
                  {error}
                </div>
              )}

              <div style={{ display: 'flex', justifyContent: 'center', margin: '16px 0', minHeight: '65px' }}>
                <Turnstile 
                  siteKey={process.env.NEXT_PUBLIC_CF_TURNSTILE_SITE_KEY!} 
                  onSuccess={(token) => setCaptchaToken(token)}
                  options={{ theme: 'auto' }}
                />
              </div>

              <button 
                onClick={handleGenerate}
                disabled={!captchaToken || loading}
                className="dash-btn dash-btn-primary"
                style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '8px' }}
              >
                {loading ? 'Đang tạo link...' : 'Xác nhận tạo link'}
                {!loading && <ArrowRight width={16} height={16} />}
              </button>
            </>
          ) : (
            <div style={{ textAlign: 'center', padding: '16px 0' }}>
              <div style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: '64px', height: '64px', borderRadius: '50%', backgroundColor: 'var(--color-success-bg)', color: 'var(--color-success)', marginBottom: '16px' }}>
                <CheckCircle2 width={32} height={32} />
              </div>
              <h3 style={{ font: 'var(--text-body-strong)', fontSize: '18px', marginBottom: '8px' }}>Đã tạo link thành công!</h3>
              <p style={{ font: 'var(--text-body)', color: 'var(--color-ink-muted-80)', marginBottom: '24px' }}>Nhấn vào nút bên dưới để đi đến trang nhiệm vụ.</p>
              <a 
                href={shortenedUrl} 
                target="_blank" 
                rel="noreferrer"
                className="dash-btn dash-btn-primary"
                style={{ width: '100%', display: 'block', textAlign: 'center' }}
                onClick={() => setSelectedProvider(null)}
              >
                Đến trang làm nhiệm vụ
              </a>
            </div>
          )}
        </div>
      </Modal>

      <Modal
        isOpen={cancelModalOpen}
        onClose={() => { setCancelModalOpen(false); setError('') }}
        title="Hủy Nhiệm Vụ Cũ"
      >
        <div style={{ padding: '24px', textAlign: 'center' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: '64px', height: '64px', borderRadius: '50%', backgroundColor: 'var(--color-error-bg)', color: 'var(--color-error)', marginBottom: '16px' }}>
            <AlertCircle width={32} height={32} />
          </div>
          <h3 style={{ font: 'var(--text-body-strong)', fontSize: '18px', marginBottom: '8px' }}>Bạn có 1 nhiệm vụ chưa làm</h3>
          <p style={{ font: 'var(--text-body)', color: 'var(--color-ink-muted-80)', marginBottom: '24px' }}>
            Hệ thống chỉ cho phép làm 1 nhiệm vụ cùng lúc. Bạn có muốn hủy nhiệm vụ cũ để tạo nhiệm vụ mới không?
          </p>
          
          <div style={{ display: 'flex', gap: '12px' }}>
            <button 
              onClick={() => setCancelModalOpen(false)}
              className="dash-btn"
              style={{ flex: 1, justifyContent: 'center', backgroundColor: 'var(--color-canvas-parchment)' }}
            >
              Không
            </button>
            <button 
              onClick={handleCancelPending}
              disabled={cancelling}
              className="dash-btn dash-btn-primary"
              style={{ flex: 1, justifyContent: 'center', backgroundColor: 'var(--color-error)' }}
            >
              {cancelling ? 'Đang hủy...' : 'Có, Hủy nhiệm vụ'}
            </button>
          </div>
        </div>
      </Modal>
    </>
  )
}
