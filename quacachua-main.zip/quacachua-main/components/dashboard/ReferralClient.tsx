'use client'

import React, { useState } from 'react'
import { Users, Copy, CheckCircle2, Sparkles, UserCheck, UserX, Info } from 'lucide-react'

interface ReferralClientProps {
  referralCode: string
  siteUrl: string
  totalFriends: number
  activeFriends: number
  inactiveFriends: number
  totalReferralCam: number
}

export function ReferralClient({
  referralCode,
  siteUrl,
  totalFriends,
  activeFriends,
  inactiveFriends,
  totalReferralCam,
}: ReferralClientProps) {
  const [copied, setCopied] = useState<'code' | 'link' | null>(null)
  const referralLink = `${siteUrl}/register?ref=${referralCode}`

  const handleCopyCode = () => {
    if (referralCode) {
      navigator.clipboard.writeText(referralCode)
      setCopied('code')
      setTimeout(() => setCopied(null), 2000)
    }
  }

  const handleCopyLink = () => {
    if (referralLink) {
      navigator.clipboard.writeText(referralLink)
      setCopied('link')
      setTimeout(() => setCopied(null), 2000)
    }
  }

  return (
    <div className="dash-section animate-in fade-in duration-500">
      <header className="dash-header">
        <h1 className="dash-header-title">Mời Bạn Bè</h1>
        <p className="dash-header-subtitle">Nhận 7% hoa hồng vĩnh viễn từ doanh thu vượt link của người bạn mời.</p>
      </header>

      {/* Stats grid: 3 cards trên + 1 card hoa hồng */}
      <div className="stats-grid mb-10" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))' }}>
        {/* Tổng đã mời */}
        <div className="stats-card">
          <div className="stats-card-header">
            <div className="stats-card-icon-wrapper"><Users /></div>
          </div>
          <h3 className="stats-card-title">Tổng đã mời</h3>
          <div className="stats-card-value">{totalFriends}</div>
        </div>

        {/* Đã làm nhiệm vụ */}
        <div className="stats-card">
          <div className="stats-card-header">
            <div className="stats-card-icon-wrapper" style={{ backgroundColor: 'var(--color-success-bg)', color: 'var(--color-success)' }}>
              <UserCheck />
            </div>
          </div>
          <h3 className="stats-card-title">Đã làm nhiệm vụ</h3>
          <div className="stats-card-value" style={{ color: 'var(--color-success)' }}>{activeFriends}</div>
        </div>

        {/* Chưa làm nhiệm vụ */}
        <div className="stats-card">
          <div className="stats-card-header">
            <div className="stats-card-icon-wrapper" style={{ backgroundColor: 'rgba(150,150,150,0.15)', color: 'var(--color-ink-muted-48)' }}>
              <UserX />
            </div>
          </div>
          <h3 className="stats-card-title">Chưa làm nhiệm vụ</h3>
          <div className="stats-card-value" style={{ color: 'var(--color-ink-muted-80)' }}>{inactiveFriends}</div>
        </div>

        {/* Tổng hoa hồng */}
        <div className="stats-card">
          <div className="stats-card-header">
            <div className="stats-card-icon-wrapper"><Sparkles className="text-[#F0AD4E]" /></div>
          </div>
          <h3 className="stats-card-title">Tổng hoa hồng nhận được</h3>
          <div className="stats-card-value text-[#F0AD4E]">{totalReferralCam.toFixed(2)} <span className="text-lg">Cam</span></div>
        </div>
      </div>

      {/* Note quan trọng */}
      <div style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: '10px',
        padding: '14px 16px',
        marginTop: '24px',
        marginBottom: '28px',
        backgroundColor: 'var(--color-success-bg)',
        border: '1px solid var(--color-success)',
        borderRadius: '10px',
        maxWidth: '800px',
      }}>
        <Info size={18} style={{ color: 'var(--color-success)', flexShrink: 0, marginTop: '2px' }} />
        <p style={{ font: 'var(--text-body)', color: 'var(--color-ink-muted-80)', margin: 0 }}>
          <strong style={{ color: 'var(--color-ink)' }}>Số người đã làm ít nhất 1 nhiệm vụ</strong> là yếu tố quan trọng để đạt điều kiện rút tiền.
          Số này phải đạt ngưỡng tối thiểu tùy theo mức rút bạn muốn thực hiện.
        </p>
      </div>

      {/* Mã mời */}
      <div className="stats-card" style={{ maxWidth: '800px' }}>
        <h2 style={{ font: 'var(--text-display-md)', color: 'var(--color-ink)', marginBottom: '24px' }}>Mã Mời Của Bạn</h2>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '32px' }}>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', alignItems: 'center' }}>
            <div style={{
              flex: 1, minWidth: '200px',
              backgroundColor: 'var(--color-canvas-parchment)',
              border: '1px solid var(--color-hairline)',
              borderRadius: 'var(--rounded-md)',
              padding: '12px 16px',
              font: 'var(--text-body-strong)',
              overflowX: 'auto',
              whiteSpace: 'nowrap',
            }}>
              {referralCode || '...'}
            </div>
            <button
              onClick={handleCopyCode}
              className={`dash-btn ${copied === 'code' ? '' : 'dash-btn-primary'}`}
              style={copied === 'code' ? { backgroundColor: 'var(--color-success)', color: 'white' } : {}}
              disabled={!referralCode}
            >
              {copied === 'code'
                ? <><CheckCircle2 style={{ width: '20px', height: '20px', marginRight: '8px' }} /> Đã Copy</>
                : <><Copy style={{ width: '20px', height: '20px', marginRight: '8px' }} /> Copy Mã</>
              }
            </button>
          </div>

          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', alignItems: 'center' }}>
            <div style={{
              flex: 1, minWidth: '300px',
              backgroundColor: 'var(--color-canvas-parchment)',
              border: '1px solid var(--color-hairline)',
              borderRadius: 'var(--rounded-md)',
              padding: '12px 16px',
              font: 'var(--text-body)',
              overflowX: 'auto',
              whiteSpace: 'nowrap',
              wordBreak: 'break-all',
            }}>
              {referralLink || '...'}
            </div>
            <button
              onClick={handleCopyLink}
              className={`dash-btn ${copied === 'link' ? '' : 'dash-btn-primary'}`}
              style={copied === 'link' ? { backgroundColor: 'var(--color-success)', color: 'white' } : {}}
              disabled={!referralCode}
            >
              {copied === 'link'
                ? <><CheckCircle2 style={{ width: '20px', height: '20px', marginRight: '8px' }} /> Đã Copy</>
                : <><Copy style={{ width: '20px', height: '20px', marginRight: '8px' }} /> Copy Link</>
              }
            </button>
          </div>
        </div>

        <h3 style={{ font: 'var(--text-body-strong)', marginBottom: '16px' }}>Cơ chế hoa hồng theo số người mời:</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', font: 'var(--text-body)', color: 'var(--color-ink-muted-80)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 12px', backgroundColor: 'var(--color-canvas-parchment)', borderRadius: '8px', border: '1px solid var(--color-hairline)' }}>
            <span>Người thứ 1</span><strong style={{ color: 'var(--color-ink)' }}>15%</strong>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 12px', backgroundColor: 'var(--color-canvas-parchment)', borderRadius: '8px', border: '1px solid var(--color-hairline)' }}>
            <span>Người thứ 2</span><strong style={{ color: 'var(--color-ink)' }}>13%</strong>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 12px', backgroundColor: 'var(--color-canvas-parchment)', borderRadius: '8px', border: '1px solid var(--color-hairline)' }}>
            <span>Người thứ 3 - 4</span><strong style={{ color: 'var(--color-ink)' }}>10%</strong>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 12px', backgroundColor: 'var(--color-canvas-parchment)', borderRadius: '8px', border: '1px solid var(--color-hairline)' }}>
            <span>Người thứ 5 - 9</span><strong style={{ color: 'var(--color-ink)' }}>7%</strong>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 12px', backgroundColor: 'var(--color-canvas-parchment)', borderRadius: '8px', border: '1px solid var(--color-hairline)' }}>
            <span>Người thứ 10 - 19</span><strong style={{ color: 'var(--color-ink)' }}>5%</strong>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 12px', backgroundColor: 'var(--color-canvas-parchment)', borderRadius: '8px', border: '1px solid var(--color-hairline)' }}>
            <span>Người thứ 20 - 49</span><strong style={{ color: 'var(--color-ink)' }}>2%</strong>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 12px', backgroundColor: 'var(--color-canvas-parchment)', borderRadius: '8px', border: '1px solid var(--color-hairline)' }}>
            <span>Người thứ 50 trở đi</span><strong style={{ color: 'var(--color-ink)' }}>1%</strong>
          </div>
        </div>
        <ul style={{ display: 'flex', flexDirection: 'column', gap: '12px', font: 'var(--text-body)', color: 'var(--color-ink-muted-80)', paddingLeft: '20px', marginTop: '16px' }}>
          <li>Thứ tự được tính dựa trên thời gian tạo tài khoản của người bạn mời (ai đăng ký trước được tính trước).</li>
          <li>Hoa hồng cộng thẳng vào Số dư hiện tại, hệ thống xử lý hoàn toàn tự động.</li>
          <li>Số lượng thành viên giới thiệu là <strong style={{ color: 'var(--color-ink)' }}>không giới hạn</strong>.</li>
        </ul>
      </div>
    </div>
  )
}
