import React from 'react'
import { LucideIcon } from 'lucide-react'

interface StatsCardProps {
  title: string
  value: string | number
  icon: LucideIcon
  trend?: string
}

export function StatsCard({ title, value, icon: Icon, trend }: StatsCardProps) {
  return (
    <div className="stats-card">
      <div className="stats-card-header">
        <div className="stats-card-icon-wrapper">
          <Icon />
        </div>
        {trend && (
          <span className={`stats-card-trend ${trend.startsWith('+') ? 'positive' : 'neutral'}`}>
            {trend}
          </span>
        )}
      </div>
      <h3 className="stats-card-title">{title}</h3>
      <div className="stats-card-value">{value}</div>
    </div>
  )
}
