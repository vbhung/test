'use client'

import React from 'react'
import { EarnTaskBoard } from '@/components/dashboard/EarnTaskBoard'

interface Provider {
  id: string
  name: string
  code: string
  reward_cam: number
  daily_limit: number
}

export function EarnModeTabs({ providers }: { providers: Provider[] }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <EarnTaskBoard providers={providers} />
    </div>
  )
}
