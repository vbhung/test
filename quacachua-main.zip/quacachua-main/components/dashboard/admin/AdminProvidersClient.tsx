'use client'

import React, { useState } from 'react'
import { adminToggleProvider, adminUpdateProvider } from '@/app/actions/admin'
import { Edit2, Save, X, Power, PowerOff } from 'lucide-react'

interface Provider {
  id: string
  name: string
  code: string
  api_url: string
  api_token: string
  reward_cam: number
  daily_limit: number
  is_active: boolean
}

export function AdminProvidersClient({ initialProviders }: { initialProviders: Provider[] }) {
  const [providers, setProviders] = useState<Provider[]>(initialProviders)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editForm, setEditForm] = useState<Partial<Provider>>({})
  const [loading, setLoading] = useState(false)

  const handleEdit = (provider: Provider) => {
    setEditingId(provider.id)
    setEditForm({
      reward_cam: provider.reward_cam,
      daily_limit: provider.daily_limit,
      api_token: provider.api_token,
      api_url: provider.api_url,
    })
  }

  const handleCancel = () => {
    setEditingId(null)
    setEditForm({})
  }

  const handleSave = async (id: string) => {
    setLoading(true)
    const { error } = await adminUpdateProvider(id, editForm)

    if (!error) {
      setProviders(providers.map((provider) => (provider.id === id ? { ...provider, ...editForm } : provider)))
      setEditingId(null)
    } else {
      alert('Loi cap nhat: ' + error)
    }
    setLoading(false)
  }

  const handleToggleActive = async (provider: Provider) => {
    const newStatus = !provider.is_active
    setLoading(true)
    const { error } = await adminToggleProvider(provider.id, newStatus)

    if (!error) {
      setProviders(
        providers.map((currentProvider) =>
          currentProvider.id === provider.id ? { ...currentProvider, is_active: newStatus } : currentProvider
        )
      )
    } else {
      alert('Loi cap nhat: ' + error)
    }
    setLoading(false)
  }

  return (
    <div className="stats-card">
      <div className="overflow-x-auto">
        <table className="dash-table">
          <thead>
            <tr>
              <th>Nha cung cap</th>
              <th>Ma Code</th>
              <th>Thuong (Cam)</th>
              <th>Gioi han/Ngay</th>
              <th>Trang thai</th>
              <th className="text-right">Hanh dong</th>
            </tr>
          </thead>
          <tbody>
            {providers.map((provider) => {
              const isEditing = editingId === provider.id
              return (
                <tr key={provider.id}>
                  <td>
                    <span className="font-semibold">{provider.name}</span>
                  </td>
                  <td>
                    <code className="px-2 py-1 bg-black/10 dark:bg-white/10 rounded text-xs">{provider.code}</code>
                  </td>

                  <td>
                    {isEditing ? (
                      <input
                        type="number"
                        step="0.01"
                        className="dash-input py-1 px-2 h-auto text-sm w-24"
                        value={editForm.reward_cam}
                        onChange={(e) => setEditForm({ ...editForm, reward_cam: Number(e.target.value) })}
                      />
                    ) : (
                      provider.reward_cam
                    )}
                  </td>

                  <td>
                    {isEditing ? (
                      <input
                        type="number"
                        className="dash-input py-1 px-2 h-auto text-sm w-24"
                        value={editForm.daily_limit}
                        onChange={(e) => setEditForm({ ...editForm, daily_limit: Number(e.target.value) })}
                      />
                    ) : (
                      provider.daily_limit
                    )}
                  </td>

                  <td>
                    <button
                      onClick={() => handleToggleActive(provider)}
                      disabled={loading}
                      className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium transition-colors ${
                        provider.is_active
                          ? 'bg-green-500/10 text-green-600 hover:bg-green-500/20'
                          : 'bg-red-500/10 text-red-600 hover:bg-red-500/20'
                      }`}
                    >
                      {provider.is_active ? <Power width={12} height={12} /> : <PowerOff width={12} height={12} />}
                      {provider.is_active ? 'Dang Bat' : 'Da Tat'}
                    </button>
                  </td>

                  <td className="text-right">
                    <div className="flex justify-end gap-2">
                      {isEditing ? (
                        <>
                          <button
                            onClick={() => handleSave(provider.id)}
                            disabled={loading}
                            className="p-1.5 text-green-600 hover:bg-green-500/10 rounded"
                            title="Luu"
                          >
                            <Save width={16} height={16} />
                          </button>
                          <button
                            onClick={handleCancel}
                            disabled={loading}
                            className="p-1.5 text-red-600 hover:bg-red-500/10 rounded"
                            title="Huy"
                          >
                            <X width={16} height={16} />
                          </button>
                        </>
                      ) : (
                        <button
                          onClick={() => handleEdit(provider)}
                          disabled={loading || editingId !== null}
                          className="p-1.5 text-blue-600 hover:bg-blue-500/10 rounded"
                          title="Sua"
                        >
                          <Edit2 width={16} height={16} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              )
            })}
            {providers.length === 0 && (
              <tr>
                <td colSpan={6} className="text-center text-ink-muted-48 py-8">
                  Chua co nha cung cap nao. Vui long chay script SQL.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
