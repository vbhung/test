'use client'

import React, { useState } from 'react'
import { adminRevokeSourceCam, adminRestoreSourceCam, adminDeleteRevokeBatch } from '@/app/actions/admin'
import { Eraser, RotateCcw, Trash2, ShieldAlert, History, XCircle } from 'lucide-react'

interface Batch {
  id: string
  source: 'nhapma' | 'layma'
  status: 'active' | 'restored'
  total_cam: number
  user_count: number
  created_at: string
  restored_at: string | null
  details: { user_id: string; amount: number }[]
}

interface Props {
  initialBatches: Batch[]
}

export function AdminXoaCamClient({ initialBatches }: Props) {
  const [batches, setBatches] = useState<Batch[]>(initialBatches)
  const [loading, setLoading] = useState(false)
  const [toast, setToast] = useState<{ message: string; isError: boolean } | null>(null)

  const showToast = (message: string, isError = false) => {
    setToast({ message, isError })
    setTimeout(() => setToast(null), 4000)
  }

  const activeBatch = (source: 'nhapma' | 'layma') => batches.find((b) => b.source === source && b.status === 'active')

  const handleRevoke = async (source: 'nhapma' | 'layma') => {
    const label = source === 'nhapma' ? 'nhapma' : 'layma'
    if (!confirm(`Bạn có chắc muốn XÓA TOÀN BỘ Cam kiếm từ ${label} cho TẤT CẢ người dùng?\n\nSố dư có thể bị âm. Lệnh này có thể hoàn lại sau.`)) return

    setLoading(true)
    const res = await adminRevokeSourceCam(source)
    setLoading(false)

    if (res.error) {
      showToast(res.error, true)
      return
    }
    showToast(`Đã xóa toàn bộ Cam ${label} (${res.data?.user_count ?? 0} người, ${Number(res.data?.total_cam ?? 0).toFixed(2)} Cam). Bấm "Hoàn" để trả lại.`)
    window.location.reload()
  }

  const handleRestore = async (batch: Batch) => {
    const label = batch.source === 'nhapma' ? 'nhapma' : 'layma'
    if (!confirm(`Bạn có chắc muốn HOÀN (trả lại) ${Number(batch.total_cam).toFixed(2)} Cam cho ${batch.user_count} người dùng?`)) return

    setLoading(true)
    const res = await adminRestoreSourceCam(batch.id)
    setLoading(false)

    if (res.error) {
      showToast(res.error, true)
      return
    }
    showToast(`Đã hoàn ${Number(res.data?.total_cam ?? 0).toFixed(2)} Cam cho ${res.data?.user_count ?? 0} người.`)
    window.location.reload()
  }

  const handleDeletePermanently = async (batch: Batch) => {
    const label = batch.source === 'nhapma' ? 'nhapma' : 'layma'
    if (!confirm(
      `CẢNH BÁO: Xóa hẳn cache hoàn trả cho Cam ${label} (${Number(batch.total_cam).toFixed(2)} Cam, ${batch.user_count} người).\n\nSAU KHI XÓA HẲN SẼ KHÔNG BAO GIỜ HOÀN LẠI ĐƯỢC NỮA!\n\nBạn có chắc chắn?`
    )) return

    setLoading(true)
    const res = await adminDeleteRevokeBatch(batch.id)
    setLoading(false)

    if (res.error) {
      showToast(res.error, true)
      return
    }
    showToast(`Đã xóa hẳn cache. Không thể hoàn lại Cam ${label} nữa.`)
    window.location.reload()
  }

  const sourceMeta: Record<'nhapma' | 'layma', { title: string; desc: string }> = {
    nhapma: { title: 'Cam từ nhapma', desc: 'Xóa toàn bộ Cam nhận từ nhập mã (nhapma)' },
    layma: { title: 'Cam từ layma', desc: 'Xóa toàn bộ Cam nhận từ lấy mã (layma)' },
  }

  const renderSourceCard = (source: 'nhapma' | 'layma') => {
    const meta = sourceMeta[source]
    const active = activeBatch(source)
    const history = batches.filter((b) => b.source === source)

    return (
      <div className="stats-card" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <div>
          <h2 style={{ font: 'var(--text-body-strong)', fontSize: '18px', margin: 0 }}>{meta.title}</h2>
          <p style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-48)', margin: '4px 0 0' }}>{meta.desc}</p>
        </div>

        <button
          onClick={() => handleRevoke(source)}
          disabled={loading || !!active}
          className="dash-btn"
          style={{
            backgroundColor: 'var(--color-error)',
            color: 'white',
            border: 'none',
            padding: '12px 20px',
            fontSize: '14px',
            fontWeight: 600,
            borderRadius: '8px',
            cursor: loading || active ? 'not-allowed' : 'pointer',
            opacity: loading || active ? 0.6 : 1,
          }}
        >
          <Trash2 width={16} height={16} style={{ marginRight: 8 }} />
          Xóa toàn bộ Cam nhận từ {source}
        </button>

        <div style={{ borderTop: '1px solid var(--color-hairline)', paddingTop: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <History width={16} height={16} />
            <span style={{ font: 'var(--text-caption-strong)' }}>Lệnh xóa & Hoàn</span>
          </div>

          {active && (
            <div style={{ backgroundColor: 'var(--color-error-bg)', borderRadius: '8px', padding: '12px', marginBottom: 8, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
              <div>
                <div style={{ font: 'var(--text-body-strong)' }}>
                  Đang xóa: {Number(active.total_cam).toFixed(2)} Cam · {active.user_count} người
                </div>
                <div style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-48)' }}>
                  {new Date(active.created_at).toLocaleString('vi-VN')}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  onClick={() => handleRestore(active)}
                  disabled={loading}
                  className="dash-btn"
                  style={{ backgroundColor: 'var(--color-success)', color: 'white', border: 'none', padding: '10px 16px', fontWeight: 600, borderRadius: '8px' }}
                >
                  <RotateCcw width={16} height={16} style={{ marginRight: 8 }} />
                  Hoàn
                </button>
                <button
                  onClick={() => handleDeletePermanently(active)}
                  disabled={loading}
                  className="dash-btn"
                  style={{ backgroundColor: 'var(--color-canvas)', color: 'var(--color-error)', border: '1px solid var(--color-error)', padding: '10px 16px', fontWeight: 600, borderRadius: '8px' }}
                >
                  <XCircle width={16} height={16} style={{ marginRight: 8 }} />
                  Xóa hẳn (không hoàn được)
                </button>
              </div>
            </div>
          )}

          {!active && history.some((b) => b.status === 'restored') && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-48)' }}>
              <RotateCcw width={14} height={14} />
              Lệnh xóa gần nhất đã được hoàn.
            </div>
          )}

          {history.length === 0 && (
            <div style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-48)' }}>
              Chưa có lệnh xóa nào.
            </div>
          )}
        </div>
      </div>
    )
  }

  return (
    <>
      {toast && (
        <div style={{
          position: 'fixed', bottom: '24px', right: '24px',
          backgroundColor: toast.isError ? 'var(--color-error)' : 'var(--color-success)',
          color: 'white', padding: '12px 24px', borderRadius: '8px', zIndex: 9999,
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)', animation: 'slideUp 0.3s ease-out',
        }}>
          {toast.message}
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '16px' }}>
        {renderSourceCard('nhapma')}
        {renderSourceCard('layma')}
      </div>

      <div style={{ marginTop: '16px', display: 'flex', gap: 8, alignItems: 'flex-start', backgroundColor: 'rgba(255,170,0,0.08)', borderRadius: '8px', padding: '16px' }}>
        <ShieldAlert width={20} height={20} style={{ color: '#b8860b', flexShrink: 0, marginTop: 2 }} />
        <div style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-48)' }}>
          <strong>Lưu ý:</strong> Hành động xóa sẽ trừ thẳng vào số dư của mọi người (kể cả người đã tiêu Cam, có thể bị âm). Lịch sử giao dịch của mỗi người sẽ ghi: "Hệ thống tự trừ cam lý do {'{nhapma/layma}'} ngưng duyệt/đóng cửa". Bấm "Hoàn" để trả lại đúng số Cam đã trừ. Bấm <strong>"Xóa hẳn"</strong> để xóa cache hoàn trả, lúc đó Cam sẽ <strong>không bao giờ hoàn lại được nữa</strong>.
        </div>
      </div>
    </>
  )
}
