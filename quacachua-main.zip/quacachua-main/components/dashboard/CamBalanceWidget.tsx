'use client'

import React, { useEffect, useState } from 'react'

function toSafeNumber(value: number | string | null | undefined) {
  const numberValue = Number(value ?? 0)
  return Number.isFinite(numberValue) ? numberValue : 0
}

export function CamBalanceWidget({ balance = 0 }: { balance?: number | string | null }) {
  const [displayBalance, setDisplayBalance] = useState(0)
  const safeBalance = toSafeNumber(balance)

  // Count up animation
  useEffect(() => {
    let start = 0
    const end = safeBalance
    if (start === end) return

    const duration = 1000
    const incrementTime = 20
    const step = (end - start) / (duration / incrementTime)

    const timer = setInterval(() => {
      start += step
      if (start >= end) {
        setDisplayBalance(end)
        clearInterval(timer)
      } else {
        setDisplayBalance(start)
      }
    }, incrementTime)

    return () => clearInterval(timer)
  }, [safeBalance])

  return (
    <div className="cam-balance-widget">
      {/* Glow effect behind */}
      <div className="cam-balance-glow"></div>
      
      <h2 className="cam-balance-label">Số dư hiện tại</h2>
      
      <div className="cam-balance-value-row">
        <span className="cam-balance-number">
          {displayBalance.toFixed(2)}
        </span>
        <span className="cam-balance-currency">Cam</span>
      </div>
      
      <div className="cam-balance-vnd">
        ≈ {(safeBalance * 250).toLocaleString('vi-VN')} VNĐ
      </div>
    </div>
  )
}
