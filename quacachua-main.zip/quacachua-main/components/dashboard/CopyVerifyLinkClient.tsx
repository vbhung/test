'use client'

import React from 'react'
import { useSearchParams } from 'next/navigation'
import { AlertCircle, LogIn, RotateCcw } from 'lucide-react'

export function CopyVerifyLinkClient() {
  const searchParams = useSearchParams()
  const token = searchParams.get('token')
  const returnTo = token ? `/verify-task?token=${encodeURIComponent(token)}` : '/dashboard/earn'

  return (
    <div style={{ backgroundColor: 'var(--color-surface-pearl)', border: '1px solid var(--color-hairline)', padding: '32px', borderRadius: 'var(--rounded-lg)', boxShadow: '0 1px 2px rgba(0,0,0,0.05)', maxWidth: '28rem', width: '100%', margin: '0 auto', textAlign: 'center' }}>
      <AlertCircle className="mx-auto text-[#f59e0b] mb-4" width={48} height={48} />
      <h2 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '8px' }}>Can dang nhap de xac minh</h2>
      <p style={{ color: 'var(--color-ink-muted-80)', marginBottom: '24px', fontSize: '15px', lineHeight: '1.5' }}>
        Lien ket nhan thuong chi co hieu luc trong dung trinh duyet dang lam nhiem vu. Vui long dang nhap tren trinh duyet nay roi mo lai shortlink goc de tiep tuc.
      </p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        <button
          onClick={() => {
            window.location.href = `/login?redirect=${encodeURIComponent(returnTo)}`
          }}
          className="dash-btn dash-btn-primary"
          style={{ width: '100%', justifyContent: 'center' }}
        >
          <LogIn style={{ width: '20px', height: '20px', marginRight: '8px' }} />
          Dang nhap
        </button>

        <button
          onClick={() => {
            window.location.href = '/dashboard/earn'
          }}
          className="dash-btn dash-btn-outline"
          style={{ width: '100%', justifyContent: 'center' }}
        >
          <RotateCcw style={{ width: '20px', height: '20px', marginRight: '8px' }} />
          Quay lai nhiem vu
        </button>
      </div>
    </div>
  )
}
