import React from 'react'
import { ArrowDownLeft, ArrowUpRight, Gift, Link, ShieldAlert, Sparkles, Coins, Trophy, RotateCcw } from 'lucide-react'

const TX_INFO = {
  earn: { label: 'Vượt Link Nhận Thưởng', icon: Link },
  transfer_in: { label: 'Nhận Chuyển Khoản', icon: ArrowDownLeft },
  transfer_out: { label: 'Chuyển Khoản Đi', icon: ArrowUpRight },
  fee: { label: 'Phí Giao Dịch', icon: ShieldAlert },
  redeem: { label: 'Rút / Đổi Thưởng', icon: Gift },
  referral_bonus: { label: 'Hoa Hồng Giới Thiệu', icon: Sparkles },
  admin_adjust: { label: 'Hệ Thống Điều Chỉnh', icon: Coins },
  admin_adjust_add: { label: 'Thưởng Top Tuần', icon: Trophy },
  admin_adjust_sub: { label: 'Hệ Thống Trừ Cam', icon: ShieldAlert },
  earn_revoke: { label: 'Hệ Thống Tự Trừ Cam', icon: ShieldAlert },
  earn_restore: { label: 'Hệ Thống Hoàn Trả Cam', icon: RotateCcw },
  deposit: { label: 'Nạp / Hoàn Tiền', icon: ArrowDownLeft },
  withdraw: { label: 'Trừ Số Dư', icon: ArrowUpRight },
}

export function TransactionItem({ tx }: { tx: any }) {
  const info = TX_INFO[tx.type as keyof typeof TX_INFO] || { label: 'Giao dịch', icon: Coins }
  const Icon = info.icon
  const balanceBefore = Number(tx.balance_before ?? 0)
  const balanceAfter = Number(tx.balance_after ?? 0)
  const amount = Number(tx.amount ?? 0)

  let isPositive = balanceAfter > balanceBefore
  if (balanceAfter === balanceBefore) {
    if (['redeem', 'transfer_out', 'withdraw', 'fee', 'admin_adjust_sub', 'earn_revoke'].includes(tx.type)) {
      isPositive = false
    } else {
      isPositive = true
    }
  }

  const colorClass = isPositive ? 'text-[#05B169]' : 'text-[#DF2935]'
  const sign = isPositive ? '+' : '-'

  return (
    <div className="dash-tx-item">
      <div className="dash-tx-left">
        <div className={`dash-tx-icon ${isPositive ? 'dash-tx-icon-pos' : 'dash-tx-icon-neg'}`}>
          <Icon width={18} height={18} />
        </div>
        <div>
          <p className="dash-tx-title">{info.label}</p>
          <p className="dash-tx-desc" title={tx.description}>{tx.description}</p>
        </div>
      </div>
      <div className="dash-tx-right">
        <p className={`dash-tx-amount ${colorClass}`}>
          {sign}{(Number.isFinite(amount) ? amount : 0).toFixed(2)} Cam
        </p>
        <p className="dash-tx-date">
          {new Date(tx.created_at).toLocaleString('vi-VN')}
        </p>
      </div>
    </div>
  )
}
