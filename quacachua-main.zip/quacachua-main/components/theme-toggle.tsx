"use client"

import * as React from "react"
import { Moon, Sun } from "lucide-react"
import { useTheme } from "next-themes"

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = React.useState(false)

  React.useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return <div style={{ width: 40, height: 40 }} />
  }

  return (
    <button
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
      className="dash-btn"
      style={{
        padding: '8px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'var(--color-surface)',
        border: '1px solid var(--color-hairline)',
        borderRadius: 'var(--rounded-full)',
        color: 'var(--color-ink)',
        cursor: 'pointer'
      }}
      title="Đổi giao diện"
    >
      {theme === "dark" ? (
        <Sun style={{ width: 20, height: 20 }} />
      ) : (
        <Moon style={{ width: 20, height: 20 }} />
      )}
    </button>
  )
}
