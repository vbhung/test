'use client'

import React, { useState, useEffect } from 'react'
import Link from 'next/link'
import { Bell, Menu } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { ThemeToggle } from '@/components/theme-toggle'
import { useSidebar } from '@/contexts/SidebarContext'

export function GlobalNav() {
  const [showNotif, setShowNotif] = useState(false)
  const [notifications, setNotifications] = useState<any[]>([])
  const [timeStr, setTimeStr] = useState('')
  const [camBalance, setCamBalance] = useState<number | null>(null)
  const supabase = createClient()
  const { toggle } = useSidebar()

  useEffect(() => {
    // Clock setup
    const clockInterval = setInterval(() => {
      const now = new Date()
      setTimeStr(now.toLocaleTimeString('vi-VN') + ' - ' + now.toLocaleDateString('vi-VN'))
    }, 1000)
    
    // Initial clock set
    const now = new Date()
    setTimeStr(now.toLocaleTimeString('vi-VN') + ' - ' + now.toLocaleDateString('vi-VN'))

    return () => clearInterval(clockInterval)
  }, [])

  useEffect(() => {
    let intervalId: NodeJS.Timeout

    const fetchData = () => {
      supabase.auth.getUser().then(({ data: { user } }) => {
        if (user) {
          // Fetch notifications
          supabase
            .from('notifications')
            .select('*')
            .eq('user_id', user.id)
            .order('created_at', { ascending: false })
            .limit(10)
            .then(({ data }) => {
              if (data) setNotifications(data)
            })

          // Fetch cam balance
          supabase
            .from('profiles')
            .select('cam_balance')
            .eq('id', user.id)
            .single()
            .then(({ data }) => {
              if (data) setCamBalance(data.cam_balance)
            })
        }
      })
    }

    fetchData() // initial fetch
    intervalId = setInterval(fetchData, 60000) // fetch every 60s

    return () => clearInterval(intervalId)
  }, [supabase])

  const unreadCount = notifications.filter(n => !n.is_read).length

  return (
    <nav className="global-nav">
      {/* Left: Logo */}
      <div className="global-nav-left" style={{ display: 'flex', alignItems: 'center' }}>
        <button className="nav-icon-btn mobile-menu-btn" onClick={toggle} style={{ marginRight: '12px' }}>
          <Menu width={20} height={20} />
        </button>
        <Link href="/" className="global-nav-logo">
          CamLink
        </Link>
      </div>

      {/* Center: Real-time clock instead of Nav Links */}
      <div className="global-nav-center" style={{ fontFamily: 'monospace', fontSize: '15px', color: 'var(--color-ink-muted-48)', fontWeight: 500, display: 'flex', gap: '12px' }}>
        <span>{timeStr}</span>
        {camBalance !== null && (
          <>
            <span style={{ color: 'var(--color-hairline)' }}>|</span>
            <span style={{ color: 'var(--color-primary)', fontWeight: 600 }}>{camBalance.toFixed(2)} Cam</span>
          </>
        )}
      </div>

      {/* Right: Actions */}
      <div className="global-nav-right" style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        <ThemeToggle />

        <div style={{ position: 'relative' }}>
          <button 
            className="nav-icon-btn" 
            onClick={() => setShowNotif(!showNotif)}
            style={{ display: 'flex', alignItems: 'center', position: 'relative' }}
          >
            <Bell width={18} height={18} />
            {unreadCount > 0 && <span className="nav-badge"></span>}
          </button>

          {showNotif && (
            <div style={{
              position: 'absolute',
              top: '50px',
              right: '0',
              width: '320px',
              backgroundColor: 'var(--color-canvas)',
              border: '1px solid var(--color-hairline)',
              borderRadius: 'var(--rounded-lg)',
              boxShadow: 'var(--shadow-product)',
              zIndex: 100,
              overflow: 'hidden'
            }}>
              <div style={{ padding: '16px', borderBottom: '1px solid var(--color-hairline)', font: 'var(--text-body-strong)' }}>
                Thông báo
              </div>
              <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
                {notifications.length === 0 ? (
                  <div style={{ padding: '24px', textAlign: 'center', color: 'var(--color-ink-muted-48)', font: 'var(--text-body)' }}>Không có thông báo nào.</div>
                ) : (
                  notifications.map(n => (
                    <div key={n.id} style={{ padding: '12px 16px', borderBottom: '1px solid var(--color-hairline)', backgroundColor: n.is_read ? 'transparent' : 'var(--color-surface-pearl)' }}>
                      <div style={{ font: 'var(--text-caption-strong)', marginBottom: '4px' }}>{n.title}</div>
                      <div style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-80)' }}>{n.body}</div>
                      <div style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-48)', marginTop: '8px', fontSize: '10px' }}>
                        {new Date(n.created_at).toLocaleString('vi-VN')}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </nav>
  )
}
