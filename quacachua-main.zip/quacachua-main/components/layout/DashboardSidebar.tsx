'use client'

import React from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { useSidebar } from '@/contexts/SidebarContext'
import { 
  LayoutDashboard, 
  Coins, 
  Send, 
  Gift, 
  Users, 
  History, 
  Settings, 
  LogOut,
  Zap,
  Award,
  Trophy,
  BarChart3,
  Anchor,
  Megaphone,
  ShoppingCart,
  Eraser
} from 'lucide-react'

const NAV_ITEMS = [
  { href: '/dashboard/top', label: 'Top Tuần', icon: Trophy },
  { href: '/dashboard', label: 'Tổng quan', icon: LayoutDashboard },
  { href: '/dashboard/statistics', label: 'Thống kê', icon: BarChart3 },
  { href: '/dashboard/earn', label: 'Kiếm Cam', icon: Zap },
  { href: '/dashboard/battleship', label: 'Battleship', icon: Anchor },
  { href: '/dashboard/mua-hang', label: 'Mua Hàng Đc Hoàn', icon: ShoppingCart },
  { href: '/dashboard/transfer', label: 'Chuyển Cam', icon: Send },
  { href: '/dashboard/redeem', label: 'Rút Cam', icon: Gift },
  { href: '/dashboard/referral', label: 'Mời bạn', icon: Users },
  { href: '/dashboard/history', label: 'Lịch sử GD', icon: History },
  { href: '/dashboard/settings', label: 'Cài đặt', icon: Settings },
]

type SidebarProfile = {
  display_name: string | null
  username: string | null
  role: string | null
}

export function DashboardSidebar({ initialProfile }: { initialProfile: SidebarProfile | null }) {
  const pathname = usePathname()
  const router = useRouter()
  const supabase = createClient()
  const [profile, setProfile] = React.useState<SidebarProfile | null>(initialProfile)
  const { isOpen, setIsOpen } = useSidebar()

  React.useEffect(() => {
    setProfile(initialProfile)
  }, [initialProfile])

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push('/login')
    router.refresh()
  }

  return (
    <>
      {isOpen && <div className="sidebar-overlay" onClick={() => setIsOpen(false)} />}
      <aside className={`dash-sidebar ${isOpen ? 'open' : ''}`}>
        <div className="dash-sidebar-menu">
          {NAV_ITEMS.map((item) => {
            const isActive = pathname === item.href
            return (
              <Link 
                key={item.href} 
                href={item.href}
                onClick={() => setIsOpen(false)}
              className={`sidebar-item ${isActive ? 'active' : ''}`}
            >
              <item.icon className="sidebar-item-icon" />
              <span>{item.label}</span>
            </Link>
          )
        })}

        {profile?.role === 'admin' && (
          <div style={{ marginTop: '16px', borderTop: '1px solid var(--color-hairline)', paddingTop: '16px' }}>
            <p style={{ padding: '0 12px 8px', font: 'var(--text-caption-strong)', color: 'var(--color-ink-muted-48)', textTransform: 'uppercase', letterSpacing: '1px' }}>Quản trị viên</p>
            <Link 
              href="/dashboard/admin/users"
              className={`sidebar-item ${pathname === '/dashboard/admin/users' ? 'active' : ''}`}
            >
              <Users className="sidebar-item-icon" />
              <span>Quản lý Users</span>
            </Link>
            <Link 
              href="/dashboard/admin/tickets"
              className={`sidebar-item ${pathname === '/dashboard/admin/tickets' ? 'active' : ''}`}
            >
              <LayoutDashboard className="sidebar-item-icon" />
              <span>Duyệt Rút Tiền</span>
            </Link>
            <Link 
              href="/dashboard/admin/providers"
              className={`sidebar-item ${pathname === '/dashboard/admin/providers' ? 'active' : ''}`}
            >
              <Zap className="sidebar-item-icon" />
              <span>Nhiệm vụ (Kiếm Cam)</span>
            </Link>
            <Link 
              href="/dashboard/admin/notification"
              className={`sidebar-item ${pathname === '/dashboard/admin/notification' ? 'active' : ''}`}
            >
              <Megaphone className="sidebar-item-icon" />
              <span>Thông báo</span>
            </Link>
            <Link 
              href="/dashboard/admin/xoa-cam"
              className={`sidebar-item ${pathname === '/dashboard/admin/xoa-cam' ? 'active' : ''}`}
            >
              <Eraser className="sidebar-item-icon" />
              <span>Xóa Cam</span>
            </Link>
          </div>
        )}
      </div>

      <div className="dash-sidebar-footer">
        <div className="user-profile-mini">
          <div className="user-profile-avatar">
            {profile?.display_name ? profile.display_name.charAt(0).toUpperCase() : 'U'}
          </div>
          <div className="user-profile-info">
            <p className="user-profile-name">{profile?.display_name || 'Tài khoản'}</p>
            <p className="user-profile-email">@{profile?.username || 'user'}</p>
          </div>
        </div>
        <button className="sidebar-logout-btn" onClick={handleLogout}>
          <LogOut width={20} height={20} />
          <span>Đăng xuất</span>
        </button>
      </div>
    </aside>
    </>
  )
}
