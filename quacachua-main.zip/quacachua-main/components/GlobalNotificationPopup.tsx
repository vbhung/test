'use client'

import React, { useEffect, useState } from 'react'
import { X, Megaphone } from 'lucide-react'
import { Modal } from '@/components/ui/Modal'

const LS_KEY = 'global_notif_hide'
const HIDE_DURATION_MS = 90 * 60 * 1000

export default function GlobalNotificationPopup() {
  const [notif, setNotif] = useState<{ content: string; updatedAt: string } | null>(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    fetch('/api/notification')
      .then(r => r.json())
      .then(data => {
        if (!data.content) return
        setNotif({ content: data.content, updatedAt: data.updated_at })

        const stored = localStorage.getItem(LS_KEY)
        if (stored) {
          try {
            const parsed = JSON.parse(stored)
            if (parsed.content === data.content && parsed.updatedAt === data.updated_at) {
              const elapsed = Date.now() - (parsed.dismissedAt || 0)
              if (elapsed < HIDE_DURATION_MS) return
            }
          } catch {}
        }

        setVisible(true)
      })
      .catch(() => {})
  }, [])

  const handleDismiss = () => {
    if (!notif) return
    localStorage.setItem(LS_KEY, JSON.stringify({
      content: notif.content,
      updatedAt: notif.updatedAt,
      dismissedAt: Date.now(),
    }))
    setVisible(false)
  }

  if (!visible || !notif) return null

  return (
    <Modal isOpen={true} onClose={handleDismiss}>
      <div style={{ padding: '8px 0' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
          <div style={{
            width: '36px', height: '36px', borderRadius: '50%',
            backgroundColor: 'var(--color-primary-muted)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0
          }}>
            <Megaphone size={18} style={{ color: 'var(--color-primary)' }} />
          </div>
          <span style={{ font: 'var(--text-body-strong)' }}>Thông báo</span>
        </div>
        <div
          style={{ font: 'var(--text-body)', whiteSpace: 'pre-wrap', lineHeight: 1.6, textAlign: 'left' }}
          dangerouslySetInnerHTML={{ __html: notif.content }}
        />
        <button
          onClick={handleDismiss}
          className="dash-btn"
          style={{ marginTop: '16px', backgroundColor: 'var(--color-primary)', color: 'white', padding: '8px 24px' }}
        >
          Đã hiểu
        </button>
      </div>
    </Modal>
  )
}
