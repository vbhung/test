import { NextResponse } from 'next/server'
import { kv } from '@/lib/kv'
import { atomicCamTransaction } from '@/lib/cam/transaction'
import { ensureUserProfile, type PendingRegistrationData } from '@/lib/auth/profile'
import { createAdminClient, createClient } from '@/lib/supabase/server'

export async function GET(request: Request) {
  const requestUrl = new URL(request.url)
  const code = requestUrl.searchParams.get('code')

  if (!code) {
    return NextResponse.redirect(`${requestUrl.origin}/login?error=Loi+xac+thuc`)
  }

  const supabase = createClient()
  const { data, error } = await supabase.auth.exchangeCodeForSession(code)

  if (error || !data.user) {
    return NextResponse.redirect(`${requestUrl.origin}/login?error=Loi+xac+thuc`)
  }

  const userId = data.user.id
  const pendingKey = `register:pending:${userId}`
  const pendingData = await kv.get<PendingRegistrationData>(pendingKey)

  const supabaseAdmin = createAdminClient()
  const profileResult = await ensureUserProfile(supabaseAdmin, data.user, pendingData)

  if (!profileResult.profile) {
    console.error('[AUTH_CALLBACK] Failed to ensure profile', profileResult.error)
    if (profileResult.code === 'email_canonical_exists') {
      await supabaseAdmin.auth.admin.deleteUser(userId)
      await supabase.auth.signOut()
      return NextResponse.redirect(`${requestUrl.origin}/login?error=Email+da+duoc+dang+ky`)
    }

    await supabase.auth.signOut()
    return NextResponse.redirect(`${requestUrl.origin}/login?error=Tao+profile+that+bai`)
  }

  await supabaseAdmin.from('registration_limits').update({ status: 'confirmed' }).eq('user_id', userId)
  await kv.del(pendingKey)

  const referrerId = profileResult.profile.referred_by
  if (profileResult.created && referrerId) {
    const signupBonusTx = await supabaseAdmin
      .from('cam_transactions')
      .select('id')
      .eq('user_id', userId)
      .eq('type', 'earn')
      .ilike('description', '%Thuong dang ky theo ma moi%')
      .maybeSingle()

    if (!signupBonusTx.data) {
      const tx = await atomicCamTransaction({
        userId,
        type: 'earn',
        amount: 0.75,
        description: 'Thuong dang ky theo ma moi',
      })

      if (tx.success) {
        await supabaseAdmin.from('notifications').insert({
          user_id: userId,
          title: 'Nhan 0.75 Cam thuong',
          body: 'Ban duoc tang 0.75 Cam vi da dang ky thong qua ma gioi thieu.',
        })
      }
    }
  }

  return NextResponse.redirect(`${requestUrl.origin}/dashboard`)
}
