'use client'

import React, { useState } from 'react'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { UtilityCard } from '@/components/ui/Card'
import { loginAction } from '@/app/actions/auth'

export default function LoginPage() {
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    const formData = new FormData(e.currentTarget)
    const res = await loginAction(formData)
    
    setLoading(false)

    if (res.error) {
      setError(res.error)
    } else if (res.success) {
      window.location.href = '/dashboard'
    }
  }

  return (
    <div className="auth-layout">
      <div className="auth-card-container">
        <h1 className="auth-title">Đăng nhập</h1>
        <p className="auth-subtitle">Chào mừng bạn trở lại CamLink</p>

        {error && (
          <div className="auth-error">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="auth-form">
          <Input
            name="email"
            label="Email hoặc Tên đăng nhập"
            type="text"
            placeholder="Nhập email hoặc username"
            required
          />
          <Input
            name="password"
            label="Mật khẩu"
            type="password"
            required
          />
          
          <div className="auth-btn-group">
            <Button type="submit" isLoading={loading}>
              Đăng nhập
            </Button>
          </div>
          
          <div className="auth-footer-text">
            <span>Chưa có tài khoản?</span>
            <a href="/register" className="auth-footer-link">Tạo tài khoản ngay</a>
          </div>
        </form>
      </div>
    </div>
  )
}
