'use client'

import React, { useEffect, useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import confetti from 'canvas-confetti'
import { Turnstile } from '@marsidev/react-turnstile'

type VerifyState = 'loading' | 'checking-code' | 'ready' | 'verifying' | 'success' | 'error'

function VerifyContent() {
  const searchParams = useSearchParams()
  const code = searchParams.get('code')
  const router = useRouter()
  
  const [state, setState] = useState<VerifyState>('checking-code')
  const [errorMsg, setErrorMsg] = useState('')
  const [reward, setReward] = useState<number>(0)
  const [captchaToken, setCaptchaToken] = useState('')

  useEffect(() => {
    if (!code) {
      setState('error')
      setErrorMsg('Link không hợp lệ hoặc thiếu mã xác nhận.')
    } else {
      // Ở hệ thống thực tế có thể gọi GET /api/links/[code] để check trước
      // Ở đây rút gọn: check luôn ở bước verify.
      setState('ready')
    }
  }, [code])

  const handleVerify = async () => {
    if (!captchaToken) {
      setErrorMsg('Vui lòng hoàn thành CAPTCHA.')
      return
    }

    setState('verifying')
    try {
      const res = await fetch('/api/links/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ linkCode: code, captchaToken }),
      })
      const data = await res.json()

      if (data.success) {
        setReward(data.reward)
        setState('success')
        fireConfetti()
      } else {
        setState('error')
        setErrorMsg(data.error || 'Có lỗi xảy ra.')
      }
    } catch (err) {
      setState('error')
      setErrorMsg('Không thể kết nối đến máy chủ.')
    }
  }

  const fireConfetti = () => {
    const duration = 3000
    const end = Date.now() + duration

    const frame = () => {
      confetti({
        particleCount: 5,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ['#0066cc', '#ffffff', '#ffd700']
      })
      confetti({
        particleCount: 5,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ['#0066cc', '#ffffff', '#ffd700']
      })

      if (Date.now() < end) {
        requestAnimationFrame(frame)
      }
    }
    frame()
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#272729] text-white p-4">
      {state === 'ready' && (
        <div className="text-center w-full max-w-md animate-in zoom-in duration-500">
          <h1 className="text-display-md mb-2">Bảo vệ liên kết</h1>
          <p className="text-body-muted mb-8">Vui lòng xác minh để tiếp tục và nhận Cam thưởng.</p>
          
          <div className="bg-canvas text-ink p-6 rounded-[18px] shadow-lg flex flex-col items-center">
            <Turnstile 
              siteKey={process.env.NEXT_PUBLIC_CF_TURNSTILE_SITE_KEY!} 
              onSuccess={(token) => setCaptchaToken(token)}
            />
            <button 
              onClick={handleVerify}
              disabled={!captchaToken}
              className={`mt-6 w-full py-3 rounded-pill font-semibold transition-all ${
                captchaToken 
                  ? 'bg-primary text-white hover:scale-95' 
                  : 'bg-[#F3F4F6] text-[#8A919E] cursor-not-allowed'
              }`}
            >
              Xác minh & Nhận thưởng
            </button>
          </div>
        </div>
      )}

      {state === 'verifying' && (
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#333] border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-body-strong">Đang xử lý giao dịch...</p>
        </div>
      )}

      {state === 'success' && (
        <div className="text-center animate-in zoom-in duration-500">
          <h1 className="text-[64px] font-bold text-[#ffd700] mb-2 leading-none">
            +{reward.toFixed(2)}
          </h1>
          <p className="text-display-md mb-8">Cam đã được cộng!</p>
          
          <button 
            onClick={() => router.push('/dashboard')}
            className="bg-primary text-white px-8 py-3 rounded-pill text-body-strong hover:scale-95 transition-transform"
          >
            Về Dashboard
          </button>
        </div>
      )}

      {state === 'error' && (
        <div className="text-center max-w-md bg-canvas text-ink p-8 rounded-[18px]">
          <div className="w-16 h-16 bg-[var(--color-error-bg)] text-[var(--color-error)] rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
            !
          </div>
          <h2 className="text-display-md mb-2">Thất bại</h2>
          <p className="text-body-muted mb-6">{errorMsg}</p>
          <button 
            onClick={() => window.location.reload()}
            className="w-full py-3 border border-primary text-primary rounded-pill font-semibold hover:bg-primary hover:text-white transition-colors"
          >
            Thử lại
          </button>
        </div>
      )}
    </div>
  )
}

export default function VerifyPage() {
  return (
    <Suspense fallback={<div style={{ padding: '20px', textAlign: 'center', color: '#fff' }}>Đang tải dữ liệu...</div>}>
      <VerifyContent />
    </Suspense>
  )
}
