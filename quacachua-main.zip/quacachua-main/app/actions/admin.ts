'use server'

import { revalidatePath } from 'next/cache'
import { requireAdminUser } from '@/lib/authz'
import { atomicCamTransaction } from '@/lib/cam/transaction'
import { createAdminClient } from '@/lib/supabase/server'
import { headers } from 'next/headers'

function forbiddenResult(error: unknown) {
  if (error instanceof Error && (error.message === 'UNAUTHORIZED' || error.message === 'FORBIDDEN')) {
    return { error: 'Bạn không có quyền thực hiện thao tác này.' }
  }
  return null
}

async function auditAdmin(action: string, targetId: string | null, targetData: Record<string, unknown>) {
  const adminUser = await requireAdminUser()
  const headerStore = await headers()
  const supabaseAdmin = createAdminClient()
  await supabaseAdmin.rpc('write_admin_audit', {
    p_admin_id: adminUser.id,
    p_action: action,
    p_target_id: targetId,
    p_target_data: targetData,
    p_ip: headerStore.get('x-forwarded-for')?.split(',')[0] || headerStore.get('x-real-ip'),
    p_user_agent: headerStore.get('user-agent'),
  })
}

export async function adminListUsers() {
  try {
    await requireAdminUser()
    const supabaseAdmin = createAdminClient()
    const { data, error } = await supabaseAdmin
      .from('profiles')
      .select('id, username, display_name, email_canonical, role, cam_balance, is_banned, created_at')
      .order('created_at', { ascending: false })

    if (error) return { data: [], error: error.message }
    return { data: data || [], error: null }
  } catch (error) {
    const forbidden = forbiddenResult(error)
    return { data: [], error: forbidden?.error || 'Không thể tải danh sách người dùng.' }
  }
}

export async function adminListPendingTickets() {
  try {
    await requireAdminUser()
    const supabaseAdmin = createAdminClient()
    const { data, error } = await supabaseAdmin
      .from('redemptions')
      .select('*, profiles(username, display_name)')
      .eq('status', 'pending')
      .order('created_at', { ascending: true })

    if (error) return { data: [], error: error.message }
    return { data: data || [], error: null }
  } catch (error) {
    const forbidden = forbiddenResult(error)
    return { data: [], error: forbidden?.error || 'Không thể tải danh sách ticket.' }
  }
}

export async function adminCancelAllPendingTickets() {
  try {
    await requireAdminUser()
    const supabaseAdmin = createAdminClient()

    const { data: tickets, error: listError } = await supabaseAdmin
      .from('redemptions')
      .select('id')
      .eq('status', 'pending')

    if (listError) return { error: listError.message }

    const pendingIds = (tickets || []).map((t: any) => t.id)
    if (pendingIds.length === 0) {
      return { success: true, canceled: 0, refundedCam: 0 }
    }

    const { data, error } = await supabaseAdmin.rpc('cancel_all_pending_redemptions', {
      p_ticket_ids: pendingIds,
      p_admin_note: 'Hủy toàn bộ đợt duyệt. Hoàn tiền đầy đủ, không thu phí.',
    })

    if (error) {
      console.error('cancel_all_pending_redemptions error:', error)
      return { error: error.message }
    }

    await auditAdmin('redemption_cancel_all', null, { count: pendingIds.length, ...(data || {}) })
    revalidatePath('/dashboard/admin/tickets')
    return {
      success: true,
      canceled: Number(data?.canceled ?? 0),
      refundedCam: Number(data?.refunded_cam ?? 0),
    }
  } catch (error) {
    const forbidden = forbiddenResult(error)
    return { error: forbidden?.error || 'Không thể hủy toàn bộ ticket.' }
  }
}

export async function adminListProviders() {
  try {
    await requireAdminUser()
    const supabaseAdmin = createAdminClient()
    const { data, error } = await supabaseAdmin
      .from('earn_providers')
      .select('*')
      .order('created_at', { ascending: true })

    if (error) return { data: [], error: error.message }
    return { data: data || [], error: null }
  } catch (error) {
    const forbidden = forbiddenResult(error)
    return { data: [], error: forbidden?.error || 'Không thể tải danh sách nhà cung cấp.' }
  }
}

export async function adminUpdateProvider(
  providerId: string,
  payload: { reward_cam?: number; daily_limit?: number; api_url?: string; api_token?: string }
) {
  try {
    await requireAdminUser()
    const supabaseAdmin = createAdminClient()
    const { error } = await supabaseAdmin.from('earn_providers').update(payload).eq('id', providerId)
    if (error) return { error: error.message }
    await auditAdmin('provider_update', providerId, payload)
    revalidatePath('/dashboard/admin/providers')
    return { success: true }
  } catch (error) {
    const forbidden = forbiddenResult(error)
    return { error: forbidden?.error || 'Không thể cập nhật nhà cung cấp.' }
  }
}

export async function adminToggleProvider(providerId: string, isActive: boolean) {
  try {
    await requireAdminUser()
    const supabaseAdmin = createAdminClient()
    const { error } = await supabaseAdmin
      .from('earn_providers')
      .update({ is_active: isActive })
      .eq('id', providerId)
    if (error) return { error: error.message }
    await auditAdmin('provider_toggle', providerId, { isActive })
    revalidatePath('/dashboard/admin/providers')
    return { success: true }
  } catch (error) {
    const forbidden = forbiddenResult(error)
    return { error: forbidden?.error || 'Không thể cập nhật trạng thái nhà cung cấp.' }
  }
}

export async function processRedemptionTicket(
  ticketId: string,
  adminNote: string,
  status: 'completed' | 'rejected',
  applyFee: boolean = false
) {
  try {
    await requireAdminUser()
    const supabaseAdmin = createAdminClient()

    const { data: ticket, error: fetchError } = await supabaseAdmin
      .from('redemptions')
      .select('*')
      .eq('id', ticketId)
      .single()

    if (fetchError || !ticket) {
      return { error: 'Không tìm thấy ticket.' }
    }

    if (ticket.status !== 'pending') {
      return { error: 'Ticket này đã được xử lý.' }
    }

    const { data: profile } = await supabaseAdmin
      .from('profiles')
      .select('username')
      .eq('id', ticket.user_id)
      .single()

    const { error: decisionError } = await supabaseAdmin.rpc('process_redemption_decision', {
      p_ticket_id: ticketId,
      p_status: status,
      p_admin_note: adminNote || null,
      p_apply_fee: applyFee,
    })

    if (decisionError) {
      return { error: 'Lỗi khi cập nhật ticket.' }
    }
    await auditAdmin('redemption_decision', ticketId, { status, applyFee, adminNote })

    if (status === 'completed') {
      const { data: txList } = await supabaseAdmin
        .from('cam_transactions')
        .select('id')
        .eq('user_id', ticket.user_id)
        .eq('type', 'redeem')
        .order('created_at', { ascending: false })
        .limit(1)

      if (txList && txList.length > 0) {
        let txDesc = ''
        if (ticket.type === 'phone_card' || ticket.type === 'game_card') {
          txDesc = `Rút thẻ ${ticket.amount_vnd.toLocaleString('vi-VN')}đ thành công. Ghi chú: ${adminNote}`
        } else {
          txDesc = `Rút tiền ${ticket.amount_vnd.toLocaleString('vi-VN')}đ thành công. ${
            adminNote ? 'Ghi chú: ' + adminNote : 'Đã chuyển khoản'
          }`
        }

        await supabaseAdmin.from('cam_transactions').update({ description: txDesc }).eq('id', txList[0].id)
      }

      try {
        const typeStr =
          ticket.type === 'bank'
            ? 'Bank'
            : `The Cao - ${ticket.details?.provider} ${ticket.amount_vnd.toLocaleString('vi-VN')}d`
        const username = profile?.username || 'Unknown'
        const processTime = new Date().toLocaleString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh' })

        const webhookUrl =
          'https://discord.com/api/webhooks/1523350842306986065/dVP-0X4ETpKeakf-of0nrxTx2RXXovE_kYF_yjwIpT538NyH6T2Rj3Xzv0RsDt8xfKwJ'
        const content = `Tên người dùng được xử lý: ${username}\nLoại: ${typeStr}\nThời gian xử lý: ${processTime}`

        await fetch(webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ content }),
        })
      } catch (e) {
        console.error('Lỗi khi gửi webhook Discord:', e)
      }
    }

    if (ticket.details?.qrCodeUrl) {
      try {
        // qrCodeUrl luc nay la fileName (path) trong bucket, khong phai public URL
        const fileName = ticket.details.qrCodeUrl
        await supabaseAdmin.storage.from('qrcodes').remove([fileName])
      } catch (e) {
        console.error('Lỗi khi xóa ảnh QR code', e)
      }
    }

    revalidatePath('/dashboard/admin/tickets')
    return { success: true }
  } catch (error) {
    const forbidden = forbiddenResult(error)
    return { error: forbidden?.error || 'Không thể xử lý ticket.' }
  }
}

export async function adminUpdateUserBalance(userId: string, changeAmount: number, reason: string) {
  try {
    await requireAdminUser()
    const supabaseAdmin = createAdminClient()

    const tx = await atomicCamTransaction({
      userId,
      type: changeAmount >= 0 ? 'admin_adjust_add' : 'admin_adjust_sub',
      amount: Math.abs(changeAmount),
      description: `Admin dieu chinh: ${reason}`,
    })

    if (!tx.success) {
      return { error: tx.error || 'Không thể cập nhật số dư.' }
    }
    await auditAdmin('user_balance_adjust', userId, { changeAmount, reason })

    await supabaseAdmin.from('notifications').insert({
      user_id: userId,
      title: changeAmount >= 0 ? 'Nhận thêm Cam' : 'Bị trừ Cam',
      body: `Tài khoản của bạn vừa được Admin ${changeAmount >= 0 ? 'cộng thêm' : 'trừ đi'} ${Math.abs(
        changeAmount
      )} Cam. Lý do: ${reason}`,
    })

    revalidatePath('/dashboard/admin/users')
    return { success: true }
  } catch (error) {
    const forbidden = forbiddenResult(error)
    return { error: forbidden?.error || 'Không thể cập nhật số dư.' }
  }
}

export async function adminGetUserTransactions(userId: string) {
  try {
    await requireAdminUser()
    const supabaseAdmin = createAdminClient()
    const { data, error } = await supabaseAdmin
      .from('cam_transactions')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(50)

    if (error) return { data: null, error: error.message }
    return { data, error: null }
  } catch (error) {
    const forbidden = forbiddenResult(error)
    return { data: null, error: forbidden?.error || 'Không thể tải lịch sử giao dịch.' }
  }
}

async function fetchStatistics() {
  const supabaseAdmin = createAdminClient()

  const { data, error } = await supabaseAdmin.rpc('get_earn_statistics')
  const { data: paidData, error: paidError } = await supabaseAdmin.rpc('get_paid_redemption_stats')

  if (error || !data) {
    console.error('[fetchStatistics] RPC error:', error)
    return { totalUsers: 0, totalCirculating: 0, shortlinkStats: [], totalEarnCompletions: 0, totalEarnCam: 0, totalPaidVnd: 0, cardPaidVnd: 0, bankPaidVnd: 0 }
  }

  return {
    totalUsers: data.totalUsers ?? 0,
    totalCirculating: Number(data.totalCirculating ?? 0),
    totalEarnCompletions: data.totalEarnCompletions ?? 0,
    totalEarnCam: Number(data.totalEarnCam ?? 0),
    shortlinkStats: (data.shortlinkStats || []) as { code: string; name: string; count: number; totalCam: number }[],
    totalPaidVnd: paidError || !paidData ? 0 : Number(paidData.total_paid_vnd ?? 0),
    cardPaidVnd: paidError || !paidData ? 0 : Number(paidData.card_paid_vnd ?? 0),
    bankPaidVnd: paidError || !paidData ? 0 : Number(paidData.bank_paid_vnd ?? 0),
  }
}

export async function adminGetStatistics() {
  try {
    await requireAdminUser()
    return await fetchStatistics()
  } catch {
    return { totalUsers: 0, totalCirculating: 0, shortlinkStats: [], totalEarnCompletions: 0, totalEarnCam: 0, totalPaidVnd: 0, cardPaidVnd: 0, bankPaidVnd: 0 }
  }
}

export async function adminGetPaidStats() {
  try {
    await requireAdminUser()
    const supabaseAdmin = createAdminClient()
    const { data, error } = await supabaseAdmin.rpc('get_paid_redemption_stats')
    if (error || !data) return { totalPaidVnd: 0, cardPaidVnd: 0, bankPaidVnd: 0 }
    return {
      totalPaidVnd: Number(data.total_paid_vnd ?? 0),
      cardPaidVnd: Number(data.card_paid_vnd ?? 0),
      bankPaidVnd: Number(data.bank_paid_vnd ?? 0),
    }
  } catch {
    return { totalPaidVnd: 0, cardPaidVnd: 0, bankPaidVnd: 0 }
  }
}

export async function getPublicStatistics() {
  return await fetchStatistics()
}

export type CamRevokeSource = 'nhapma' | 'layma'

export async function adminListRevokeBatches() {
  try {
    await requireAdminUser()
    const supabaseAdmin = createAdminClient()
    const { data, error } = await supabaseAdmin
      .from('cam_revoke_batches')
      .select('*')
      .order('created_at', { ascending: false })

    if (error) return { data: [], error: error.message }
    return { data: data || [], error: null }
  } catch (error) {
    const forbidden = forbiddenResult(error)
    return { data: [], error: forbidden?.error || 'Không thể tải danh sách lệnh xóa Cam.' }
  }
}

export async function adminRevokeSourceCam(source: CamRevokeSource) {
  try {
    const adminUser = await requireAdminUser()
    const supabaseAdmin = createAdminClient()

    const { data, error } = await supabaseAdmin.rpc('admin_revoke_source_cam', {
      p_source: source,
      p_admin_id: adminUser.id,
    })

    if (error) {
      if (error.message === 'ACTIVE_BATCH_EXISTS') {
        return { error: `Đã có lệnh xóa Cam ${source} chưa hoàn. Hãy bấm "Hoàn" trước khi xóa lại.` }
      }
      return { error: error.message }
    }
    await auditAdmin('cam_revoke', data?.batch_id || null, { source, ...(data || {}) })
    revalidatePath('/dashboard/admin/xoa-cam')
    return { success: true, data }
  } catch (error) {
    const forbidden = forbiddenResult(error)
    return { error: forbidden?.error || 'Không thể xóa Cam.' }
  }
}

export async function adminRestoreSourceCam(batchId: string) {
  try {
    const adminUser = await requireAdminUser()
    const supabaseAdmin = createAdminClient()

    const { data, error } = await supabaseAdmin.rpc('admin_restore_source_cam', {
      p_batch_id: batchId,
      p_admin_id: adminUser.id,
    })

    if (error) {
      if (error.message === 'BATCH_ALREADY_RESTORED') {
        return { error: 'Lệnh xóa Cam này đã được hoàn trước đó.' }
      }
      return { error: error.message }
    }
    await auditAdmin('cam_restore', batchId, data || {})
    revalidatePath('/dashboard/admin/xoa-cam')
    return { success: true, data }
  } catch (error) {
    const forbidden = forbiddenResult(error)
    return { error: forbidden?.error || 'Không thể hoàn Cam.' }
  }
}

export async function adminDeleteRevokeBatch(batchId: string) {
  try {
    const adminUser = await requireAdminUser()
    const supabaseAdmin = createAdminClient()

    const { data, error } = await supabaseAdmin.rpc('admin_delete_revoke_batch', {
      p_batch_id: batchId,
    })

    if (error) {
      if (error.message === 'BATCH_ALREADY_RESTORED') {
        return { error: 'Lệnh này đã được hoàn nên không thể xóa hẳn.' }
      }
      return { error: error.message }
    }
    await auditAdmin('cam_revoke_delete', batchId, data || {})
    revalidatePath('/dashboard/admin/xoa-cam')
    return { success: true, data }
  } catch (error) {
    const forbidden = forbiddenResult(error)
    return { error: forbidden?.error || 'Không thể xóa hẳn lệnh này.' }
  }
}
