'use server'

import { getAuthenticatedUser } from '@/lib/authz'
import { createAdminClient } from '@/lib/supabase/server'

export async function getCurrentProfileAction() {
  const user = await getAuthenticatedUser()
  if (!user) return { error: 'UNAUTHORIZED' }

  const supabaseAdmin = createAdminClient()
  const { data, error } = await supabaseAdmin
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .maybeSingle()

  if (error) {
    console.error('[PROFILE] Failed to load current profile', error)
    return { error: 'Không thể tải thông tin tài khoản.' }
  }

  if (!data) return { error: 'PROFILE_NOT_FOUND' }

  return { data }
}
