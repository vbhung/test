'use server'

import { revalidatePath } from 'next/cache'
import { z } from 'zod'
import { getAuthenticatedUser } from '@/lib/authz'
import { createAdminClient, createClient } from '@/lib/supabase/server'

const updateProfileSchema = z.object({
  displayName: z.string().min(2, 'Họ và tên phải từ 2 ký tự').max(100),
})

export async function updateProfileAction(displayName: string) {
  try {
    const user = await getAuthenticatedUser()
    if (!user) return { error: 'Không thể xác thực.' }

    const parsed = updateProfileSchema.safeParse({ displayName })
    if (!parsed.success) {
      return { error: parsed.error.issues?.[0]?.message || 'Dữ liệu không hợp lệ.' }
    }

    const supabaseAdmin = createAdminClient()
    const { error } = await supabaseAdmin
      .from('profiles')
      .update({ display_name: parsed.data.displayName, updated_at: new Date().toISOString() })
      .eq('id', user.id)

    if (error) return { error: 'Không thể cập nhật hồ sơ.' }

    revalidatePath('/dashboard')
    revalidatePath('/dashboard/settings')
    return { success: true }
  } catch {
    return { error: 'Có lỗi xảy ra khi lưu.' }
  }
}

const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, 'Vui lòng nhập mật khẩu hiện tại'),
  newPassword: z.string().min(8, 'Mật khẩu mới phải từ 8 ký tự'),
})

export async function changePasswordAction(currentPassword: string, newPassword: string) {
  try {
    const user = await getAuthenticatedUser()
    if (!user) return { error: 'Không thể xác thực.' }

    const parsed = changePasswordSchema.safeParse({ currentPassword, newPassword })
    if (!parsed.success) {
      return { error: parsed.error.issues?.[0]?.message || 'Dữ liệu không hợp lệ.' }
    }

    const supabase = createClient()
    // Verify mat khau hien tai
    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: user.email ?? '',
      password: currentPassword,
    })
    if (signInError) {
      return { error: 'Mật khẩu hiện tại không chính xác.' }
    }

    // Doi mat khau
    const { error: updateError } = await supabase.auth.updateUser({ password: newPassword })
    if (updateError) {
      return { error: updateError.message || 'Không thể đổi mật khẩu.' }
    }

    return { success: true }
  } catch {
    return { error: 'Có lỗi xảy ra khi đổi mật khẩu.' }
  }
}
