'use server'

import { createAdminClient, createClient } from '@/lib/supabase/server'
import { revalidatePath } from 'next/cache'

export async function deleteUserAccount() {
  const supabase = createClient()
  const supabaseAdmin = createAdminClient()

  const { data: { user }, error: authError } = await supabase.auth.getUser()
  if (authError || !user) {
    return { error: 'Khong the xac thuc.' }
  }

  const transferDeleteCooldownStart = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()
  const { count: recentTransferOutCount, error: transferCheckError } = await supabaseAdmin
    .from('cam_transactions')
    .select('id', { count: 'exact', head: true })
    .eq('user_id', user.id)
    .eq('type', 'transfer_out')
    .gte('created_at', transferDeleteCooldownStart)

  if (transferCheckError) {
    console.error('[DELETE_ACCOUNT] Failed to check recent transfer activity:', transferCheckError)
    return { error: 'Khong the kiem tra dieu kien xoa tai khoan. Vui long thu lai sau.' }
  }

  if ((recentTransferOutCount || 0) > 0) {
    return { error: 'Ban vua chuyen Cam trong 24 gio qua. Vui long cho du 1 ngay sau lan chuyen gan nhat roi moi xoa tai khoan.' }
  }

  try {
    const { data: tickets } = await supabaseAdmin
      .from('redemptions')
      .select('details')
      .eq('user_id', user.id)
      .eq('type', 'bank')

    const qrFiles: string[] = []
    for (const ticket of tickets || []) {
      const fileName = ticket.details?.qrCodeUrl
      if (fileName && typeof fileName === 'string') qrFiles.push(fileName)
    }
    if (qrFiles.length > 0) {
      await supabaseAdmin.storage.from('qrcodes').remove(qrFiles)
    }
  } catch (error) {
    console.error('Failed to remove QR files during account deletion:', error)
  }

  await supabaseAdmin.from('registration_limits').update({ deleted_at: new Date().toISOString() }).eq('user_id', user.id)
  const { error: deleteAuthError } = await supabaseAdmin.auth.admin.deleteUser(user.id)
  if (deleteAuthError) {
    return { error: deleteAuthError.message || 'Co loi xay ra khi xoa tai khoan.' }
  }

  revalidatePath('/')
  return { success: true }
}
