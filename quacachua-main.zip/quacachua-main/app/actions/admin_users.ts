'use server'

import { revalidatePath } from 'next/cache'
import { requireAdminUser } from '@/lib/authz'
import { createAdminClient } from '@/lib/supabase/server'
import { headers } from 'next/headers'

function forbiddenResult(error: unknown) {
  if (error instanceof Error && (error.message === 'UNAUTHORIZED' || error.message === 'FORBIDDEN')) {
    return { error: 'Bạn không có quyền thực hiện thao tác này.' }
  }
  return null
}

async function audit(action: string, targetId: string, data: Record<string, unknown>) {
  const admin = await requireAdminUser()
  const h = await headers()
  await createAdminClient().rpc('write_admin_audit', {
    p_admin_id: admin.id, p_action: action, p_target_id: targetId, p_target_data: data,
    p_ip: h.get('x-forwarded-for')?.split(',')[0] || h.get('x-real-ip'), p_user_agent: h.get('user-agent'),
  })
}

export async function adminBanUser(
  userId: string,
  banType: 'permanent' | 'temporary',
  banReason: string,
  banUntilDays?: number
) {
  try {
    await requireAdminUser()
    const supabaseAdmin = createAdminClient()

    let banUntil = null
    if (banType === 'temporary' && banUntilDays) {
      const d = new Date()
      d.setDate(d.getDate() + banUntilDays)
      banUntil = d.toISOString()
    }

    const { error } = await supabaseAdmin.auth.admin.updateUserById(userId, {
      user_metadata: {
        is_banned: true,
        ban_type: banType,
        ban_reason: banReason,
        ban_until: banUntil,
      },
    })

    if (error) return { error: 'Lỗi khi ban user: ' + error.message }

    await supabaseAdmin.from('profiles').update({ is_banned: true }).eq('id', userId)
    await audit('user_ban', userId, { banType, banReason, banUntil })

    revalidatePath('/dashboard/admin/users')
    return { success: true }
  } catch (error) {
    const forbidden = forbiddenResult(error)
    return { error: forbidden?.error || 'Không thể khóa tài khoản.' }
  }
}

export async function adminUnbanUser(userId: string) {
  try {
    await requireAdminUser()
    const supabaseAdmin = createAdminClient()

    const { error } = await supabaseAdmin.auth.admin.updateUserById(userId, {
      user_metadata: {
        is_banned: false,
        ban_type: null,
        ban_reason: null,
        ban_until: null,
      },
    })

    if (error) return { error: 'Lỗi khi gỡ ban user: ' + error.message }

    await supabaseAdmin.from('profiles').update({ is_banned: false }).eq('id', userId)
    await audit('user_unban', userId, {})

    revalidatePath('/dashboard/admin/users')
    return { success: true }
  } catch (error) {
    const forbidden = forbiddenResult(error)
    return { error: forbidden?.error || 'Không thể mở khóa tài khoản.' }
  }
}

export async function adminDeleteUser(userId: string) {
  try {
    await requireAdminUser()
    const supabaseAdmin = createAdminClient()

    // Xoa QR codes cua user (khong co FK)
    try {
      const { data: tickets } = await supabaseAdmin
        .from('redemptions')
        .select('details')
        .eq('user_id', userId)
        .eq('type', 'bank')
      const qrFiles: string[] = []
      for (const t of tickets || []) {
        const fileName = t.details?.qrCodeUrl
        if (fileName && typeof fileName === 'string') qrFiles.push(fileName)
      }
      if (qrFiles.length > 0) {
        await supabaseAdmin.storage.from('qrcodes').remove(qrFiles)
      }
    } catch (e) {
      console.error('Lỗi xóa QR storage:', e)
    }

    // Xoa auth user -> cascade qua profiles + tat ca bang
    // (Can chay migration_cascade.sql truoc)
    await supabaseAdmin.from('registration_limits').update({ deleted_at: new Date().toISOString() }).eq('user_id', userId)
    await audit('user_delete', userId, {})
    const { error: deleteAuthError } = await supabaseAdmin.auth.admin.deleteUser(userId)
    if (deleteAuthError) {
      return { error: 'Lỗi khi xóa Auth User: ' + deleteAuthError.message }
    }

    revalidatePath('/dashboard/admin/users')
    return { success: true }
  } catch (error: any) {
    const forbidden = forbiddenResult(error)
    return { error: forbidden?.error || 'Lỗi hệ thống: ' + error.message }
  }
}
