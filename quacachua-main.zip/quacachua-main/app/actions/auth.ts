'use server'

import { normalizeGmail } from '@/lib/email/normalize'
import { kv } from '@/lib/kv'
import { checkRateLimit, getIp } from '@/lib/ratelimit'
import { normalizeDeviceId, findRegistrationConflict } from '@/lib/security/registration'
import { generateSecureToken } from '@/lib/tokens/crypto'
import { verifyTurnstile } from '@/lib/captcha/turnstile'
import { checkVietnameseIp } from '@/lib/security/vpn-check'
import { createAdminClient, createClient } from '@/lib/supabase/server'
import { ensureUserProfile } from '@/lib/auth/profile'
import { z } from 'zod'

function normalizeLoginIdentifier(value: FormDataEntryValue | null) {
  return typeof value === 'string' ? value.trim() : ''
}

function normalizeUsernameIdentifier(value: string) {
  return value.trim().replace(/^@+/, '').toLowerCase()
}

export async function checkEmailAction(email: string) {
  const ip = await getIp()

  const rl = await checkRateLimit('check-email', 10, 3600, ip)
  if (!rl.success) return { error: 'Thao tác quá nhanh. Vui lòng thử lại sau.' }

  const canonical = normalizeGmail(email)
  if (!canonical) {
    return { error: 'Chỉ hỗ trợ địa chỉ email Gmail.' }
  }

  const checkToken = generateSecureToken(16)
  await kv.set(
    `register:check:${checkToken}`,
    {
      canonical,
      ip,
    },
    { ex: 3600 }
  )

  return { success: true, checkToken }
}

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8, 'Mật khẩu phải từ 8 ký tự trở lên'),
  displayName: z.string().min(2, 'Họ và tên phải từ 2 ký tự trở lên'),
  username: z
    .string()
    .min(3, 'Username phải từ 3 ký tự trở lên')
    .regex(/^[a-zA-Z0-9_]+$/, 'Username chỉ được chứa chữ cái, số và dấu gạch dưới'),
  captchaToken: z.string().min(1, 'Lỗi Captcha: Rỗng'),
  referralCode: z.string().nullish().or(z.literal('')),
  checkToken: z.string().min(10, 'Phiên đăng ký không hợp lệ.'),
  deviceId: z.string().min(16, 'Thiết bị không hợp lệ.'),
  browserId: z.string().min(16, 'Trình duyệt không hợp lệ.'),
})

export async function registerAction(formData: FormData) {
  const ip = await getIp()

  const countryCheck = checkVietnameseIp()
  if (!countryCheck.allowed) {
    return { error: 'Quả Cà Chua chỉ hỗ trợ người dùng tại Việt Nam.' }
  }

  const rl = await checkRateLimit('register', 5, 3600, ip)
  if (!rl.success) return { error: 'Đăng ký quá nhiều lần. Vui lòng thử lại sau.' }

  const data = {
    email: formData.get('email') as string,
    password: formData.get('password') as string,
    displayName: formData.get('displayName') as string,
    username: formData.get('username') as string,
    captchaToken: formData.get('captchaToken') as string,
    referralCode: formData.get('referralCode') as string | undefined,
    checkToken: formData.get('checkToken') as string,
    deviceId: formData.get('deviceId') as string,
    browserId: formData.get('browserId') as string,
  }

  const parsed = registerSchema.safeParse(data)
  if (!parsed.success) {
    const issue = parsed.error.issues?.[0]
    return { error: issue?.message || 'Dữ liệu không hợp lệ.' }
  }

  const { email, password, displayName, username, captchaToken, referralCode, checkToken, deviceId, browserId } = parsed.data
  const canonical = normalizeGmail(email)
  const normalizedDeviceId = normalizeDeviceId(deviceId)
  const normalizedBrowserId = normalizeDeviceId(browserId)
  if (!canonical || !normalizedDeviceId || !normalizedBrowserId) {
    return { error: 'Dữ liệu đăng ký không hợp lệ.' }
  }

  const checkSession = await kv.get<{ canonical: string; ip: string }>(`register:check:${checkToken}`)
  if (!checkSession || checkSession.canonical !== canonical || checkSession.ip !== ip) {
    return { error: 'Phiên đăng ký đã hết hạn hoặc không hợp lệ. Vui lòng thử lại từ đầu.' }
  }

  const supabase = createClient()
  const supabaseAdmin = createAdminClient()

  const { data: existing } = await supabaseAdmin
    .from('profiles')
    .select('id')
    .eq('email_canonical', canonical)
    .maybeSingle()
  if (existing) return { error: 'Không thể tạo tài khoản với email này.' }

  const { data: existingUsername } = await supabaseAdmin
    .from('profiles')
    .select('id')
    .ilike('username', username)
    .maybeSingle()
  if (existingUsername) return { error: 'Tên đăng nhập (Username) đã có người sử dụng.' }

  let referrerId: string | null = null
  if (referralCode) {
    const { data: referrer } = await supabaseAdmin
      .from('profiles')
      .select('id')
      .eq('referral_code', referralCode.toUpperCase())
      .maybeSingle()
    if (!referrer) return { error: 'Mã mời không tồn tại hoặc không hợp lệ.' }
    referrerId = referrer.id
  }

  try {
    const registrationConflict = await findRegistrationConflict(ip, normalizedDeviceId, normalizedBrowserId)
    if (registrationConflict.conflict) {
      return { error: 'Mỗi IP và thiết bị chỉ được đăng ký 1 tài khoản duy nhất.' }
    }
  } catch (error) {
    console.error('[REGISTER] Failed to verify registration limit', error)
    return { error: 'Hệ thống không thể xác minh giới hạn đăng ký.' }
  }

  const captchaOk = await verifyTurnstile(captchaToken, ip)
  if (!captchaOk) return { error: 'Xác minh CAPTCHA thất bại hoặc đã hết hạn.' }
  const { data: authData, error: authError } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: `${process.env.NEXT_PUBLIC_APP_URL}/auth/callback`,
      data: {
        registration_username: username.toLowerCase(),
        registration_display_name: displayName,
        registration_email_canonical: canonical,
        registration_referrer_id: referrerId,
      },
    },
  })

  if (authError || !authData.user) {
    console.error('Supabase SignUp Error:', authError)
    return { error: authError?.message || 'Lỗi hệ thống khi khởi tạo tài khoản. Vui lòng thử lại.' }
  }

  try {
    const registrationLimit = await findRegistrationConflict(ip, normalizedDeviceId, normalizedBrowserId)
    if (registrationLimit.conflict) {
      await supabaseAdmin.auth.admin.deleteUser(authData.user.id)
      return { error: 'Mỗi IP và thiết bị chỉ được đăng ký 1 tài khoản duy nhất.' }
    }

    const { error: limitError } = await supabaseAdmin.from('registration_limits').insert({
      user_id: authData.user.id,
      ip_hash: registrationLimit.ipHash,
      device_hash: registrationLimit.deviceHash,
      status: 'pending',
    })

    if (limitError) {
      await supabaseAdmin.auth.admin.deleteUser(authData.user.id)
      return { error: 'IP hoặc thiết bị này đã được dùng đăng ký trước đó.' }
    }

    await kv.set(
      `register:pending:${authData.user.id}`,
      {
        canonical,
        referrerId,
        displayName,
        username: username.toLowerCase(),
        ip,
        deviceId: normalizedDeviceId,
      },
      { ex: 7 * 24 * 3600 }
    )
    await kv.del(`register:check:${checkToken}`)
  } catch (error) {
    console.error('[REGISTER] Failed to create pending registration', error)
    await supabaseAdmin.auth.admin.deleteUser(authData.user.id)
    return { error: 'Không thể hoàn tất đăng ký. Vui lòng thử lại.' }
  }

  return { success: true }
}

export async function loginAction(formData: FormData) {
  const ip = await getIp()
  const rl = await checkRateLimit('login', 10, 3600, ip)
  if (!rl.success) return { error: 'Thử lại quá nhiều. Vui lòng quay lại sau.' }

  const identifier = normalizeLoginIdentifier(formData.get('email'))
  const password = normalizeLoginIdentifier(formData.get('password'))

  if (!identifier || !password) return { error: 'Vui lòng điền đầy đủ email và mật khẩu.' }

  let emailToLogin = identifier
  const supabase = createClient()

  if (!identifier.includes('@') || identifier.startsWith('@')) {
    const username = normalizeUsernameIdentifier(identifier)
    if (!username) return { error: 'Tên đăng nhập không tồn tại.' }

    const supabaseAdmin = createAdminClient()
    const { data: profile, error: profileError } = await supabaseAdmin
      .from('profiles')
      .select('id, email_canonical')
      .ilike('username', username)
      .maybeSingle()

    if (profileError) {
      console.error('[LOGIN] Failed to lookup username', profileError)
      return { error: 'Không thể kiểm tra tên đăng nhập. Vui lòng thử lại.' }
    }

    if (!profile) return { error: 'Tên đăng nhập không tồn tại.' }

    const { data: authUser, error: authUserError } = await supabaseAdmin.auth.admin.getUserById(profile.id)
    if (authUserError) {
      console.error('[LOGIN] Failed to resolve auth email for username', authUserError)
    }

    emailToLogin = authUser.user?.email || profile.email_canonical
    if (!emailToLogin) return { error: 'Tài khoản này chưa có email đăng nhập hợp lệ.' }
  }

  const { data: authData, error } = await supabase.auth.signInWithPassword({
    email: emailToLogin,
    password,
  })

  if (error) {
    const msg = error.message.toLowerCase()
    if (msg.includes('email not confirmed') || msg.includes('unverified')) {
      return { error: 'Vui lòng kiểm tra hộp thư email để xác nhận tài khoản trước khi đăng nhập.' }
    }
    return { error: 'Email hoặc mật khẩu không chính xác.' }
  }

  if (authData.user) {
    const supabaseAdmin = createAdminClient()
    const profileResult = await ensureUserProfile(supabaseAdmin, authData.user)
    if (!profileResult.profile) {
      console.error('[LOGIN] Failed to ensure user profile', profileResult.error)
      await supabase.auth.signOut()
      if (profileResult.code === 'email_canonical_exists') {
        return { error: 'Email này đã được gắn với tài khoản khác.' }
      }
      return { error: 'Không thể tải hồ sơ tài khoản. Vui lòng liên hệ quản trị viên.' }
    }
  }

  if (authData.user?.user_metadata?.is_banned) {
    const meta = authData.user.user_metadata
    if (meta.ban_type === 'permanent') {
      await supabase.auth.signOut()
      return { error: `Tài khoản của bạn đã bị khóa vĩnh viễn. Lý do: ${meta.ban_reason}` }
    } else if (meta.ban_until && new Date() < new Date(meta.ban_until)) {
      await supabase.auth.signOut()
      return {
        error: `Tài khoản của bạn đang bị khóa tạm thời đến ${new Date(meta.ban_until).toLocaleString(
          'vi-VN'
        )}. Lý do: ${meta.ban_reason}`,
      }
    } else {
      const supabaseAdmin = createAdminClient()
      await supabaseAdmin.auth.admin.updateUserById(authData.user.id, {
        user_metadata: { is_banned: false, ban_type: null, ban_reason: null, ban_until: null },
      })
      await supabaseAdmin.from('profiles').update({ is_banned: false }).eq('id', authData.user.id)
    }
  }

  return { success: true }
}
