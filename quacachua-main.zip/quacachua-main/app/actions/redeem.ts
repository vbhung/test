'use server'

import { revalidatePath } from 'next/cache'
import { z } from 'zod'
import { requireAuthenticatedUser } from '@/lib/authz'
import { verifyTurnstile } from '@/lib/captcha/turnstile'
import { createAdminClient } from '@/lib/supabase/server'

const REDEEM_COOLDOWN_HOURS = 12

const bankDetailsSchema = z.object({
  info: z.string().max(500).optional().default(''),
  qrCodeUrl: z.string().max(300).optional(),
})

const cardDetailsSchema = z.object({
  provider: z.string().min(1).max(50),
  denomination: z.number().int().positive(),
})

const redeemInputSchema = z.object({
  type: z.enum(['phone_card', 'game_card', 'bank']),
  amountCam: z.number().positive(),
  amountVnd: z.number().int().positive(),
  captchaToken: z.string().min(10),
  details: z.unknown(),
})

function getRequiredQualifiedReferrals(amountVnd: number) {
  if (amountVnd <= 50000) return 1
  if (amountVnd <= 100000) return 3
  if (amountVnd <= 500000) return 5
  return 10
}

function formatCooldownTime(ms: number) {
  const totalMinutes = Math.max(1, Math.ceil(ms / 60000))
  const hours = Math.floor(totalMinutes / 60)
  const minutes = totalMinutes % 60

  if (hours <= 0) return `${minutes} phút`
  if (minutes <= 0) return `${hours} giờ`
  return `${hours} giờ ${minutes} phút`
}

export async function createRedeemTicket(input: {
  type: 'phone_card' | 'game_card' | 'bank'
  amountCam: number
  amountVnd: number
  details: unknown
  captchaToken: string
}) {
  try {
    const parsed = redeemInputSchema.safeParse(input)
    if (!parsed.success) {
      return { error: parsed.error.issues?.[0]?.message || 'Dữ liệu không hợp lệ.' }
    }
    const { type, amountCam, details, captchaToken } = parsed.data

    // Validate min amount (10 Cam cho bank; card thi amountCam = ceil(denomination/rate) da >= 1)
    if (type === 'bank' && amountCam < 10) {
      return { error: 'Số tiền rút tối thiểu là 10 Cam.' }
    }

    // Verify CAPTCHA server-side
    const captchaOk = await verifyTurnstile(captchaToken)
    if (!captchaOk) {
      return { error: 'Xác minh CAPTCHA thất bại.' }
    }

    // Validate details theo type
    let cleanDetails: Record<string, unknown> = {}
    if (type === 'bank') {
      const d = bankDetailsSchema.safeParse(details)
      if (!d.success) {
        return { error: 'Thông tin ngân hàng không hợp lệ.' }
      }
      cleanDetails = { info: d.data.info }
      if (d.data.qrCodeUrl) cleanDetails.qrCodeUrl = d.data.qrCodeUrl
      if (!cleanDetails.info && !cleanDetails.qrCodeUrl) {
        return { error: 'Vui lòng nhập thông tin ngân hàng hoặc tải QR.' }
      }
    } else {
      const d = cardDetailsSchema.safeParse(details)
      if (!d.success) {
        return { error: 'Thông tin thẻ không hợp lệ.' }
      }
      cleanDetails = { provider: d.data.provider, denomination: d.data.denomination }
    }

    const user = await requireAuthenticatedUser()
    const supabaseAdmin = createAdminClient()

    const cooldownSince = new Date(Date.now() - REDEEM_COOLDOWN_HOURS * 60 * 60 * 1000)
    const { data: latestRedeem, error: latestRedeemError } = await supabaseAdmin
      .from('redemptions')
      .select('created_at')
      .eq('user_id', user.id)
      .neq('status', 'rejected')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle()

    if (latestRedeemError) {
      console.error('[REDEEM] Failed to check cooldown:', latestRedeemError)
      return { error: 'Không thể kiểm tra thời gian chờ rút thưởng.' }
    }

    if (latestRedeem?.created_at) {
      const latestRedeemAt = new Date(latestRedeem.created_at)
      if (latestRedeemAt > cooldownSince) {
        const nextRedeemAt = latestRedeemAt.getTime() + REDEEM_COOLDOWN_HOURS * 60 * 60 * 1000
        return { error: `Bạn vừa tạo yêu cầu rút gần đây. Vui lòng chờ thêm ${formatCooldownTime(nextRedeemAt - Date.now())} rồi rút tiếp.` }
      }
    }

    let hasFreeRedeem = false
    if (type === 'phone_card' || type === 'game_card') {
      hasFreeRedeem = true
    } else if (type === 'bank') {
      const { count: usedBankRedeems, error: bankCountError } = await supabaseAdmin
        .from('redemptions')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('type', 'bank')
        .neq('status', 'rejected')

      if (bankCountError) {
        console.error('[REDEEM] Failed to count bank redemptions:', bankCountError)
        return { error: 'Không thể kiểm tra lượt rút ngân hàng miễn điều kiện.' }
      }

      hasFreeRedeem = (usedBankRedeems || 0) < 3
    }

    if (!hasFreeRedeem) {
      const requestedVnd = type === 'bank'
        ? amountCam * (cleanDetails.qrCodeUrl ? 220 : 200)
        : Number((cleanDetails as { denomination?: number }).denomination || 0)
      const requiredReferrals = getRequiredQualifiedReferrals(requestedVnd)
      const { data: referredProfiles, error: referredProfilesError } = await supabaseAdmin
        .from('profiles')
        .select('id')
        .eq('referred_by', user.id)

      if (referredProfilesError) {
        console.error('[REDEEM] Failed to fetch referred profiles:', referredProfilesError)
        return { error: 'Không thể kiểm tra điều kiện mời bạn.' }
      }

      const referredIds = (referredProfiles || []).map((profile) => profile.id)
      let qualifiedReferralCount = 0

      if (referredIds.length > 0) {
        const { data: completedReferralTasks, error: completedReferralTasksError } = await supabaseAdmin
          .from('earn_tasks')
          .select('user_id')
          .in('user_id', referredIds)
          .eq('status', 'completed')

        if (completedReferralTasksError) {
          console.error('[REDEEM] Failed to count qualified referrals:', completedReferralTasksError)
          return { error: 'Không thể kiểm tra nhiệm vụ của người được mời.' }
        }

        qualifiedReferralCount = new Set((completedReferralTasks || []).map((task) => task.user_id)).size
      }

      if (qualifiedReferralCount < requiredReferrals) {
        const missing = requiredReferrals - qualifiedReferralCount
        return {
          error: `Bạn cần ít nhất ${requiredReferrals} người được mời đã hoàn thành tối thiểu 1 nhiệm vụ để rút mệnh giá này. Hiện có ${qualifiedReferralCount}/${requiredReferrals}; còn thiếu ${missing}. Người được mời chưa làm nhiệm vụ sẽ bị tính giống bot, hãy nhắc họ làm ít nhất 1 nhiệm vụ trước khi bạn rút.`,
        }
      }
    }

    const denomination = type === 'bank' ? null : Number((cleanDetails as { denomination?: number }).denomination)
    const provider = type === 'bank' ? null : String((cleanDetails as { provider?: string }).provider || '')
    const { error } = await supabaseAdmin.rpc('process_redemption_request_secure', {
      p_user_id: user.id,
      p_type: type,
      p_requested_cam: amountCam,
      p_provider: provider,
      p_denomination: denomination,
      p_details: cleanDetails,
    })

    if (error) {
      if (error.message.includes('INSUFFICIENT_BALANCE')) {
        return { error: 'Số dư không đủ.' }
      }
      if (error.message.includes('REDEEM_COOLDOWN')) {
        return { error: `Bạn cần chờ ${REDEEM_COOLDOWN_HOURS} giờ giữa 2 lần rút.` }
      }
      if (error.message.includes('QUALIFIED_REFERRALS_REQUIRED')) {
        return { error: 'Bạn chưa đủ số người được mời hợp lệ cho mệnh giá rút này. Người được mời cần hoàn thành ít nhất 1 nhiệm vụ.' }
      }
      return { error: 'Lỗi tạo ticket rút tiền.' }
    }

    revalidatePath('/dashboard')
    return { success: true }
  } catch (error) {
    if (error instanceof Error && error.message === 'UNAUTHORIZED') {
      return { error: 'Không thể xác thực người dùng.' }
    }
    return { error: 'Có lỗi xảy ra khi tạo yêu cầu rút thưởng.' }
  }
}
