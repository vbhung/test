import React from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { Link2, ShieldCheck, Zap } from 'lucide-react'

export default async function LandingPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  return (
    <div className="landing-layout">
      {/* Global Nav for Landing */}
      <nav className="global-nav">
        <div className="global-nav-left">
          <Link href="/" className="global-nav-logo">CamLink</Link>
        </div>
        <div className="global-nav-right">
          {user ? (
            <Link href="/dashboard" className="btn-primary" style={{ padding: '6px 16px', fontSize: '14px' }}>
              Vào Dashboard
            </Link>
          ) : (
            <Link href="/login" className="global-nav-link" style={{ fontWeight: 600 }}>
              Đăng nhập
            </Link>
          )}
        </div>
      </nav>

      <main className="landing-main">
        <section className="hero-section">
          <div className="hero-content animate-in slide-in-from-bottom-8 duration-700">
            <h1 className="hero-title">Quả Cà Chua</h1>
            <p className="hero-subtitle" style={{ fontSize: '24px', fontWeight: 500, color: '#f5f5f7' }}>
              Dịch vụ vượt link kiếm tiền top 2 Việt Nam
            </p>
            <div className="hero-actions" style={{ marginTop: '32px' }}>
              {user ? (
                <Link href="/dashboard" className="btn-primary">
                  Truy cập Dashboard ngay
                </Link>
              ) : (
                <>
                  <Link href="/register" className="btn-primary">
                    Bắt đầu kiếm tiền
                  </Link>
                  <Link href="/login" className="btn-secondary-pill">
                    Đăng nhập
                  </Link>
                </>
              )}
            </div>
          </div>
        </section>

        <section className="features-section">
          <div className="features-header">
            <h2 className="features-title">Tại sao chọn Quả Cà Chua?</h2>
            <p className="features-subtitle">Hệ thống an toàn, minh bạch và tỷ lệ chia sẻ doanh thu cao nhất.</p>
          </div>
          <div className="features-grid">
            <div className="feature-item">
              <div className="feature-icon"><Zap /></div>
              <h3 className="feature-item-title">Vượt link siêu tốc</h3>
              <p className="feature-item-desc">Không quảng cáo rác, không popup ẩn. Người dùng chỉ cần xác minh CAPTCHA nhanh chóng để đến đích.</p>
            </div>
            <div className="feature-item">
              <div className="feature-icon"><ShieldCheck /></div>
              <h3 className="feature-item-title">Thanh toán minh bạch</h3>
              <p className="feature-item-desc">Mọi giao dịch cộng tiền (Cam) đều được lưu trữ an toàn trên Database, chống gian lận tuyệt đối.</p>
            </div>
            <div className="feature-item">
              <div className="feature-icon"><Link2 /></div>
              <h3 className="feature-item-title">Hoa hồng 7%</h3>
              <p className="feature-item-desc">Mời bạn bè tham gia Quả Cà Chua và nhận ngay 7% doanh thu từ mọi lượt vượt link của họ mãi mãi.</p>
            </div>
          </div>
        </section>
      </main>

      <footer className="landing-footer">
        <p className="landing-footer-text">© 2026 Quả Cà Chua (CamLink) - Dịch vụ vượt link kiếm tiền top 2 VN.</p>
      </footer>
    </div>
  )
}
