import { NextResponse } from 'next/server'
import { createAdminClient, createClient } from '@/lib/supabase/server'

export const dynamic = 'force-dynamic'

const UUID_RE =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i

export async function GET(request: Request, context: { params: { token: string } }) {
  const token = context.params.token

  if (!UUID_RE.test(token)) {
    return new NextResponse('Not Found', { status: 404 })
  }

  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const url = new URL(request.url)

  if (!user) {
    return NextResponse.redirect(`${url.origin}/login?redirect=/verify-task?token=${encodeURIComponent(token)}`)
  }

  const supabaseAdmin = createAdminClient()

  const { data: profile } = await supabaseAdmin
    .from('profiles')
    .select('is_banned')
    .eq('id', user.id)
    .maybeSingle()
  if (profile?.is_banned) {
    return NextResponse.redirect(`${url.origin}/dashboard?error=banned`)
  }

  const { data: task, error: taskError } = await supabaseAdmin
    .from('earn_tasks')
    .select('id, status, expires_at')
    .eq('token', token)
    .eq('user_id', user.id)
    .maybeSingle()

  if (taskError) {
    console.error('[EARN_TOKEN_ROUTE] Task lookup failed:', { token, userId: user.id, error: taskError })
    return NextResponse.redirect(`${url.origin}/dashboard/earn?error=task_lookup_failed`)
  }

  if (!task) {
    console.warn('[EARN_TOKEN_ROUTE] Task not found for token:', { token, userId: user.id })
    return NextResponse.redirect(`${url.origin}/dashboard/earn?error=task_not_found`)
  }

  if (task.status !== 'pending') {
    console.warn('[EARN_TOKEN_ROUTE] Task no longer pending:', { token, userId: user.id, status: task.status })
    return NextResponse.redirect(`${url.origin}/dashboard/earn?error=task_not_pending`)
  }

  if (new Date(task.expires_at) < new Date()) {
    console.warn('[EARN_TOKEN_ROUTE] Task expired:', { token, userId: user.id, expiresAt: task.expires_at })
    return NextResponse.redirect(`${url.origin}/dashboard/earn?error=task_expired`)
  }

  return NextResponse.redirect(`${url.origin}/dashboard/earn?error=legacy_entry_disabled`, 302)
}
