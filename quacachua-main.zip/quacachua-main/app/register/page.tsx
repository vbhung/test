'use client'

import React, { useEffect, useState } from 'react'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { checkEmailAction, registerAction } from '@/app/actions/auth'
import { TermsModal } from '@/components/ui/TermsModal'
import { getRegistrationIdentity } from '@/lib/client/identity'

export default function RegisterPage() {
  const [step, setStep] = useState(1)
  const [email, setEmail] = useState('')
  const [checkToken, setCheckToken] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [successMsg, setSuccessMsg] = useState('')

  // Step 2 state
  const [displayName, setDisplayName] = useState('')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [referral, setReferral] = useState('')
  
  const [showTerms, setShowTerms] = useState(false)
  const [captchaToken, setCaptchaToken] = useState('')
  const [agreed, setAgreed] = useState(false)
  const [deviceId, setDeviceId] = useState('')
  const [browserId, setBrowserId] = useState('')

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const ref = params.get('ref')
    if (ref) setReferral(ref)
  }, [])

  useEffect(() => {
    const identity = getRegistrationIdentity()
    setDeviceId(identity.deviceId)
    setBrowserId(identity.browserId)
  }, [])

  const handleStep1 = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    const res = await checkEmailAction(email)
    setLoading(false)

    if (res.error) {
      setError(res.error)
    } else if (res.success && res.checkToken) {
      setCheckToken(res.checkToken)
      setStep(2)
    }
  }

  const handleStep2 = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    if (!agreed || !captchaToken) {
      setError('Vui lòng đồng ý Điều khoản Sử dụng và xác minh CAPTCHA')
      setLoading(false)
      return
    }

    const formData = new FormData()
    formData.append('email', email)
    formData.append('displayName', displayName)
    formData.append('username', username)
    formData.append('password', password)
    formData.append('captchaToken', captchaToken)
    if (referral) formData.append('referralCode', referral)
    formData.append('checkToken', checkToken)
    formData.append('deviceId', deviceId)
    formData.append('browserId', browserId)

    const res = await registerAction(formData)
    setLoading(false)

    if (res.error) {
      setError(res.error)
    } else if (res.success) {
      setSuccessMsg('Đăng ký thành công! Vui lòng kiểm tra email của bạn và bấm vào link xác nhận để hoàn tất.')
    }
  }

  if (successMsg) {
    return (
      <div className="auth-layout">
        <div className="auth-card-container" style={{ textAlign: 'center' }}>
          <h1 className="auth-title" style={{ color: 'var(--color-primary)' }}>Thành công!</h1>
          <p className="auth-subtitle" style={{ marginBottom: '32px' }}>{successMsg}</p>
          <Button variant="primary" onClick={() => window.location.href = '/login'}>
            Quay lại Đăng nhập
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="auth-layout">
      <div className="auth-card-container">
        <h1 className="auth-title">Tạo tài khoản</h1>
        <p className="auth-subtitle">
          {step === 1 ? 'Bước 1: Xác minh email' : 'Bước 2: Hoàn tất thông tin'}
        </p>

        {error && (
          <div className="auth-error">
            {error}
          </div>
        )}

        {step === 1 && (
          <form onSubmit={handleStep1} className="auth-form">
            <Input
              label="Địa chỉ Email (Chỉ hỗ trợ Gmail)"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="ví dụ: bạn@gmail.com"
              required
            />
            <div className="auth-btn-group">
              <Button type="submit" isLoading={loading}>
                Tiếp tục
              </Button>
            </div>
            <div className="auth-footer-text">
              <span>Đã có tài khoản?</span>
              <a href="/login" className="auth-footer-link">Đăng nhập</a>
            </div>
          </form>
        )}

        {step === 2 && (
          <form onSubmit={handleStep2} className="auth-form">
            <Input
              label="Email"
              type="email"
              value={email}
              disabled
            />
            <Input
              label="Họ và tên"
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="VD: Nguyễn Văn A"
              required
            />
            <Input
              label="Tên đăng nhập (Username)"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="VD: nguyenvana123"
              required
            />
            <Input
              label="Mật khẩu"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Tối thiểu 8 ký tự"
              required
            />
            <Input
              label="Mã mời (không bắt buộc)"
              type="text"
              value={referral}
              onChange={(e) => setReferral(e.target.value)}
              placeholder="Nhập mã mời để nhận thưởng"
            />
            
            <div style={{ display: 'flex', alignItems: 'center', marginTop: '16px', marginBottom: '16px' }}>
              <input 
                type="checkbox" 
                id="termsCheck" 
                checked={agreed}
                onChange={(e) => {
                  if (e.target.checked && !agreed) {
                    setShowTerms(true)
                  } else {
                    setAgreed(false)
                    setCaptchaToken('')
                  }
                }}
                style={{ marginRight: '8px', cursor: 'pointer' }}
              />
              <label htmlFor="termsCheck" style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-80)' }}>
                Tôi đồng ý với <a href="#" onClick={(e) => { e.preventDefault(); setShowTerms(true); }} style={{ color: 'var(--color-primary)' }}>Điều khoản Sử dụng Dịch vụ</a>
              </label>
            </div>

            <div className="auth-btn-group">
              <Button type="submit" isLoading={loading} disabled={!agreed || loading || !deviceId}>
                Tạo tài khoản
              </Button>
              <Button type="button" variant="utility" onClick={() => setStep(1)} disabled={loading} style={{ background: 'transparent', border: '1px solid var(--color-hairline)', color: 'var(--color-ink)' }}>
                Quay lại
              </Button>
            </div>
          </form>
        )}
      </div>

      <TermsModal 
        isOpen={showTerms} 
        onClose={() => setShowTerms(false)} 
        onAccept={(token) => {
          setCaptchaToken(token)
          setAgreed(true)
          setShowTerms(false)
        }} 
      />
    </div>
  )
}
