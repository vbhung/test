import { Suspense } from 'react'
import { VerifyTaskClient } from '@/components/dashboard/VerifyTaskClient'
import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { CopyVerifyLinkClient } from '@/components/dashboard/CopyVerifyLinkClient'

export const metadata = {
  title: 'Xác minh nhiệm vụ | CamLink',
}

export default async function VerifyTaskPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-[var(--color-canvas)]">
        <Suspense fallback={<div className="text-center text-ink-muted-80">Đang tải...</div>}>
          <CopyVerifyLinkClient />
        </Suspense>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[var(--color-canvas)]">
      <Suspense fallback={<div className="text-center text-ink-muted-80">Đang tải...</div>}>
        <VerifyTaskClient />
      </Suspense>
    </div>
  )
}
