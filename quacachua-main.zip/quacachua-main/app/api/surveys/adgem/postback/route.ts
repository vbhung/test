import { createHmac, timingSafeEqual } from 'crypto'
import { NextResponse } from 'next/server'
import { atomicCamTransaction } from '@/lib/cam/transaction'
import { createAdminClient } from '@/lib/supabase/server'

export const dynamic = 'force-dynamic'
export const revalidate = 0
export const runtime = 'nodejs'

function safeEqual(a: string, b: string) {
  const aBuffer = Buffer.from(a)
  const bBuffer = Buffer.from(b)
  if (aBuffer.length !== bBuffer.length) return false
  return timingSafeEqual(aBuffer, bBuffer)
}

function firstParam(params: URLSearchParams, names: string[]) {
  for (const name of names) {
    const value = params.get(name)
    if (value) return value.trim()
  }
  return ''
}

function numberParam(params: URLSearchParams, names: string[]) {
  const raw = firstParam(params, names)
  if (!raw) return null
  const value = Number(raw.replace(',', '.'))
  return Number.isFinite(value) ? value : null
}

function buildRawPayload(params: URLSearchParams) {
  const payload: Record<string, string | string[]> = {}
  params.forEach((value, key) => {
    if (key === 'verifier') return
    if (payload[key] === undefined) {
      payload[key] = value
    } else if (Array.isArray(payload[key])) {
      payload[key].push(value)
    } else {
      payload[key] = [payload[key] as string, value]
    }
  })
  return payload
}

function removeVerifierFromUrl(rawUrl: string) {
  const [base, hash = ''] = rawUrl.split('#', 2)
  const queryStart = base.indexOf('?')
  if (queryStart === -1) return base

  const path = base.slice(0, queryStart)
  const query = base.slice(queryStart + 1)
  const filteredQuery = query
    .split('&')
    .filter((part) => {
      const key = part.split('=', 1)[0]
      return decodeURIComponent(key.replace(/\+/g, '%20')) !== 'verifier'
    })
    .join('&')

  return `${path}${filteredQuery ? `?${filteredQuery}` : ''}${hash ? `#${hash}` : ''}`
}

function verifyAdGemRequest(rawUrl: string, postbackKey: string, verifier: string) {
  const hashlessUrl = removeVerifierFromUrl(rawUrl)
  const expectedVerifier = createHmac('sha256', postbackKey).update(hashlessUrl, 'utf8').digest('hex')
  return safeEqual(verifier, expectedVerifier)
}

export async function GET(request: Request) {
  try {
    const postbackKey = process.env.ADGEM_POSTBACK_KEY
    if (!postbackKey) {
      console.error('[CONFIG] Missing ADGEM_POSTBACK_KEY')
      return new NextResponse('postback_not_configured', { status: 503 })
    }

    const requestUrl = new URL(request.url)
    const params = requestUrl.searchParams
    const requestId = firstParam(params, ['request_id'])
    const verifier = firstParam(params, ['verifier'])
    const userId = firstParam(params, ['player_id'])
    const transactionId = firstParam(params, ['transaction_id']) || requestId
    const amountCam = numberParam(params, ['amount'])
    const payoutUsd = numberParam(params, ['payout'])
    const maxRewardCam = Number(process.env.ADGEM_MAX_CAM_REWARD || '10000')
    const creditEnabled = process.env.ADGEM_POSTBACK_ENABLE_CREDIT === 'true'

    if (!requestId || !verifier || !userId || !transactionId) {
      return new NextResponse('missing_required_params', { status: 400 })
    }

    if (!verifyAdGemRequest(request.url, postbackKey, verifier)) {
      return new NextResponse('invalid_verifier', { status: 403 })
    }

    if (amountCam === null || amountCam <= 0 || amountCam > maxRewardCam) {
      return new NextResponse('invalid_amount', { status: 400 })
    }

    if (!creditEnabled) {
      console.info('[AdGem] Dry-run postback accepted', {
        requestId,
        transactionId,
        userId,
        amountCam,
        payoutUsd,
      })
      return new NextResponse('ok')
    }

    const supabaseAdmin = createAdminClient()
    const { data: profile, error: profileError } = await supabaseAdmin
      .from('profiles')
      .select('id, is_banned')
      .eq('id', userId)
      .single()

    if (profileError || !profile) {
      return new NextResponse('unknown_user', { status: 404 })
    }

    if (profile.is_banned) {
      return new NextResponse('restricted_user', { status: 403 })
    }

    const rawPayload = buildRawPayload(params)
    const { data: postback, error: insertError } = await supabaseAdmin
      .from('survey_postbacks')
      .insert({
        provider: 'adgem',
        transaction_id: transactionId,
        user_id: userId,
        status: 'completed',
        amount_cam: amountCam,
        amount_usd: payoutUsd,
        raw_payload: rawPayload,
      })
      .select('id')
      .single()

    if (insertError) {
      if (insertError.code === '23505') {
        return new NextResponse('duplicate_ok')
      }
      console.error('AdGem postback insert error:', insertError)
      return new NextResponse('postback_store_failed', { status: 500 })
    }

    const offerName = firstParam(params, ['offer_name']) || 'offer'
    const goalName = firstParam(params, ['goal_name'])
    const tx = await atomicCamTransaction({
      userId,
      type: 'earn',
      amount: amountCam,
      description: `AdGem reward: ${offerName}${goalName ? ` - ${goalName}` : ''} (${transactionId})`,
      refId: postback.id,
    })

    if (!tx.success) {
      console.error('AdGem reward transaction failed:', tx.error)
      await supabaseAdmin
        .from('survey_postbacks')
        .update({ status: 'ignored', raw_payload: { ...rawPayload, credit_error: tx.error }, updated_at: new Date().toISOString() })
        .eq('id', postback.id)
      return new NextResponse('credit_failed', { status: 500 })
    }

    await supabaseAdmin
      .from('survey_postbacks')
      .update({ credited_tx_id: tx.data?.tx_id || null, updated_at: new Date().toISOString() })
      .eq('id', postback.id)

    return new NextResponse('ok')
  } catch (error) {
    console.error('AdGem postback error:', error)
    return new NextResponse('server_error', { status: 500 })
  }
}
