import { createHash } from 'crypto'
import { NextResponse } from 'next/server'
import { guardApi } from '@/lib/security/api-guard'
import { createAdminClient } from '@/lib/supabase/server'

export const dynamic = 'force-dynamic'
export const revalidate = 0
export const runtime = 'nodejs'

const CPX_WALL_BASE_URL = 'https://offers.cpx-research.com/index.php'

function md5(value: string) {
  return createHash('md5').update(value).digest('hex')
}

export async function GET(request: Request) {
  try {
    const guard = await guardApi(request, 'survey_cpx_wall', 30, 60)
    if (guard instanceof NextResponse) return guard
    const { user } = guard

    const appId = process.env.CPX_APP_ID || '34270'
    const appSecureHash = process.env.CPX_SECURE_HASH
    if (!appSecureHash) {
      console.error('[CONFIG] Missing CPX_SECURE_HASH')
      return NextResponse.json({ error: 'CPX survey wall is not configured.' }, { status: 503 })
    }

    const supabaseAdmin = createAdminClient()
    const { data: profile, error: profileError } = await supabaseAdmin
      .from('profiles')
      .select('username, display_name, email_canonical, is_banned')
      .eq('id', user.id)
      .single()

    if (profileError || !profile) {
      return NextResponse.json({ error: 'Profile not found.' }, { status: 404 })
    }

    if (profile.is_banned) {
      return NextResponse.json({ error: 'Account is restricted.' }, { status: 403 })
    }

    const url = new URL(CPX_WALL_BASE_URL)
    url.searchParams.set('app_id', appId)
    url.searchParams.set('ext_user_id', user.id)
    url.searchParams.set('secure_hash', md5(`${user.id}-${appSecureHash}`))
    url.searchParams.set('username', profile.username || profile.display_name || '')
    url.searchParams.set('email', profile.email_canonical || user.email || '')
    url.searchParams.set('subid_1', 'quacachua')
    url.searchParams.set('subid_2', 'survey_wall')

    return NextResponse.json(
      { surveyUrl: url.toString() },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate',
        },
      }
    )
  } catch (error) {
    console.error('CPX wall URL error:', error)
    return NextResponse.json({ error: 'Could not load survey wall.' }, { status: 500 })
  }
}
