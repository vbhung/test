import { createHash, timingSafeEqual } from 'crypto'
import { NextResponse } from 'next/server'
import { atomicCamTransaction } from '@/lib/cam/transaction'
import { createAdminClient } from '@/lib/supabase/server'

export const dynamic = 'force-dynamic'
export const revalidate = 0
export const runtime = 'nodejs'

type PostbackStatus = 'completed' | 'reversed' | 'ignored'
type PostbackEventType = 'complete' | 'bonus' | 'rating' | 'screenout' | 'unknown'

function safeEqual(a: string, b: string) {
  const aBuffer = Buffer.from(a)
  const bBuffer = Buffer.from(b)
  if (aBuffer.length !== bBuffer.length) return false
  return timingSafeEqual(aBuffer, bBuffer)
}

function md5(value: string) {
  return createHash('md5').update(value).digest('hex')
}

function firstParam(params: URLSearchParams, names: string[]) {
  for (const name of names) {
    const value = params.get(name)
    if (value) return value.trim()
  }
  return ''
}

function numberParam(params: URLSearchParams, names: string[]) {
  const raw = firstParam(params, names)
  if (!raw) return null
  const value = Number(raw.replace(',', '.'))
  return Number.isFinite(value) ? value : null
}

function normalizeStatus(rawStatus: string): PostbackStatus {
  const status = rawStatus.trim().toLowerCase()
  if (!status || status === '1' || status === 'complete' || status === 'completed' || status === 'approved') {
    return 'completed'
  }
  if (status === '2' || status === 'cancelled' || status === 'canceled' || status === 'reversed' || status === 'chargeback') {
    return 'reversed'
  }
  return 'ignored'
}

function normalizeEventType(rawType: string): PostbackEventType {
  const type = rawType.trim().toLowerCase().replace(/[\s_-]+/g, '')
  if (!type) return 'unknown'
  if (type === 'complete' || type === 'completed') return 'complete'
  if (type === 'bonus') return 'bonus'
  if (type === 'rating' || type === 'rate' || type === 'survey rating'.replace(/\s+/g, '')) return 'rating'
  if (type === 'screenout' || type === 'screenedout' || type === 'returnout' || type === 'out') return 'screenout'
  return 'unknown'
}

function canCreditPostback(status: PostbackStatus, eventType: PostbackEventType) {
  if (status === 'reversed') return false
  return status === 'completed' || eventType === 'complete' || eventType === 'bonus' || eventType === 'rating' || eventType === 'screenout'
}

function describePostback(eventType: PostbackEventType, transactionId: string) {
  if (eventType === 'bonus') return `CPX Research bonus reward (${transactionId})`
  if (eventType === 'rating') return `CPX Research rating reward (${transactionId})`
  if (eventType === 'screenout') return `CPX Research screen-out bonus (${transactionId})`
  return `CPX Research survey reward (${transactionId})`
}

function buildRawPayload(params: URLSearchParams) {
  const payload: Record<string, string | string[]> = {}
  params.forEach((value, key) => {
    if (key === 'key' || key === 'secret' || key === 'hash' || key === 'secure_hash') return
    if (payload[key] === undefined) {
      payload[key] = value
    } else if (Array.isArray(payload[key])) {
      payload[key].push(value)
    } else {
      payload[key] = [payload[key] as string, value]
    }
  })
  return payload
}

function resolveRewardCam(params: URLSearchParams) {
  const localAmount = numberParam(params, ['amount_local', 'amount_cam', 'reward', 'payout', 'amount'])
  if (localAmount !== null) return localAmount

  const usdAmount = numberParam(params, ['amount_usd', 'payout_usd', 'usd'])
  const usdToCamRate = Number(process.env.CPX_USD_TO_CAM_RATE || '0')
  if (usdAmount !== null && Number.isFinite(usdToCamRate) && usdToCamRate > 0) {
    return Number((usdAmount * usdToCamRate).toFixed(4))
  }

  return null
}

export async function GET(request: Request) {
  try {
    const appSecureHash = process.env.CPX_SECURE_HASH
    if (!appSecureHash) {
      console.error('[CONFIG] Missing CPX_SECURE_HASH')
      return new NextResponse('postback_not_configured', { status: 503 })
    }

    const requestUrl = new URL(request.url)
    const params = requestUrl.searchParams
    const transactionId = firstParam(params, ['trans_id', 'transaction_id', 'tx_id'])
    const userId = firstParam(params, ['user_id', 'ext_user_id', 'ext_user'])

    if (!transactionId || !userId) {
      return new NextResponse('missing_required_params', { status: 400 })
    }

    const providedHash = firstParam(params, ['hash', 'secure_hash'])
    const expectedHash = md5(`${transactionId}-${appSecureHash}`)
    if (!providedHash || !safeEqual(providedHash, expectedHash)) {
      return new NextResponse('forbidden', { status: 403 })
    }

    const extraPostbackSecret = process.env.CPX_POSTBACK_SECRET
    const providedSecret = firstParam(params, ['key', 'secret'])
    if (extraPostbackSecret && providedSecret && !safeEqual(providedSecret, extraPostbackSecret)) {
      return new NextResponse('forbidden', { status: 403 })
    }

    const status = normalizeStatus(firstParam(params, ['status', 'state']))
    const eventType = normalizeEventType(firstParam(params, ['type', 'event_type', 'event']))
    const shouldCredit = canCreditPostback(status, eventType)
    const storedStatus = status === 'ignored' && eventType !== 'unknown' ? eventType : status
    const amountCam = resolveRewardCam(params)
    const amountUsd = numberParam(params, ['amount_usd', 'payout_usd', 'usd'])
    const maxRewardCam = Number(process.env.CPX_MAX_CAM_REWARD || '100')

    const supabaseAdmin = createAdminClient()
    const { data: profile, error: profileError } = await supabaseAdmin
      .from('profiles')
      .select('id, is_banned')
      .eq('id', userId)
      .single()

    if (profileError || !profile) {
      return new NextResponse('unknown_user', { status: 404 })
    }

    const rawPayload = buildRawPayload(params)

    if (!shouldCredit) {
      const { data: existing } = await supabaseAdmin
        .from('survey_postbacks')
        .select('id')
        .eq('provider', 'cpx')
        .eq('transaction_id', transactionId)
        .maybeSingle()

      if (existing) {
        await supabaseAdmin
          .from('survey_postbacks')
          .update({ status: storedStatus, raw_payload: rawPayload, updated_at: new Date().toISOString() })
          .eq('id', existing.id)
      } else {
        await supabaseAdmin.from('survey_postbacks').insert({
          provider: 'cpx',
          transaction_id: transactionId,
          user_id: userId,
          status: storedStatus,
          amount_cam: amountCam,
          amount_usd: amountUsd,
          raw_payload: rawPayload,
        })
      }

      return new NextResponse('ok')
    }

    if (profile.is_banned) {
      return new NextResponse('restricted_user', { status: 403 })
    }

    const cpxDisabled = process.env.CPX_REWARDS_DISABLED === 'true'
    if (cpxDisabled) {
      const { data: existing } = await supabaseAdmin
        .from('survey_postbacks')
        .select('id')
        .eq('provider', 'cpx')
        .eq('transaction_id', transactionId)
        .maybeSingle()

      if (!existing) {
        await supabaseAdmin.from('survey_postbacks').insert({
          provider: 'cpx',
          transaction_id: transactionId,
          user_id: userId,
          status: storedStatus,
          amount_cam: amountCam,
          amount_usd: amountUsd,
          raw_payload: rawPayload,
        })
      }

      return new NextResponse('ok')
    }

    if (amountCam === null || amountCam <= 0 || amountCam > maxRewardCam) {
      return new NextResponse('invalid_amount', { status: 400 })
    }

    const { data: postback, error: insertError } = await supabaseAdmin
      .from('survey_postbacks')
      .insert({
        provider: 'cpx',
        transaction_id: transactionId,
        user_id: userId,
        status: storedStatus,
        amount_cam: amountCam,
        amount_usd: amountUsd,
        raw_payload: rawPayload,
      })
      .select('id')
      .single()

    if (insertError) {
      if (insertError.code === '23505') {
        return new NextResponse('duplicate_ok')
      }
      console.error('CPX postback insert error:', insertError)
      return new NextResponse('postback_store_failed', { status: 500 })
    }

    const tx = await atomicCamTransaction({
      userId,
      type: 'earn',
      amount: amountCam,
      description: describePostback(eventType, transactionId),
      refId: postback.id,
    })

    if (!tx.success) {
      console.error('CPX reward transaction failed:', tx.error)
      await supabaseAdmin
        .from('survey_postbacks')
        .update({ status: 'ignored', raw_payload: { ...rawPayload, credit_error: tx.error }, updated_at: new Date().toISOString() })
        .eq('id', postback.id)
      return new NextResponse('credit_failed', { status: 500 })
    }

    await supabaseAdmin
      .from('survey_postbacks')
      .update({ credited_tx_id: tx.data?.tx_id || null, updated_at: new Date().toISOString() })
      .eq('id', postback.id)

    return new NextResponse('ok')
  } catch (error) {
    console.error('CPX postback error:', error)
    return new NextResponse('server_error', { status: 500 })
  }
}
