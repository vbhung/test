import { NextResponse } from 'next/server'
import { createClient, createAdminClient } from '@/lib/supabase/server'

export async function GET() {
  try {
    const supabase = createAdminClient()
    const { data, error } = await supabase
      .from('global_notifications')
      .select('content, updated_at')
      .eq('id', 1)
      .maybeSingle()

    if (error) return NextResponse.json({ content: '', updated_at: null })
    return NextResponse.json({ content: data?.content || '', updated_at: data?.updated_at || null })
  } catch {
    return NextResponse.json({ content: '', updated_at: null })
  }
}

export async function POST(req: Request) {
  try {
    const supabase = createClient()
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()

    if (profile?.role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

    const { content } = await req.json()
    if (typeof content !== 'string') return NextResponse.json({ error: 'Invalid content' }, { status: 400 })

    const supabaseAdmin = createAdminClient()
    const { error: upsertError } = await supabaseAdmin
      .from('global_notifications')
      .upsert({ id: 1, content, updated_at: new Date().toISOString() })

    if (upsertError) return NextResponse.json({ error: upsertError.message }, { status: 500 })
    return NextResponse.json({ success: true })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
