import { NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export async function GET() {
  try {
    const supabaseAdmin = createAdminClient()
    await supabaseAdmin.rpc('process_referral_suspensions')
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Referral suspension cron error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
