import { NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

async function checkReview(alias: string): Promise<{ tinhtien: string; ketqua: string; time: number } | null> {
  try {
    const url = `https://phienchoso.com/api_task/review-show.php?alias=${encodeURIComponent(alias)}`
    const res = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', Accept: 'application/json' },
      signal: AbortSignal.timeout(10000),
    })
    const data = await res.json()
    if (data.status === 'success') {
      return { tinhtien: data.tinhtien || '', ketqua: data.ketqua || '', time: Number(data.time) || 0 }
    }
    return null
  } catch {
    return null
  }
}

export async function GET(req: Request) {
  try {
    const authHeader = req.headers.get('authorization')
    const cronSecret = process.env.CRON_SECRET
    if (cronSecret && authHeader !== `Bearer ${cronSecret}`) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const supabase = createAdminClient()
    const { data: pendingReviews, error } = await supabase
      .from('earn_review_queue')
      .select('*')
      .eq('status', 'pending')
      .order('created_at', { ascending: true })

    if (error) throw error
    if (!pendingReviews || pendingReviews.length === 0) {
      return NextResponse.json({ checked: 0, results: [] })
    }

    const results: Array<{ id: string; alias: string; action: string }> = []

    for (const review of pendingReviews) {
      const result = await checkReview(review.alias)
      if (!result) {
        await supabase.from('earn_review_queue').update({ checked_at: new Date().toISOString() }).eq('id', review.id)
        continue
      }

      if (result.ketqua === 'YES' && result.tinhtien === 'VIEW') {
        await supabase.rpc('process_cam_transaction', {
          p_user_id: review.user_id,
          p_type: 'earn_review_release',
          p_amount: review.pending_cam,
          p_description: `Giải ngân ${review.pending_cam} Cam duyệt Phienchoso review`,
          p_ref_id: review.task_id,
        })

        await supabase.from('earn_review_queue').update({
          status: 'approved',
          checked_at: new Date().toISOString(),
          completed_at: new Date().toISOString(),
        }).eq('id', review.id)

        results.push({ id: review.id, alias: review.alias, action: 'approved' })
      } else if (result.ketqua === 'NO') {
        await supabase.rpc('process_cam_transaction', {
          p_user_id: review.user_id,
          p_type: 'earn_review_hold',
          p_amount: review.advanced_cam,
          p_description: `Thu hồi ${review.advanced_cam} Cam tạm ứng Phienchoso review không hợp lệ`,
          p_ref_id: review.task_id,
        })

        await supabase.from('earn_review_queue').update({
          status: 'rejected',
          checked_at: new Date().toISOString(),
          completed_at: new Date().toISOString(),
        }).eq('id', review.id)

        results.push({ id: review.id, alias: review.alias, action: 'rejected' })
      } else {
        await supabase.from('earn_review_queue').update({ checked_at: new Date().toISOString() }).eq('id', review.id)
        results.push({ id: review.id, alias: review.alias, action: 'pending' })
      }
    }

    return NextResponse.json({ checked: pendingReviews.length, results })
  } catch (error) {
    console.error('Review check cron error:', error)
    return NextResponse.json({ error: 'Internal error' }, { status: 500 })
  }
}
