import { NextResponse } from 'next/server'
import { guardApi } from '@/lib/security/api-guard'
import { atomicCamTransaction } from '@/lib/cam/transaction'
import { verifyTurnstile } from '@/lib/captcha/turnstile'

export async function POST(request: Request) {
  try {
    const { linkCode, captchaToken } = await request.json()

    if (!linkCode || !captchaToken) {
      return NextResponse.json({ error: 'Dữ liệu không hợp lệ' }, { status: 400 })
    }

    // 1. Validate CAPTCHA
    const isValidCaptcha = await verifyTurnstile(captchaToken)
    if (!isValidCaptcha) {
      return NextResponse.json({ error: 'Xác minh CAPTCHA thất bại. Vui lòng thử lại.' }, { status: 400 })
    }

    const guard = await guardApi(request, 'links_verify', 10, 60)
    if (guard instanceof NextResponse) return guard
    const { user, admin: supabaseAdmin } = guard

    // 2. Fetch Link info
    const { data: link, error: linkError } = await supabaseAdmin
      .from('link_verifications')
      .select('*')
      .eq('code', linkCode)
      .single()

    if (linkError || !link) {
      return NextResponse.json({ error: 'Link không tồn tại' }, { status: 404 })
    }

    // 3. Validate Link State
    if (link.status !== 'pending') {
      return NextResponse.json({ error: 'Link này đã được sử dụng hoặc hết hạn' }, { status: 400 })
    }

    if (new Date(link.expires_at).getTime() < Date.now()) {
      return NextResponse.json({ error: 'Link này đã hết thời gian hiệu lực' }, { status: 400 })
    }

    // 4. Mark Link as Used (Phải làm trước khi cộng tiền để chống double-click)
    const { data: updatedLink, error: updateError } = await supabaseAdmin
      .from('link_verifications')
      .update({
        status: 'used',
        used_by: user.id,
        used_at: new Date().toISOString()
      })
      .eq('id', link.id)
      .eq('status', 'pending')
      .select()
      .single()

    if (updateError || !updatedLink) {
      return NextResponse.json({ error: 'Xác minh quá chậm, link đã có người dùng.' }, { status: 400 })
    }

    // 5. Trả thưởng bằng Atomic Transaction Engine
    const tx = await atomicCamTransaction({
      userId: user.id,
      type: 'earn',
      amount: link.reward_cam,
      description: `Vượt link thành công: ${linkCode}`,
      refId: link.id
    })

    if (!tx.success) {
      console.error('[CRITICAL] Failed to reward user after link used', tx.error)
      return NextResponse.json({ error: 'Có lỗi xảy ra khi cộng tiền. Đã báo cáo cho Admin.' }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      reward: link.reward_cam,
      message: `Bạn vừa nhận được ${link.reward_cam} Cam!`
    })

  } catch (error: any) {
    console.error('[VerifyAPI]', error)
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 })
  }
}
