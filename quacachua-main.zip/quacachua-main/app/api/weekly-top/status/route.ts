export const dynamic = 'force-dynamic'

import { NextResponse } from 'next/server'
import { createAdminClient, createClient } from '@/lib/supabase/server'
import { kv } from '@/lib/kv'

const REFRESH_INTERVAL_MINUTES = 216
const FORCE_REFRESH_COOLDOWN_SECONDS = 60 * 60

function getIsoWeekPeriod(date: Date) {
  const d = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()))
  const dayNum = d.getUTCDay() || 7
  d.setUTCDate(d.getUTCDate() + 4 - dayNum)
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1))
  const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7)
  return `${d.getUTCFullYear()}-W${weekNo}`
}

function getCurrentVietnamWeek() {
  const now = new Date()
  const vnTime = new Date(now.getTime() + 7 * 60 * 60 * 1000)
  const dayOfWeek = vnTime.getUTCDay()
  const daysSinceMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1
  const startOfWeekVN = new Date(vnTime)
  startOfWeekVN.setUTCDate(vnTime.getUTCDate() - daysSinceMonday)
  startOfWeekVN.setUTCHours(0, 0, 0, 0)

  const endOfWeekVN = new Date(startOfWeekVN)
  endOfWeekVN.setUTCDate(startOfWeekVN.getUTCDate() + 6)

  return {
    period: getIsoWeekPeriod(startOfWeekVN),
    weekStartVN: startOfWeekVN.toISOString().slice(0, 10),
    weekEndVN: endOfWeekVN.toISOString().slice(0, 10),
  }
}

function isMissingSchema(error: any) {
  return error?.code === '42P01' || error?.code === 'PGRST205' || error?.code === 'PGRST202'
}

export async function GET(request: Request) {
  try {
    const supabase = createClient()
    const { data: { user }, error: authError } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const supabaseAdmin = createAdminClient()
    const currentWeek = getCurrentVietnamWeek()
    const requestUrl = new URL(request.url)
    const forceRefresh = requestUrl.searchParams.get('force') === '1'

    if (forceRefresh) {
      const cooldownKey = `weekly-top:force-refresh:${user.id}`
      const cooldownEntry = await kv.get<{ requestedAt?: string }>(cooldownKey)

      if (cooldownEntry?.requestedAt) {
        const requestedAtMs = new Date(cooldownEntry.requestedAt).getTime()
        const remainingSeconds = Math.max(
          0,
          Math.ceil((requestedAtMs + FORCE_REFRESH_COOLDOWN_SECONDS * 1000 - Date.now()) / 1000)
        )

        if (remainingSeconds > 0) {
          return NextResponse.json(
            {
              error: `Bạn chỉ có thể ấn tải lại ngay 1 lần mỗi giờ. Vui lòng thử lại sau ${Math.ceil(remainingSeconds / 60)} phút.`,
            },
            {
              status: 429,
              headers: {
                'Retry-After': String(remainingSeconds),
              },
            }
          )
        }
      }

      await kv.set(
        cooldownKey,
        {
          requestedAt: new Date().toISOString(),
        },
        { ex: FORCE_REFRESH_COOLDOWN_SECONDS }
      )
    }

    const { error: awardError } = await supabaseAdmin.rpc('award_previous_weekly_top')
    if (awardError && !isMissingSchema(awardError)) {
      console.error('Weekly top award skipped:', awardError)
    }

    const { error: refreshError } = await supabaseAdmin.rpc('refresh_weekly_top_current', { p_force: forceRefresh })
    if (refreshError && !isMissingSchema(refreshError)) throw refreshError

    if (isMissingSchema(awardError) || isMissingSchema(refreshError)) {
      return NextResponse.json({
        schemaMissing: true,
        leaderboard: [],
        rewards: [],
        currentWeek,
        message: 'Cần chạy weekly_top.sql trong Supabase SQL Editor.',
      })
    }

    const { data: leaderboard, error: leaderboardError } = await supabaseAdmin
      .from('weekly_top_cache')
      .select('period, week_start_vn, week_end_vn, rank, user_id, username, display_name, task_count, generated_at')
      .eq('period', currentWeek.period)
      .order('rank', { ascending: true })

    if (leaderboardError) {
      if (isMissingSchema(leaderboardError)) {
        return NextResponse.json({
          schemaMissing: true,
          leaderboard: [],
          rewards: [],
          currentWeek,
          message: 'Cần chạy weekly_top.sql trong Supabase SQL Editor.',
        })
      }
      throw leaderboardError
    }

    const { data: refreshMeta, error: refreshMetaError } = await supabaseAdmin
      .from('weekly_top_refreshes')
      .select('generated_at')
      .eq('period', currentWeek.period)
      .maybeSingle()

    if (refreshMetaError && !isMissingSchema(refreshMetaError)) throw refreshMetaError

    const { data: rewards, error: rewardsError } = await supabaseAdmin
      .from('weekly_top_rewards')
      .select('period, week_start_vn, week_end_vn, rank, task_count, reward_cam, awarded_at')
      .eq('user_id', user.id)
      .order('awarded_at', { ascending: false })
      .limit(5)

    if (rewardsError && !isMissingSchema(rewardsError)) throw rewardsError

    const generatedAt = refreshMeta?.generated_at || leaderboard?.[0]?.generated_at || null
    const nextRefreshAt = generatedAt
      ? new Date(new Date(generatedAt).getTime() + REFRESH_INTERVAL_MINUTES * 60 * 1000).toISOString()
      : null
    const currentUserEntry = leaderboard?.find((entry) => entry.user_id === user.id) || null

    return NextResponse.json({
      schemaMissing: false,
      currentWeek,
      leaderboard: leaderboard || [],
      generatedAt,
      nextRefreshAt,
      currentUserEntry,
      rewards: rewards || [],
      refreshIntervalMinutes: REFRESH_INTERVAL_MINUTES,
      forcedRefresh: forceRefresh,
      rewardWarning: awardError && !isMissingSchema(awardError)
        ? 'Chưa thể xử lý thưởng tuần trước. Bảng top hiện tại vẫn hiển thị bình thường.'
        : null,
    })
  } catch (error) {
    console.error('Weekly top status error:', error)
    return NextResponse.json({ error: 'Lỗi hệ thống khi tải top tuần.' }, { status: 500 })
  }
}
