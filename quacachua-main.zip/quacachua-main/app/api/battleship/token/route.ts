import { NextResponse } from 'next/server'
import { guardApi } from '@/lib/security/api-guard'
import { serverEnv } from '@/lib/env'
import { createHmac, randomUUID } from 'crypto'

const AMOUNT_TO_TIER: Record<number, string> = {
  4: 'little',
  12: 'little',
  20: 'middle',
  40: 'middle',
  80: 'large',
  200: 'large',
}

const VALID_AMOUNTS = Object.keys(AMOUNT_TO_TIER).map(Number)

type Tier = 'little' | 'middle' | 'large'

export async function POST(request: Request) {
  try {
    const guard = await guardApi(request, 'battleship_token', 10, 60)
    if (guard instanceof NextResponse) return guard
    const { user, admin } = guard

    const body = await request.json()
    const { amount } = body as { amount?: number }

    if (!amount || !VALID_AMOUNTS.includes(amount)) {
      return NextResponse.json({ error: 'Số CAM cược không hợp lệ' }, { status: 400 })
    }

    // Check balance only — deduction happens when match starts
    const { data: profile } = await admin
      .from('profiles')
      .select('cam_balance, display_name, username')
      .eq('id', user.id)
      .single()

    if (!profile) {
      return NextResponse.json({ error: 'Không tìm thấy tài khoản' }, { status: 404 })
    }

    if (Number(profile.cam_balance) < amount) {
      return NextResponse.json({ error: 'Số dư CAM không đủ' }, { status: 400 })
    }

    const displayName = profile.display_name || profile.username || 'Player'
    const tier = AMOUNT_TO_TIER[amount] as Tier
    const wagerContextId = randomUUID()

    const now = Math.floor(Date.now() / 1000)
    const payload = {
      version: 1,
      partnerId: serverEnv.battleshipPartnerId(),
      playerId: user.id,
      displayName: String(displayName).slice(0, 30),
      betTier: tier,
      amount,
      wagerContextId,
      issuedAt: now,
      expiresAt: now + 1800,
      nonce: randomUUID(),
    }
    const encoded = Buffer.from(JSON.stringify(payload)).toString('base64url')
    const sig = createHmac('sha256', serverEnv.battleshipSecret()).update(encoded).digest('base64url')
    return NextResponse.json({ token: `${encoded}.${sig}` })
  } catch (error) {
    console.error('[Battleship] Token error:', error)
    return NextResponse.json({ error: 'Lỗi tạo token' }, { status: 500 })
  }
}
