import { NextRequest, NextResponse } from 'next/server'
import { createHmac, timingSafeEqual } from 'crypto'
import { createAdminClient } from '@/lib/supabase/server'
import { serverEnv } from '@/lib/env'

export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const signature = request.headers.get('x-battleship-signature') || ''

    const secret = serverEnv.battleshipSecret()
    const expected = createHmac('sha256', secret).update(body).digest('hex')
    if (!signature || expected.length !== signature.length || !timingSafeEqual(Buffer.from(expected), Buffer.from(signature))) {
      return NextResponse.json({ error: 'Invalid signature' }, { status: 401 })
    }

    const result = JSON.parse(body) as {
      matchId: string
      partnerId: string
      status: 'match_start' | 'finished' | 'cancelled'
      winnerId: string | null
      loserId: string | null
      playerIds: string[]
      reason?: string
      wagerContextIds: string[]
      tier: string
      amount: number
      replayHash?: string
      completedAt: string
    }

    const supabase = createAdminClient()

    if (result.partnerId !== serverEnv.battleshipPartnerId()) {
      return NextResponse.json({ error: 'Invalid partner' }, { status: 403 })
    }

    const { data, error } = await supabase.rpc('process_battleship_event', {
      p_match_id: result.matchId,
      p_status: result.status,
      p_player_ids: result.playerIds,
      p_amount: result.amount,
      p_tier: result.tier,
      p_winner_id: result.winnerId ?? null,
      p_loser_id: result.loserId ?? null,
      p_reason: result.reason ?? null,
      p_replay_hash: result.replayHash ?? null,
    })
    if (error) {
      console.error('[Battleship] Atomic event failed:', error)
      return NextResponse.json({ error: 'Invalid match event' }, { status: 400 })
    }

    return NextResponse.json({ received: true, result: data })
  } catch (error) {
    console.error('[Battleship] Webhook error:', error)
    return NextResponse.json({ error: 'Internal error' }, { status: 500 })
  }
}
