import { NextResponse } from 'next/server'
import { guardApi } from '@/lib/security/api-guard'
import { createAdminClient } from '@/lib/supabase/server'

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { recipient, amount, note } = body

    if (!recipient || typeof recipient !== 'string') {
      return NextResponse.json({ error: 'Thông tin người nhận không hợp lệ.' }, { status: 400 })
    }

    const parsedAmount = Number(amount)
    if (!Number.isFinite(parsedAmount) || parsedAmount <= 0) {
      return NextResponse.json({ error: 'Số tiền chuyển không hợp lệ.' }, { status: 400 })
    }

    const totalDeduction = parsedAmount
    const fee = 1
    const transferAmount = totalDeduction - fee

    if (transferAmount <= 0) {
      return NextResponse.json({ error: `Số tiền chuyển phải lớn hơn phí giao dịch (${fee} Cam).` }, { status: 400 })
    }

    const guard = await guardApi(req, 'wallet_transfer', 10, 60)
    if (guard instanceof NextResponse) return guard
    const { user } = guard
    const supabaseAdmin = createAdminClient()

    const { data, error } = await supabaseAdmin.rpc('process_cam_transfer', {
      p_sender_id: user.id,
      p_recipient_username: recipient,
      p_total_deduction: totalDeduction,
      p_fee: fee,
      p_note: note || null,
    })

    if (error) {
      if (error.message.includes('SELF_TRANSFER')) {
        return NextResponse.json({ error: 'Không thể chuyển Cam cho chính mình.' }, { status: 400 })
      }
      if (error.message.includes('RECIPIENT_NOT_FOUND')) {
        return NextResponse.json({ error: `Không tìm thấy người dùng có Username là: ${recipient}` }, { status: 404 })
      }
      if (error.message.includes('INSUFFICIENT_BALANCE')) {
        return NextResponse.json(
          { error: `Số dư không đủ. Cần ít nhất ${totalDeduction.toFixed(2)} Cam (bao gồm phí).` },
          { status: 400 }
        )
      }
      if (error.message.includes('REFERRAL_TRANSFER_BLOCKED')) {
        return NextResponse.json({ error: 'Không thể chuyển Cam cho người có liên kết mã mời (referral) với bạn.' }, { status: 400 })
      }
      throw error
    }

    await supabaseAdmin.from('notifications').insert({
      user_id: data.receiver_id,
      title: 'Nhận Cam thành công',
      body: `Bạn vừa nhận được ${transferAmount} Cam từ ${data.sender_username}.${note ? ' Lời nhắn: ' + note : ''}`,
    })

    return NextResponse.json({
      success: true,
      message: `Đã chuyển thành công ${transferAmount} Cam cho ${data.receiver_username}.`,
    })
  } catch (error: unknown) {
    console.error('[TRANSFER_API_ERROR]', error)
    return NextResponse.json({ error: 'Đã xảy ra lỗi hệ thống, vui lòng thử lại sau.' }, { status: 500 })
  }
}
