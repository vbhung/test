import { NextResponse } from 'next/server'
import { serverEnv } from '@/lib/env'

export const dynamic = 'force-dynamic'

export async function GET() {
  const token = serverEnv.phienchosoToken()
  return NextResponse.json({ token })
}
