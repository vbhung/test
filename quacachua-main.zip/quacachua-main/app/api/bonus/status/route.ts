export const dynamic = 'force-dynamic'
import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: Request) {
  try {
    const supabase = createClient()
    const { data: { user }, error: authError } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Lấy thời gian hiện tại theo giờ Việt Nam
    const now = new Date()
    const vnTime = new Date(now.getTime() + 7 * 60 * 60 * 1000)
    
    // Tính khoảng thời gian cho Daily
    const startOfTodayVN = new Date(vnTime)
    startOfTodayVN.setUTCHours(0, 0, 0, 0)
    const endOfTodayVN = new Date(vnTime)
    endOfTodayVN.setUTCHours(23, 59, 59, 999)
    
    const startOfTodayUTC = new Date(startOfTodayVN.getTime() - 7 * 60 * 60 * 1000)
    const endOfTodayUTC = new Date(endOfTodayVN.getTime() - 7 * 60 * 60 * 1000)
    
    // Tính khoảng thời gian cho Weekly (từ T2 đến CN)
    const dayOfWeek = vnTime.getUTCDay() // 0 là CN, 1 là T2
    const daysSinceMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1
    const startOfWeekVN = new Date(vnTime)
    startOfWeekVN.setUTCDate(vnTime.getUTCDate() - daysSinceMonday)
    startOfWeekVN.setUTCHours(0, 0, 0, 0)
    const startOfWeekUTC = new Date(startOfWeekVN.getTime() - 7 * 60 * 60 * 1000)

    // 1. Tính tổng số nhiệm vụ Daily
    const { count: dailyTasksCount, error: dailyError } = await supabase
      .from('cam_transactions')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id)
      .eq('type', 'earn')
      .gte('created_at', startOfTodayUTC.toISOString())
      .lte('created_at', endOfTodayUTC.toISOString())

    if (dailyError) throw dailyError

    // 2. Tính tổng Cam từ Referral Weekly
    const { data: refTransactions, error: refError } = await supabase
      .from('cam_transactions')
      .select('amount')
      .eq('user_id', user.id)
      .eq('type', 'referral_bonus')
      .gte('created_at', startOfWeekUTC.toISOString())

    if (refError) throw refError

    const weeklyRefCam = (refTransactions || []).reduce((sum, tx) => sum + Number(tx.amount || 0), 0)

    // 3. Lấy danh sách các phần thưởng đã claim
    // Mảng string kiểu như '2026-07-04' cho daily và '2026-W27' cho weekly
    const todayStr = startOfTodayVN.toISOString().split('T')[0]
    
    // Hàm format Weekly string
    const getWeek = (d: Date) => {
        const date = new Date(d.getTime());
        date.setUTCDate(date.getUTCDate() + 4 - (date.getUTCDay()||7));
        var yearStart = new Date(Date.UTC(date.getUTCFullYear(),0,1));
        var weekNo = Math.ceil(( ( (date.getTime() - yearStart.getTime()) / 86400000) + 1)/7);
        return `${date.getUTCFullYear()}-W${weekNo}`;
    }
    const weekStr = getWeek(vnTime)

    // Lấy Claims
    const { data: claims, error: claimError } = await supabase
      .from('bonus_claims')
      .select('bonus_type, period')
      .eq('user_id', user.id)
      .in('period', [todayStr, weekStr])

    if (claimError) {
      // Nếu bảng chưa có (Mã lỗi của PostgREST là PGRST205 hoặc Postgres là 42P01)
      if (claimError.code === '42P01' || claimError.code === 'PGRST205') {
        return NextResponse.json({
          dailyCount: dailyTasksCount || 0,
          weeklyRefCam: weeklyRefCam || 0,
          claims: [],
          todayStr,
          weekStr,
          schemaMissing: true // Flag nhắc dev tạo bảng
        })
      }
      throw claimError
    }

    return NextResponse.json({ 
      dailyCount: dailyTasksCount || 0,
      weeklyRefCam: weeklyRefCam || 0,
      claims: claims || [],
      todayStr,
      weekStr
    })
  } catch (e) {
    console.error('Bonus Status API error:', e)
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 })
  }
}

