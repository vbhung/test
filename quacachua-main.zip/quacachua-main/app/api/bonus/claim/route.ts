import { NextResponse } from 'next/server'
import { guardApi } from '@/lib/security/api-guard'
import { createAdminClient } from '@/lib/supabase/server'

const BONUS_CONFIG: Record<string, { type: 'daily' | 'weekly', requirement: number, reward: number, desc: string }> = {
  'daily_30': { type: 'daily', requirement: 30, reward: 8, desc: 'Thưởng thêm: Đạt mốc 30 nhiệm vụ ngày' },
  'daily_60': { type: 'daily', requirement: 60, reward: 10, desc: 'Thưởng thêm: Đạt mốc 60 nhiệm vụ ngày' },
  'daily_100': { type: 'daily', requirement: 100, reward: 12, desc: 'Thưởng thêm: Đạt mốc 100 nhiệm vụ ngày' },
  'weekly_10': { type: 'weekly', requirement: 10, reward: 16, desc: 'Thưởng thêm: Kiếm 10 Cam từ hoa hồng tuần' },
  'weekly_28': { type: 'weekly', requirement: 28, reward: 20, desc: 'Thưởng thêm: Kiếm 28 Cam từ hoa hồng tuần' },
  'weekly_60': { type: 'weekly', requirement: 60, reward: 32, desc: 'Thưởng thêm: Kiếm 60 Cam từ hoa hồng tuần' },
}

function checkTableError(e: any): string | null {
  if (e?.code === '42P01' || e?.code === 'PGRST205') return 'Hệ thống chưa được cấu hình. Vui lòng chạy SQL tạo bảng bonus_claims trong Supabase SQL Editor.'
  if (e?.code === '23505') return 'Bạn đã nhận phần thưởng này rồi'
  return null
}

export async function POST(request: Request) {
  try {
    const guard = await guardApi(request, 'bonus_claim', 10, 60)
    if (guard instanceof NextResponse) return guard
    const { user } = guard
    const supabaseAdmin = createAdminClient()

    const body = await request.json()
    const { bonusType } = body

    if (!bonusType || !BONUS_CONFIG[bonusType]) {
      return NextResponse.json({ error: 'Tham số không hợp lệ' }, { status: 400 })
    }

    const config = BONUS_CONFIG[bonusType]

    const now = new Date()
    const vnTime = new Date(now.getTime() + 7 * 60 * 60 * 1000)
    
    if (config.type === 'daily') {
      const startOfTodayVN = new Date(vnTime)
      startOfTodayVN.setUTCHours(0, 0, 0, 0)
      const endOfTodayVN = new Date(vnTime)
      endOfTodayVN.setUTCHours(23, 59, 59, 999)
      const startOfTodayUTC = new Date(startOfTodayVN.getTime() - 7 * 60 * 60 * 1000)
      const endOfTodayUTC = new Date(endOfTodayVN.getTime() - 7 * 60 * 60 * 1000)

      const { count, error } = await supabaseAdmin
        .from('cam_transactions')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('type', 'earn')
        .gte('created_at', startOfTodayUTC.toISOString())
        .lte('created_at', endOfTodayUTC.toISOString())

      if (error || (count || 0) < config.requirement) {
        return NextResponse.json({ error: 'Chưa đủ điều kiện nhận thưởng' }, { status: 400 })
      }
    } else {
      const dayOfWeek = vnTime.getUTCDay()
      const daysSinceMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1
      const startOfWeekVN = new Date(vnTime)
      startOfWeekVN.setUTCDate(vnTime.getUTCDate() - daysSinceMonday)
      startOfWeekVN.setUTCHours(0, 0, 0, 0)
      const startOfWeekUTC = new Date(startOfWeekVN.getTime() - 7 * 60 * 60 * 1000)

      const { data: refTransactions, error } = await supabaseAdmin
        .from('cam_transactions')
        .select('amount')
        .eq('user_id', user.id)
        .eq('type', 'referral_bonus')
        .gte('created_at', startOfWeekUTC.toISOString())

      if (error) throw error
      const weeklyRefCam = refTransactions.reduce((sum, tx) => sum + Number(tx.amount), 0)

      if (weeklyRefCam < config.requirement) {
        return NextResponse.json({ error: 'Chưa đủ điều kiện nhận thưởng tuần' }, { status: 400 })
      }
    }

    const { data: claim, error: claimError } = await supabaseAdmin.rpc('process_bonus_claim_secure', {
      p_user_id: user.id,
      p_bonus_type: bonusType,
    })
    if (claimError) {
      const known = checkTableError(claimError)
      if (known || claimError.code === '23505') return NextResponse.json({ error: known || 'Bạn đã nhận phần thưởng này rồi' }, { status: 400 })
      return NextResponse.json({ error: 'Chưa đủ điều kiện hoặc phần thưởng đã được nhận.' }, { status: 400 })
    }
    return NextResponse.json({ success: true, reward: Number(claim?.reward || config.reward) })
  } catch (e) {
    console.error('Bonus Claim API error:', e)
    return NextResponse.json({ error: 'Lỗi hệ thống hoặc Database chưa được cấu hình' }, { status: 500 })
  }
}
