import { NextResponse } from 'next/server'
import { cookies, headers } from 'next/headers'
import { EARN_VERIFY_ENTRY_COOKIE, createVerifyEntryCookieValue, isValidShortlinkEntryReferrer } from '@/lib/security/earn-entry'
import { createAdminClient, createClient } from '@/lib/supabase/server'
import { checkVpn, extractClientIp, checkVietnameseIp } from '@/lib/security/vpn-check'
import { getClientIdentity } from '@/lib/security/client-identity'
import crypto from 'crypto'
import { DEVICE_HEADER, BROWSER_HEADER } from '@/lib/security/client-identity'

export async function GET(request: Request) {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://quacachua.shop'

  const requestUrl = new URL(request.url)
  const token = requestUrl.searchParams.get('token')

  if (!token) {
    return NextResponse.redirect(`${siteUrl}/dashboard/earn?error=invalid_task`)
  }

  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.redirect(`${siteUrl}/login`)
  }

  const supabaseAdmin = createAdminClient()

  // Check banned
  const { data: profile } = await supabaseAdmin
    .from('profiles')
    .select('is_banned')
    .eq('id', user.id)
    .maybeSingle()
  if (profile?.is_banned) {
    return NextResponse.redirect(`${siteUrl}/dashboard?error=banned`)
  }

  const clientIp = extractClientIp(request)
  let deviceId = requestUrl.searchParams.get('did')
  let browserId = requestUrl.searchParams.get('bid')

  // Fallback từ cookie (set khi generate task)
  if (!deviceId || !browserId) {
    const cookieStore = await cookies()
    deviceId = deviceId || cookieStore.get('earn_did')?.value
    browserId = browserId || cookieStore.get('earn_bid')?.value
  }

  const identityHeaders = new Headers(request.headers)
  identityHeaders.set(DEVICE_HEADER, deviceId)
  identityHeaders.set(BROWSER_HEADER, browserId)
  const identityRequest = new Request(request.url, { headers: identityHeaders })
  const identity = getClientIdentity(identityRequest)
  if (!identity) {
    return NextResponse.redirect(`${siteUrl}/dashboard/earn?error=identity_required`)
  }
  const vpnCheck = await checkVpn(clientIp)
  if (vpnCheck.blocked) {
    return NextResponse.redirect(`${siteUrl}/dashboard/earn?error=vpn_blocked`)
  }

  const countryCheck = checkVietnameseIp()
  if (!countryCheck.allowed) {
    return NextResponse.redirect(`${siteUrl}/dashboard/earn?error=vn_only`)
  }

  const { data: task, error: taskError } = await supabaseAdmin
    .from('earn_tasks')
    .select('id, shortened_url, status, expires_at')
    .eq('token', token)
    .eq('user_id', user.id)
    .maybeSingle()

  if (taskError) {
    console.error('[EARN_ENTRY] Task lookup failed:', { token, userId: user.id, error: taskError })
    return NextResponse.redirect(`${siteUrl}/dashboard/earn?error=task_lookup_failed`)
  }

  if (!task) {
    console.warn('[EARN_ENTRY] Task not found for token:', { token, userId: user.id })
    return NextResponse.redirect(`${siteUrl}/dashboard/earn?error=task_not_found`)
  }

  if (task.status !== 'pending') {
    console.warn('[EARN_ENTRY] Task no longer pending:', { token, userId: user.id, status: task.status })
    return NextResponse.redirect(`${siteUrl}/dashboard/earn?error=task_not_pending`)
  }

  if (new Date(task.expires_at) < new Date()) {
    console.warn('[EARN_ENTRY] Task expired:', { token, userId: user.id, expiresAt: task.expires_at })
    return NextResponse.redirect(`${siteUrl}/dashboard/earn?error=task_expired`)
  }

  const headerStore = await headers()
  const referer = headerStore.get('referer')
  const userAgent = headerStore.get('user-agent') || 'unknown'

  // Chi block khi co referer VA referer khac domain - null/empty referer cho qua
  // (browser co the strip referer do Referrer-Policy, false positive se block user that)
  if (referer && !isValidShortlinkEntryReferrer(referer, task.shortened_url)) {
    await supabaseAdmin.from('security_flags').insert({
      user_id: user.id,
      reason: 'verify_entry_invalid_referrer',
      metadata: {
        token,
        referer,
        shortened_url: task.shortened_url,
      },
    })
    return NextResponse.redirect(`${siteUrl}/verify-task?token=${encodeURIComponent(token)}&entry=blocked`)
  }

  const proof = crypto.randomUUID() + crypto.randomUUID()
  const proofHash = crypto.createHash('sha256').update(proof).digest('hex')

  // Upsert proof: update identity hashes theo thiết bị hiện tại (user click từ đâu thì verify từ đó)
  const { error: proofError } = await supabaseAdmin.from('earn_entry_proofs').upsert({
    task_id: task.id,
    user_id: user.id,
    proof_hash: proofHash,
    ip_hash: identity.ipHash,
    device_hash: identity.deviceHash,
    browser_hash: identity.browserHash,
    issued_at: new Date().toISOString(),
    expires_at: new Date(Date.now() + 20 * 60 * 1000).toISOString(),
    consumed_at: null,
  }, { onConflict: 'task_id' })

  if (proofError) {
    console.error('[EARN_ENTRY] Proof creation failed:', proofError)
    return NextResponse.redirect(`${siteUrl}/dashboard/earn?error=proof_failed`)
  }

  const response = NextResponse.redirect(`${siteUrl}/verify-task?token=${encodeURIComponent(token)}`)
  response.cookies.set({
    name: EARN_VERIFY_ENTRY_COOKIE,
    value: createVerifyEntryCookieValue({ userId: user.id, token, userAgent, proof }),
    httpOnly: true,
    sameSite: 'lax',
    secure: true,
    path: '/',
    maxAge: 20 * 60,
  })

  return response
}
