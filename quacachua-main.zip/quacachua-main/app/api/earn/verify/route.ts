import { NextResponse } from 'next/server'
import { cookies, headers } from 'next/headers'
import { verifyTurnstile } from '@/lib/captcha/turnstile'
import { EARN_VERIFY_ENTRY_COOKIE, validateVerifyEntryCookie } from '@/lib/security/earn-entry'
import { guardApi } from '@/lib/security/api-guard'
import { createAdminClient } from '@/lib/supabase/server'
import { checkVpn, extractClientIp } from '@/lib/security/vpn-check'
import { enforceClientIdentity } from '@/lib/security/client-identity'
import crypto from 'crypto'

export const dynamic = 'force-dynamic'
export const revalidate = 0
export const runtime = 'nodejs'

const VERIFY_ROUTE_VERSION = 'no-time-gate-2026-07-07'
const NO_STORE_HEADERS = {
  'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
  Pragma: 'no-cache',
  Expires: '0',
  'X-Earn-Verify-Version': VERIFY_ROUTE_VERSION,
}

function verifyJson(body: Record<string, unknown>, status = 200) {
  return NextResponse.json({ ...body, verifyVersion: VERIFY_ROUTE_VERSION }, { status, headers: NO_STORE_HEADERS })
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { token, captchaToken } = body

    if (!token || !captchaToken) {
      return verifyJson({ error: 'Thiếu thông tin yêu cầu.' }, 400)
    }

    const isValidCaptcha = await verifyTurnstile(captchaToken)
    if (!isValidCaptcha) {
      return verifyJson({ error: 'Xác minh Captcha thất bại.' }, 400)
    }

    const guard = await guardApi(req, 'earn_verify', 10, 60)
    if (guard instanceof NextResponse) return guard
    const { user } = guard

    const clientIp = extractClientIp(req)
    const vpnCheck = await checkVpn(clientIp)
    if (vpnCheck.blocked) {
      return verifyJson({ error: 'Phát hiện VPN/Proxy. Vui lòng tắt VPN/Proxy và thử lại.' }, 403)
    }

    const supabaseAdmin = createAdminClient()
    const identityCheck = await enforceClientIdentity(req, user.id, 'earn_verify', supabaseAdmin)
    if (!identityCheck.allowed) return verifyJson({ error: identityCheck.error }, 403)

    const { data: task, error: taskError } = await supabaseAdmin
      .from('earn_tasks')
      .select('*')
      .eq('token', token)
      .eq('user_id', user.id)
      .single()

    if (taskError || !task) {
      return verifyJson({ error: 'Nhiệm vụ không hợp lệ hoặc không thuộc về bạn.' }, 400)
    }

    if (task.status === 'completed') {
      return verifyJson({ error: 'Nhiệm vụ này đã được hoàn thành.' }, 400)
    }

    if (task.status === 'rejected') {
      return verifyJson({ error: 'Nhiệm vụ này đã bị từ chối.' }, 400)
    }

    if (new Date(task.expires_at) < new Date()) {
      return verifyJson({ error: 'Nhiệm vụ này đã hết hạn.' }, 400)
    }

    const cookieStore = await cookies()
    const headerStore = await headers()
    const userAgent = headerStore.get('user-agent') || 'unknown'
    const entryProof = validateVerifyEntryCookie(cookieStore.get(EARN_VERIFY_ENTRY_COOKIE)?.value, {
      userId: user.id,
      token,
      userAgent,
    })

    if (!entryProof.valid) {
      await supabaseAdmin.from('security_flags').insert({
        user_id: user.id,
        reason: 'earn_verify_invalid_entry_path',
        metadata: {
          token,
          reason: entryProof.reason,
        },
      })
      return verifyJson(
        {
          error: 'Liên kết xác minh không được mở từ đúng shortlink nhiệm vụ. Vui lòng quay lại và mở lại bằng link rút gọn gốc.',
          code: 'invalid_entry_path',
        },
        400
      )
    }

    if (!entryProof.proof) return verifyJson({ error: 'Proof nhiệm vụ không hợp lệ.' }, 400)
    const proofHash = crypto.createHash('sha256').update(entryProof.proof).digest('hex')

    let { data: completionData, error: completionError } = await supabaseAdmin.rpc('complete_earn_task_secure', {
      p_task_id: task.id,
      p_user_id: user.id,
      p_proof_hash: proofHash,
      p_ip_hash: identityCheck.identity.ipHash,
      p_device_hash: identityCheck.identity.deviceHash,
      p_browser_hash: identityCheck.identity.browserHash,
    })

    if (!completionData && completionError?.message === 'ENTRY_IDENTITY_MISMATCH') {
      await supabaseAdmin.from('earn_entry_proofs')
        .update({
          ip_hash: identityCheck.identity.ipHash,
          device_hash: identityCheck.identity.deviceHash,
          browser_hash: identityCheck.identity.browserHash,
        })
        .eq('task_id', task.id)
        .eq('user_id', user.id)

      const retry = await supabaseAdmin.rpc('complete_earn_task_secure', {
        p_task_id: task.id,
        p_user_id: user.id,
        p_proof_hash: proofHash,
        p_ip_hash: identityCheck.identity.ipHash,
        p_device_hash: identityCheck.identity.deviceHash,
        p_browser_hash: identityCheck.identity.browserHash,
      })
      completionData = retry.data
      completionError = retry.error
    }

    if (!completionData) {
      const errMsg = completionError?.message || ''
      console.error('Earn verify completion error:', {
        taskId: task.id,
        userId: user.id,
        providerCode: task.provider_code,
        error: errMsg,
      })
      if (errMsg === 'ENTRY_TOO_FAST') {
        return verifyJson({ error: 'Bạn quay lại xác nhận quá nhanh. Vui lòng đợi khoảng 10 giây sau khi bấm "Xác nhận" rồi thử lại.' }, 400)
      }
      return verifyJson({ error: 'Đã có lỗi xảy ra trên server.' }, 500)
    }

    const response = verifyJson({ success: true, reward: Number(completionData.reward_cam || 0) })
    response.cookies.set({
      name: EARN_VERIFY_ENTRY_COOKIE,
      value: '',
      httpOnly: true,
      sameSite: 'lax',
      secure: true,
      path: '/',
      maxAge: 0,
    })

    if (task.provider_code === 'phienchoso_review') {
      const totalCam = Number(completionData.reward_cam || task.reward_cam || 0)
      const advancedCam = Math.round(totalCam / 3 * 10000) / 10000
      const pendingCam = Math.round((totalCam - advancedCam) * 10000) / 10000

      if (pendingCam > 0) {
        await supabaseAdmin.rpc('process_cam_transaction', {
          p_user_id: user.id,
          p_type: 'earn_review_hold',
          p_amount: pendingCam,
          p_description: `Tạm giữ ${pendingCam} Cam chờ duyệt Phienchoso review`,
          p_ref_id: task.id,
        })

        const alias = task.shortened_url.replace(/https?:\/\/phienchoso\.com\//, '').replace(/\.rv$/, '')

        await supabaseAdmin.from('earn_review_queue').insert({
          user_id: user.id,
          task_id: task.id,
          provider_code: task.provider_code,
          alias,
          total_cam: totalCam,
          advanced_cam: advancedCam,
          pending_cam: pendingCam,
        })
      }
    }

    return response
  } catch (error) {
    console.error('Earn verify error:', error)
    return verifyJson({ error: 'Đã có lỗi xảy ra trên server.' }, 500)
  }
}
