import { NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'
import { verifyTurnstile } from '@/lib/captcha/turnstile'
import { guardApi } from '@/lib/security/api-guard'
import { checkVpn, extractClientIp } from '@/lib/security/vpn-check'


const UPTOLINK_CAMPAIGN_TYPES: Record<string, number> = {
  uptolink_social: 1,
  uptolink_socical: 1,
  uptolink_search_2step: 4,
  uptolink_search_2_step: 4,
  uptolink_search2step: 4,
  uptolink_search_3step: 3,
  uptolink_search_3_step: 3,
  uptolink_search3step: 3,
  uptolink_search_4step: 5,
  uptolink_search_4_step: 5,
  uptolink_search4step: 5,
}

function getUptolinkCampaignType(provider: { code?: string; api_url?: string }) {
  const code = (provider.code || '').toLowerCase()
  if (Object.prototype.hasOwnProperty.call(UPTOLINK_CAMPAIGN_TYPES, code)) {
    return UPTOLINK_CAMPAIGN_TYPES[code]
  }

  const apiUrl = (provider.api_url || '').toLowerCase()
  const looksLikeUptolink = code.startsWith('uptolink') || code.startsWith('octolink') || apiUrl.includes('uptolink.vip') || apiUrl.includes('octolink.vip')
  if (!looksLikeUptolink) return null

  if (code.includes('social') || code.includes('socical')) return 1
  if (code.includes('2step') || code.includes('2_step')) return 4
  if (code.includes('3step') || code.includes('3_step')) return 3
  if (code.includes('4step') || code.includes('4_step')) return 5

  return 1
}

function extractShortenedUrl(apiData: any) {
  return apiData?.shortenedUrl || apiData?.short_url || apiData?.shortUrl || apiData?.url || apiData?.link || apiData?.data?.shortenedUrl || apiData?.data?.url
}

async function fetchGenericShortener(provider: { code?: string; api_url: string; api_token: string }, destinationUrl: string) {
  const apiUrl =
    `${provider.api_url}?api=${provider.api_token}` +
    `&url=${encodeURIComponent(destinationUrl)}` +
    `&format=json`

  const apiRes = await fetch(apiUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept': 'application/json',
    },
  })

  const resText = await apiRes.text()
  try {
    const apiData = JSON.parse(resText)
    if (apiData.status === 'error' || apiData.success === false) {
      console.error('Generic shortener error:', provider.code, apiData)
      return ''
    }

    return extractShortenedUrl(apiData) || ''
  } catch (e) {
    return resText.startsWith('http') ? resText.trim() : ''
  }
}

export async function POST(req: Request) {
  try {
    const guard = await guardApi(req, 'earn_generate', 10, 60)
    if (guard instanceof NextResponse) return guard
    const { user } = guard

    const body = await req.json()
    const { providerCode, captchaToken } = body

    if (!providerCode || !captchaToken) {
      return NextResponse.json({ error: 'Thiếu thông tin yêu cầu.' }, { status: 400 })
    }

    const isValidCaptcha = await verifyTurnstile(captchaToken)
    if (!isValidCaptcha) {
      return NextResponse.json({ error: 'Xác minh Captcha thất bại.' }, { status: 400 })
    }

    const clientIp = extractClientIp(req)
    const vpnCheck = await checkVpn(clientIp)
    if (vpnCheck.blocked) {
      return NextResponse.json({ error: 'Phát hiện VPN/Proxy. Vui lòng tắt VPN/Proxy và thử lại.' }, { status: 403 })
    }

    const supabaseAdmin = createAdminClient()
    const { data: provider, error: providerError } = await supabaseAdmin
      .from('earn_providers')
      .select('*')
      .eq('code', providerCode)
      .eq('is_active', true)
      .single()

    if (providerError || !provider) {
      return NextResponse.json({ error: 'Lập trình viên đã tắt nhiệm vụ này, vui lòng đổi nhà cung cấp khác.' }, { status: 400 })
    }

    const now = new Date()

    // Dọn các nhiệm vụ đã hết hạn trước khi kiểm tra
    await supabaseAdmin
      .from('earn_tasks')
      .delete()
      .eq('user_id', user.id)
      .eq('status', 'pending')
      .lte('expires_at', now.toISOString())

    // 2. Check for active pending tasks across ALL providers
    const { count: pendingCount, error: pendingError } = await supabaseAdmin
      .from('earn_tasks')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id)
      .eq('status', 'pending')

    if (pendingError) throw pendingError

    if ((pendingCount || 0) > 0) {
      return NextResponse.json({ error: 'pending_task_exists', message: 'Bạn đang có một nhiệm vụ chưa hoàn thành. Vui lòng hoàn thành hoặc hủy nó trước khi nhận nhiệm vụ mới.' }, { status: 400 })
    }

    // 3. Check Daily Limit - Đếm số lần đã làm từ 0h00 VN hôm nay

    // Lấy mốc 0h00 hôm nay theo giờ Việt Nam (UTC+7)
    const vnTime = new Date(now.getTime() + 7 * 60 * 60 * 1000)
    const startOfTodayVN = new Date(vnTime)
    startOfTodayVN.setUTCHours(0, 0, 0, 0)
    // Chuyển ngược lại về chuẩn UTC để truy vấn DB
    const startOfDayUTC = new Date(startOfTodayVN.getTime() - 7 * 60 * 60 * 1000)

    const { count, error: countError } = await supabaseAdmin
      .from('earn_tasks')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id)
      .eq('provider_code', providerCode)
      .eq('status', 'completed')
      .gt('created_at', startOfDayUTC.toISOString())

    if (countError) throw countError

    if ((count || 0) >= provider.daily_limit) {
      return NextResponse.json({ error: `Bạn đã vượt quá giới hạn ${provider.daily_limit} lần/ngày cho nhà cung cấp này.` }, { status: 400 })
    }

    // Check limit by IP Address (chặn cheat đăng nhập nhiều acc trên 1 máy)
    if (clientIp !== 'unknown') {
      const { count: ipCount, error: ipCountError } = await supabaseAdmin
        .from('earn_tasks')
        .select('*', { count: 'exact', head: true })
        .eq('provider_code', providerCode)
        .eq('status', 'completed')
        .eq('ip_address', clientIp)
        .gt('created_at', startOfDayUTC.toISOString())

      if (!ipCountError && (ipCount || 0) >= provider.daily_limit) {
        return NextResponse.json({ error: 'IP này đã hết lượt làm hôm nay. Vui lòng đổi mạng (4G/WiFi khác) và thử lại.' }, { status: 400 })
      }
    }

    // 3. Generate Task
    const token = crypto.randomUUID()
    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL
    if (!siteUrl) {
      console.error('[CONFIG] Missing NEXT_PUBLIC_SITE_URL')
      return NextResponse.json({ error: 'Lỗi cấu hình server.' }, { status: 500 })
    }
    const deviceId = req.headers.get('x-client-device-id') || ''
    const browserId = req.headers.get('x-client-browser-id') || ''
    const destinationUrl = `${siteUrl}/api/earn/entry?token=${token}&did=${encodeURIComponent(deviceId)}&bid=${encodeURIComponent(browserId)}`

    // 4. Shorten Link using Provider API
    let shortenedUrl = ''
    const providerDbCode = String(provider.code || '').trim()
    const normalizedProviderCode = providerDbCode.toLowerCase()

    if (normalizedProviderCode === 'link4m') {
      const apiUrl = `${provider.api_url}?api=${provider.api_token}&url=${encodeURIComponent(destinationUrl)}`
      const apiRes = await fetch(apiUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/json'
        }
      })
      
      const resText = await apiRes.text()
      try {
        const apiData = JSON.parse(resText)
        if (apiData.status !== 'success') {
          console.error('Link4M error:', apiData)
          return NextResponse.json({ error: 'Lỗi từ nhà cung cấp rút gọn link.' }, { status: 500 })
        }
        shortenedUrl = apiData.shortenedUrl
      } catch (e) {
        console.error('Link4M returned non-JSON:', resText.substring(0, 200))
        return NextResponse.json({ error: 'Nhà cung cấp trả về phản hồi không hợp lệ.' }, { status: 500 })
      }
    } else if (normalizedProviderCode === 'site2s') {
      const apiUrl =
        `${provider.api_url}?api=${provider.api_token}` +
        `&url=${encodeURIComponent(destinationUrl)}` +
        `&format=json&type=1`
      const apiRes = await fetch(apiUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/json'
        }
      })

      const resText = await apiRes.text()
      try {
        const apiData = JSON.parse(resText)
        if (apiData.status === 'error') {
          console.error('Site2S error:', apiData)
          return NextResponse.json({ error: 'Loi tu Site2S: ' + (apiData.message || 'Unknown error') }, { status: 500 })
        }

        shortenedUrl = apiData.shortenedUrl || apiData.short_url || apiData.url

        if (!shortenedUrl || !shortenedUrl.startsWith('http')) {
          console.error('Site2S missing url in response:', apiData)
          return NextResponse.json({ error: 'Loi doc URL tu Site2S.' }, { status: 500 })
        }
      } catch (e) {
        if (resText.startsWith('http')) {
          shortenedUrl = resText.trim()
        } else {
          console.error('Site2S returned non-JSON:', resText.substring(0, 200))
          return NextResponse.json({ error: 'Nha cung cap Site2S tra ve phan hoi khong hop le.' }, { status: 500 })
        }
      }
    } else if (getUptolinkCampaignType({ code: normalizedProviderCode, api_url: provider.api_url }) !== null) {
      const campaignType = getUptolinkCampaignType({ code: normalizedProviderCode, api_url: provider.api_url }) ?? 1
      let uptolinkApiUrl = provider.api_url.replace('uptolink.vip', 'octolink.vip').replace(/\/+$/, '')
      if (!uptolinkApiUrl.endsWith('/api')) {
        uptolinkApiUrl += '/api'
      }
      const apiUrl =
        `${uptolinkApiUrl}?api=${provider.api_token}` +
        `&url=${encodeURIComponent(destinationUrl)}` +
        `&format=json&type=${campaignType}`
      console.debug('[Uptolink] requesting:', apiUrl.replace(provider.api_token, '***'))
      const apiRes = await fetch(apiUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/json'
        }
      })

      const resText = await apiRes.text()
      console.debug('[Uptolink] response status:', apiRes.status, 'body:', resText.substring(0, 300))
      try {
        const apiData = JSON.parse(resText)
        if (apiData.status === 'error') {
          console.error('Uptolink error:', apiData)
          return NextResponse.json({ error: 'Loi tu Uptolink: ' + (apiData.message || 'Unknown error') }, { status: 500 })
        }

        shortenedUrl = apiData.shortenedUrl || apiData.short_url || apiData.url

        if (!shortenedUrl || !shortenedUrl.startsWith('http')) {
          console.error('Uptolink missing url in response:', apiData)
          return NextResponse.json({ error: 'Loi doc URL tu Uptolink.' }, { status: 500 })
        }
      } catch (e) {
        if (resText.startsWith('http')) {
          shortenedUrl = resText.trim()
        } else {
          console.error('Uptolink returned non-JSON:', resText.substring(0, 300))
          return NextResponse.json({ error: 'Nha cung cap Uptolink tra ve phan hoi khong hop le.' }, { status: 500 })
        }
      }
    } else if (normalizedProviderCode === 'traffic68' || normalizedProviderCode === 'linktop') {
      const apiUrl = `${provider.api_url}?api=${provider.api_token}&url=${encodeURIComponent(destinationUrl)}`
      const apiRes = await fetch(apiUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/json'
        }
      })
      
      const resText = await apiRes.text()
      try {
        const apiData = JSON.parse(resText)
        // Traffic68 error format
        if (apiData.status === 'error') {
          console.error('Traffic68 error:', apiData)
          return NextResponse.json({ error: 'Lỗi từ Traffic68: ' + (apiData.message || 'Unknown error') }, { status: 500 })
        }
        
        // Flexible extraction since shortener response structures vary
        shortenedUrl = apiData.shortenedUrl || apiData.short_url || apiData.url || (apiData.data && apiData.data.shortenedUrl)
        
        if (!shortenedUrl) {
          console.error('Traffic68 missing url in response:', apiData)
          return NextResponse.json({ error: 'Lỗi đọc URL từ Traffic68.' }, { status: 500 })
        }
      } catch (e) {
        // Fallback for plain text response
        if (resText.startsWith('http')) {
          shortenedUrl = resText.trim()
        } else {
          console.error('Traffic68 returned non-JSON:', resText.substring(0, 200))
          return NextResponse.json({ error: 'Nhà cung cấp Traffic68 trả về phản hồi không hợp lệ.' }, { status: 500 })
        }
      }
    } else if (normalizedProviderCode === 'nhapma' || normalizedProviderCode === 'taplayma') {
      const apiUrl = `${provider.api_url}?token=${provider.api_token}&url=${encodeURIComponent(destinationUrl)}`
      const apiRes = await fetch(apiUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/json'
        }
      })
      
      const resText = await apiRes.text()
      try {
        const apiData = JSON.parse(resText)
        if (apiData.status === 'error') {
          console.error(`${provider.code} error:`, apiData)
          return NextResponse.json({ error: `Lỗi từ ${provider.code}: ` + (apiData.message || 'Unknown error') }, { status: 500 })
        }
        
        shortenedUrl = apiData.shortenedUrl || apiData.short_url || apiData.url
        
        if (!shortenedUrl) {
          console.error(`${provider.code} missing url in response:`, apiData)
          return NextResponse.json({ error: `Lỗi đọc URL từ ${provider.code}.` }, { status: 500 })
        }
      } catch (e) {
        if (resText.startsWith('http')) {
          shortenedUrl = resText.trim()
        } else {
          console.error(`${provider.code} returned non-JSON:`, resText.substring(0, 200))
          return NextResponse.json({ error: `Nhà cung cấp ${provider.code} trả về phản hồi không hợp lệ.` }, { status: 500 })
        }
      }
    } else if (normalizedProviderCode === 'layma') {
      const apiUrl =
        `${provider.api_url}?tokenUser=${provider.api_token}` +
        `&format=json&url=${encodeURIComponent(destinationUrl)}` +
        `&link_du_phong=${encodeURIComponent(destinationUrl)}`
      const apiRes = await fetch(apiUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/json',
        },
      })

      const resText = await apiRes.text()
      try {
        const apiData = JSON.parse(resText)
        if (!apiData.success) {
          console.error('Layma error:', apiData)
          return NextResponse.json({ error: 'Lỗi từ Layma.' }, { status: 500 })
        }

        shortenedUrl = apiData.html

        if (!shortenedUrl || !shortenedUrl.startsWith('http')) {
          console.error('Layma missing url in response:', apiData)
          return NextResponse.json({ error: 'Lỗi đọc URL từ Layma.' }, { status: 500 })
        }
      } catch (e) {
        if (resText.startsWith('http')) {
          shortenedUrl = resText.trim()
        } else {
          console.error('Layma returned non-JSON:', resText.substring(0, 200))
          return NextResponse.json({ error: 'Nhà cung cấp Layma trả về phản hồi không hợp lệ.' }, { status: 500 })
        }
      }
    } else if (normalizedProviderCode === 'trafficuserr' || normalizedProviderCode === 'traficuserr') {
      let trafficBaseUrl = provider.api_url.includes('www.') ? provider.api_url : provider.api_url.replace('://', '://www.')
      trafficBaseUrl = trafficBaseUrl.replace(/\/+$/, '')
      const apiUrl = `${trafficBaseUrl}?api_key=${provider.api_token}&url=${encodeURIComponent(destinationUrl)}`
      console.debug('[Trafficuserr] requesting:', apiUrl.replace(provider.api_token, '***'))
      const apiRes = await fetch(apiUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/json'
        }
      })
      
      const resText = await apiRes.text()
      console.debug('[Trafficuserr] response status:', apiRes.status, 'body:', resText.substring(0, 300))
      try {
        const apiData = JSON.parse(resText)
        if (apiData.status === false) {
          console.error('Trafficuserr error:', apiData)
          return NextResponse.json({ error: 'Lỗi từ Trafficuserr: ' + (apiData.message || 'Unknown error') }, { status: 500 })
        }
        
        shortenedUrl = apiData.shortenedUrl || apiData.message || apiData.url
        
        if (!shortenedUrl || !shortenedUrl.startsWith('http')) {
          console.error('Trafficuserr missing url in response:', apiData)
          return NextResponse.json({ error: 'Lỗi đọc URL từ Trafficuserr.' }, { status: 500 })
        }
      } catch (e) {
        if (resText.startsWith('http')) {
          shortenedUrl = resText.trim()
        } else {
          console.error('Trafficuserr returned non-JSON:', resText.substring(0, 300))
          return NextResponse.json({ error: 'Nhà cung cấp Trafficuserr trả về phản hồi không hợp lệ.' }, { status: 500 })
        }
      }
    } else if (normalizedProviderCode === 'bbmkts') {
      const apiUrl = `${provider.api_url}?token=${provider.api_token}&longurl=${encodeURIComponent(destinationUrl)}`
      const apiRes = await fetch(apiUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/json'
        }
      })
      
      const resText = await apiRes.text()
      try {
        const apiData = JSON.parse(resText)
        if (apiData.status === 'error') {
          console.error('bbmkts error:', apiData)
          return NextResponse.json({ error: 'Lỗi từ Vượt Nhanh: ' + (apiData.message || 'Unknown error') }, { status: 500 })
        }
        
        shortenedUrl = apiData.bbmktsUrl || apiData.shortenedUrl || apiData.url
        
        if (!shortenedUrl) {
          console.error('bbmkts missing url in response:', apiData)
          return NextResponse.json({ error: 'Lỗi đọc URL từ Vượt Nhanh.' }, { status: 500 })
        }
      } catch (e) {
        if (resText.startsWith('http')) {
          shortenedUrl = resText.trim()
        } else {
          console.error('bbmkts returned non-JSON:', resText.substring(0, 200))
          return NextResponse.json({ error: 'Nhà cung cấp Vượt Nhanh trả về phản hồi không hợp lệ.' }, { status: 500 })
        }
      }
    } else if (normalizedProviderCode.startsWith('linktot_')) {
      const apiUrl = `${provider.api_url}?token=${provider.api_token}&url=${encodeURIComponent(destinationUrl)}`
      const apiRes = await fetch(apiUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/json'
        }
      })
      
      const resText = await apiRes.text()
      try {
        const apiData = JSON.parse(resText)
        if (apiData.status === 'error') {
          console.error('Linktot error:', apiData)
          return NextResponse.json({ error: `Lỗi từ Linktot: ` + (apiData.message || 'Unknown error') }, { status: 500 })
        }
        
        shortenedUrl = apiData.shortenedUrl || apiData.short_url || apiData.url
        
        if (!shortenedUrl) {
          console.error('Linktot missing url in response:', apiData)
          return NextResponse.json({ error: `Lỗi đọc URL từ Linktot.` }, { status: 500 })
        }
      } catch (e) {
        if (resText.startsWith('http')) {
          shortenedUrl = resText.trim()
        } else {
          // Linktot review/map returns <script> window.location.href = "..." </script>
          const scriptMatch = resText.match(/window\.location\.href\s*=\s*['"]([^'"]+)['"]/)
          if (scriptMatch && scriptMatch[1]) {
            let path = scriptMatch[1]
            if (!path.startsWith('http')) {
              path = 'https://linktot.net' + (path.startsWith('/') ? '' : '/') + path
            }
            shortenedUrl = path
          } else {
            console.error('Linktot returned non-JSON:', resText.substring(0, 200))
            return NextResponse.json({ error: `Nhà cung cấp Linktot trả về phản hồi không hợp lệ.` }, { status: 500 })
          }
        }
      }
    } else if (normalizedProviderCode === 'phienchoso_tukhoa') {
      const apiUrl = `${provider.api_url}?token=${provider.api_token}&url=${encodeURIComponent(destinationUrl)}&url_duphong=${encodeURIComponent(destinationUrl)}`
      const res = await fetch(apiUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', Accept: 'application/json' },
      })
      const resText = await res.text()
      try {
        const data = JSON.parse(resText)
        if (data.status !== 'success') {
          console.error('Phienchoso tukhoa error:', data)
          return NextResponse.json({ error: 'Lỗi từ Phienchoso.' }, { status: 500 })
        }
        shortenedUrl = data.url
      } catch {
        return NextResponse.json({ error: 'Phienchoso trả về phản hồi không hợp lệ.' }, { status: 500 })
      }
    } else if (normalizedProviderCode === 'phienchoso_review') {
      const apiUrl = `${provider.api_url}?token=${provider.api_token}&url=${encodeURIComponent(destinationUrl)}&url_duphong=${encodeURIComponent(destinationUrl)}`
      const res = await fetch(apiUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', Accept: 'application/json' },
      })
      const resText = await res.text()
      try {
        const data = JSON.parse(resText)
        if (data.status !== 'success') {
          console.error('Phienchoso review error:', data)
          return NextResponse.json({ error: 'Lỗi từ Phienchoso.' }, { status: 500 })
        }
        shortenedUrl = data.url
      } catch {
        return NextResponse.json({ error: 'Phienchoso trả về phản hồi không hợp lệ.' }, { status: 500 })
      }
    } else {
      console.error('Unsupported provider, trying generic shortener:', {
        code: providerDbCode,
        api_url: provider.api_url,
      })
      shortenedUrl = await fetchGenericShortener(provider, destinationUrl)

      if (!shortenedUrl || !shortenedUrl.startsWith('http')) {
        return NextResponse.json({ error: `Nhà cung cấp ${providerDbCode || 'này'} chưa được hỗ trợ hoặc trả về phản hồi không hợp lệ.` }, { status: 400 })
      }
    }

    // 5. Save to DB
    const expiresAt = new Date()
    const expiryMinutes = normalizedProviderCode.startsWith('uptolink') || normalizedProviderCode.startsWith('octolink')
      ? 120
      : 30
    expiresAt.setMinutes(expiresAt.getMinutes() + expiryMinutes)

    const { error: insertError } = await supabaseAdmin
      .from('earn_tasks')
      .insert({
        user_id: user.id,
        provider_code: providerCode,
        token,
        shortened_url: shortenedUrl,
        reward_cam: provider.reward_cam,
        status: 'pending',
        expires_at: expiresAt.toISOString(),
        ip_address: clientIp
      })

    if (insertError) {
      console.error('DB Insert Error:', insertError)
      throw insertError
    }

    const response = NextResponse.json({ shortenedUrl })
    response.cookies.set('earn_did', deviceId, { httpOnly: true, sameSite: 'lax', secure: true, path: '/', maxAge: 7200 })
    response.cookies.set('earn_bid', browserId, { httpOnly: true, sameSite: 'lax', secure: true, path: '/', maxAge: 7200 })
    return response
  } catch (error) {
    console.error('Earn generate error:', error)
    return NextResponse.json({ error: 'Đã có lỗi xảy ra trên server.' }, { status: 500 })
  }
}
