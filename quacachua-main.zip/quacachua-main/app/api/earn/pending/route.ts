export const dynamic = 'force-dynamic'
import { NextResponse } from 'next/server'
import { guardApi } from '@/lib/security/api-guard'
import { createAdminClient } from '@/lib/supabase/server'


export async function GET(request: Request) {
  try {
    const guard = await guardApi(request, 'earn_pending', 30, 60)
    if (guard instanceof NextResponse) return guard
    const { user } = guard

    const supabaseAdmin = createAdminClient()

    // Dọn các nhiệm vụ đã hết hạn trước
    const now = new Date()
    await supabaseAdmin
      .from('earn_tasks')
      .delete()
      .eq('user_id', user.id)
      .eq('status', 'pending')
      .lte('expires_at', now.toISOString())

    const { data: pendingTasks, error } = await supabaseAdmin
      .from('earn_tasks')
      .select(`
         id,
         status,
         created_at,
         expires_at,
         provider_code,
        shortened_url,
        earn_providers (
          name
        )
      `)
      .eq('user_id', user.id)
      .eq('status', 'pending')
      .order('created_at', { ascending: false })
      .limit(1)

    if (error) {
      console.error('Error fetching pending task:', error)
      return NextResponse.json({ error: 'Lỗi lấy dữ liệu' }, { status: 500 })
    }

    // Tính completedCounts từ 0h00 VN hôm nay (đồng bộ với logic kiểm tra ở generate route)
    const vnTime = new Date(now.getTime() + 7 * 60 * 60 * 1000)
    const startOfTodayVN = new Date(vnTime)
    startOfTodayVN.setUTCHours(0, 0, 0, 0)
    const startOfDayUTC = new Date(startOfTodayVN.getTime() - 7 * 60 * 60 * 1000)

    const { data: completedTasks } = await supabaseAdmin
      .from('earn_tasks')
      .select('provider_code')
      .eq('user_id', user.id)
      .eq('status', 'completed')
      .gt('created_at', startOfDayUTC.toISOString())

    const completedCounts: Record<string, number> = {}
    if (completedTasks) {
      for (const t of completedTasks) {
        completedCounts[t.provider_code] = (completedCounts[t.provider_code] || 0) + 1
      }
    }

    const laymaCutoff = new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString()
    const { count: laymaCompletedCount } = await supabaseAdmin
      .from('earn_tasks')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id)
      .eq('provider_code', 'layma')
      .eq('status', 'completed')
      .gte('completed_at', laymaCutoff)

    const laymaUnlocked = (laymaCompletedCount || 0) > 0

    if (!pendingTasks || pendingTasks.length === 0) {
      return NextResponse.json({ task: null, completedCounts, laymaUnlocked })
    }

    const task = pendingTasks[0]

    if (new Date(task.expires_at) < now) {
      return NextResponse.json({ task: null, completedCounts, laymaUnlocked })
    }

    const provider = Array.isArray(task.earn_providers) ? task.earn_providers[0] : task.earn_providers

    return NextResponse.json({ 
      task: {
        id: task.id,
        providerCode: task.provider_code,
        providerName: provider?.name || task.provider_code,
        shortenedUrl: task.shortened_url,
        createdAt: task.created_at
      },
      completedCounts,
      laymaUnlocked
    })
  } catch (e) {
    console.error('Pending API error:', e)
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 })
  }
}

