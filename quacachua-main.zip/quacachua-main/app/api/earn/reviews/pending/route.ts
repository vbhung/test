import { NextResponse } from 'next/server'
import { guardApi } from '@/lib/security/api-guard'
import { createAdminClient } from '@/lib/supabase/server'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  try {
    const guard = await guardApi(req, 'earn_reviews_pending', 10, 60)
    if (guard instanceof NextResponse) return guard
    const { user } = guard

    const supabase = createAdminClient()
    const { data, error } = await supabase
      .from('earn_review_queue')
      .select('*')
      .eq('user_id', user.id)
      .eq('status', 'pending')
      .order('created_at', { ascending: false })

    if (error) throw error

    return NextResponse.json({ reviews: data || [] })
  } catch (error) {
    console.error('Earn reviews pending error:', error)
    return NextResponse.json({ error: 'Đã có lỗi xảy ra trên server.' }, { status: 500 })
  }
}
