import { NextResponse } from 'next/server'
import { guardApi } from '@/lib/security/api-guard'


export async function POST(request: Request) {
  try {
    const guard = await guardApi(request, 'earn_cancel', 10, 60)
    if (guard instanceof NextResponse) return guard
    const { user, admin: supabaseAdmin } = guard

    const body = await request.json()
    const { taskId } = body

    if (!taskId) {
      return NextResponse.json({ error: 'Thiếu mã nhiệm vụ' }, { status: 400 })
    }

    const { error } = await supabaseAdmin
      .from('earn_tasks')
      .delete()
      .eq('id', taskId)
      .eq('user_id', user.id)
      .eq('status', 'pending')

    if (error) {
      console.error('Error cancelling task:', error)
      return NextResponse.json({ error: 'Lỗi hủy nhiệm vụ' }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (e) {
    console.error('Cancel API error:', e)
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 })
  }
}
