import { NextResponse } from 'next/server'
import { createClient, createAdminClient } from '@/lib/supabase/server'
import { buyCard } from '@/lib/cardws/api'

export async function POST(req: Request) {
  try {
    const supabase = createClient()
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()

    if (profile?.role !== 'admin') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const { ticketId } = await req.json()
    if (!ticketId) {
      return NextResponse.json({ error: 'Thiếu ticketId' }, { status: 400 })
    }

    const supabaseAdmin = createAdminClient()
    const { data: ticket, error: ticketError } = await supabaseAdmin
      .from('redemptions')
      .select('*')
      .eq('id', ticketId)
      .single()

    if (ticketError || !ticket) {
      return NextResponse.json({ error: 'Không tìm thấy ticket' }, { status: 404 })
    }

    if (ticket.status !== 'pending') {
      return NextResponse.json({ error: 'Ticket đã được xử lý' }, { status: 400 })
    }

    if (ticket.type !== 'phone_card' && ticket.type !== 'game_card') {
      return NextResponse.json({ error: 'Chỉ hỗ trợ mua thẻ cho loại phone_card/game_card' }, { status: 400 })
    }

    const provider = ticket.details?.provider
    const denomination = ticket.details?.denomination

    if (!provider || !denomination) {
      return NextResponse.json({ error: 'Ticket thiếu thông tin nhà mạng/mệnh giá' }, { status: 400 })
    }

    const providerMap: Record<string, string> = {
      viettel: 'Viettel',
      vinaphone: 'Vinaphone',
      mobifone: 'Mobifone',
      vietnamobile: 'Vietnamobile',
      garena: 'Garena',
      zing: 'Zing',
      vcoin: 'Vcoin',
    }

    const serviceCode = providerMap[provider.toLowerCase()]
    if (!serviceCode) {
      return NextResponse.json({ error: `Nhà mạng "${provider}" chưa được hỗ trợ mua tự động` }, { status: 400 })
    }

    const result = await buyCard(serviceCode, denomination, 1)

    if (!result.success) {
      return NextResponse.json({ error: result.message }, { status: 500 })
    }

    const card = result.cards?.[0]

    return NextResponse.json({
      success: true,
      card: card ? { serial: card.serial, code: card.code, name: card.name } : null,
      rawMessage: result.message,
    })
  } catch (err: any) {
    console.error('Buy-card API error:', err)
    return NextResponse.json({ error: 'Lỗi hệ thống khi mua thẻ' }, { status: 500 })
  }
}
