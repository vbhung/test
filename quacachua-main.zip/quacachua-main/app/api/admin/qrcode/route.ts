import { NextResponse } from 'next/server'
import { requireAdminUser } from '@/lib/authz'
import { createAdminClient } from '@/lib/supabase/server'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export async function GET(request: Request) {
  try {
    await requireAdminUser()

    const requestUrl = new URL(request.url)
    const fileName = requestUrl.searchParams.get('file')

    if (!fileName) {
      return NextResponse.json({ error: 'Thiếu tên file QR.' }, { status: 400 })
    }

    const supabaseAdmin = createAdminClient()
    const { data, error } = await supabaseAdmin.storage.from('qrcodes').download(fileName)

    if (error || !data) {
      return NextResponse.json({ error: 'Không tải được ảnh QR.' }, { status: 404 })
    }

    const arrayBuffer = await data.arrayBuffer()

    return new NextResponse(arrayBuffer, {
      status: 200,
      headers: {
        'Content-Type': data.type || 'application/octet-stream',
        'Content-Length': String(arrayBuffer.byteLength),
        'Cache-Control': 'private, max-age=300',
      },
    })
  } catch (error) {
    if (error instanceof Error && (error.message === 'UNAUTHORIZED' || error.message === 'FORBIDDEN')) {
      return NextResponse.json({ error: 'Bạn không có quyền xem QR này.' }, { status: 403 })
    }

    console.error('Admin QR proxy error:', error)
    return NextResponse.json({ error: 'Lỗi hệ thống khi tải QR.' }, { status: 500 })
  }
}
