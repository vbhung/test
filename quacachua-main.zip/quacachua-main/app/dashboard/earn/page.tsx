import React from 'react'
import { createAdminClient, createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { EarnModeTabs } from '@/components/dashboard/EarnModeTabs'

export default async function EarnPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/login')

  const supabaseAdmin = createAdminClient()
  const { data: providers } = await supabaseAdmin
    .from('earn_providers')
    .select('id, name, code, reward_cam, daily_limit')
    .eq('is_active', true)
    .order('created_at', { ascending: true })

  return (
    <div className="dash-section animate-in fade-in duration-500">
      <header className="dash-header">
        <h1 className="dash-header-title">Kiếm Cam</h1>
        <p className="dash-header-subtitle">
          Chọn nhiệm vụ phù hợp và hoàn thành để nhận Cam.
        </p>
      </header>

      <EarnModeTabs providers={providers || []} />
    </div>
  )
}
