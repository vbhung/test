'use client'

import React, { useEffect, useState } from 'react'
import { Award, Clock3, Gift, Medal, RefreshCw, Trophy } from 'lucide-react'

type LeaderboardEntry = {
  period: string
  week_start_vn: string
  week_end_vn: string
  rank: number
  user_id: string
  username: string
  display_name: string
  task_count: number
  generated_at: string
}

type RewardEntry = {
  period: string
  week_start_vn: string
  week_end_vn: string
  rank: number
  task_count: number
  reward_cam: number
  awarded_at: string
}

type WeeklyTopData = {
  schemaMissing?: boolean
  message?: string
  currentWeek?: {
    period: string
    weekStartVN: string
    weekEndVN: string
  }
  leaderboard: LeaderboardEntry[]
  generatedAt: string | null
  nextRefreshAt: string | null
  currentUserEntry: LeaderboardEntry | null
  rewards: RewardEntry[]
  refreshIntervalMinutes: number
  rewardWarning?: string | null
}

const REWARD_RULES = [
  { rank: 'Top 1', reward: '20 Cam' },
  { rank: 'Top 2', reward: '16 Cam' },
  { rank: 'Top 3', reward: '12 Cam' },
  { rank: 'Top 4', reward: '8 Cam' },
  { rank: 'Top 5 - 6', reward: '4 Cam' },
  { rank: 'Top 7 - 10', reward: '2 Cam' },
]

function formatDateTime(value: string | null | undefined) {
  if (!value) return 'Chưa có dữ liệu'
  return new Intl.DateTimeFormat('vi-VN', {
    timeZone: 'Asia/Bangkok',
    dateStyle: 'short',
    timeStyle: 'short',
  }).format(new Date(value))
}

function formatDate(value: string | null | undefined) {
  if (!value) return '...'
  return new Intl.DateTimeFormat('vi-VN', {
    timeZone: 'Asia/Bangkok',
    dateStyle: 'short',
  }).format(new Date(`${value}T00:00:00+07:00`))
}

function rewardForRank(rank: number) {
  if (rank === 1) return 20
  if (rank === 2) return 16
  if (rank === 3) return 12
  if (rank === 4) return 8
  if (rank === 5 || rank === 6) return 4
  if (rank >= 7 && rank <= 10) return 2
  return 0
}

function rankBadge(rank: number) {
  if (rank === 1) return '#f59e0b'
  if (rank === 2) return '#94a3b8'
  if (rank === 3) return '#b45309'
  return 'var(--color-primary)'
}

export default function WeeklyTopPage() {
  const [data, setData] = useState<WeeklyTopData | null>(null)
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [error, setError] = useState('')

  const fetchTop = async (force = false) => {
    if (force) {
      setRefreshing(true)
    } else {
      setLoading(true)
    }
    setError('')
    try {
      const res = await fetch(`/api/weekly-top/status${force ? '?force=1' : ''}`, { cache: 'no-store' })
      const json = await res.json()
      if (!res.ok) {
        setError(json.error || 'Không thể tải top tuần.')
      } else {
        setData(json)
      }
    } catch (e) {
      setError('Lỗi kết nối khi tải top tuần.')
    } finally {
      if (force) {
        setRefreshing(false)
      } else {
        setLoading(false)
      }
    }
  }

  useEffect(() => {
    fetchTop()
  }, [])

  if (loading) {
    return <div style={{ padding: '24px', color: 'var(--color-ink-muted-48)' }}>Đang tải bảng xếp hạng...</div>
  }

  if (error) {
    return (
      <div className="dash-section">
        <div className="dash-alert dash-alert-error">
          <span>{error}</span>
        </div>
        <button className="dash-btn dash-btn-primary" onClick={fetchTop}>Thử lại</button>
      </div>
    )
  }

  if (data?.schemaMissing) {
    return (
      <div className="dash-section">
        <header className="dash-header">
          <h1 className="dash-header-title">Top Vượt Tuần</h1>
          <p className="dash-header-subtitle">Cần chạy SQL trước khi bật hệ thống top tuần.</p>
        </header>
        <div className="dash-alert dash-alert-warning">
          <span>{data.message || 'Cần chạy weekly_top.sql trong Supabase SQL Editor.'}</span>
        </div>
      </div>
    )
  }

  const leaderboard = data?.leaderboard || []
  const currentWeek = data?.currentWeek

  return (
    <div className="dash-section animate-in fade-in duration-500">
      <header className="dash-header">
        <h1 className="dash-header-title" style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <Trophy style={{ color: 'var(--color-primary)' }} />
          Top Vượt Tuần
        </h1>
        <p className="dash-header-subtitle">
          Xếp hạng top 10 người hoàn thành nhiều nhiệm vụ nhất trong tuần theo giờ Việt Nam.
        </p>
      </header>

      <div className="stats-grid" style={{ marginBottom: '24px' }}>
        <div className="stats-card">
          <div className="stats-card-header">
            <div className="stats-card-icon-wrapper"><Clock3 /></div>
          </div>
          <h3 className="stats-card-title">Tuần hiện tại</h3>
          <div className="stats-card-value" style={{ fontSize: '1.25rem' }}>
            {formatDate(currentWeek?.weekStartVN)} - {formatDate(currentWeek?.weekEndVN)}
          </div>
        </div>

        <div className="stats-card">
          <div className="stats-card-header">
            <div className="stats-card-icon-wrapper"><RefreshCw /></div>
          </div>
          <h3 className="stats-card-title">Cập nhật gần nhất</h3>
          <div className="stats-card-value" style={{ fontSize: '1.25rem' }}>
            {formatDateTime(data?.generatedAt)}
          </div>
          <p style={{ marginTop: '8px', color: 'var(--color-ink-muted-48)', font: 'var(--text-fine-print)' }}>
            Cập nhật lại mỗi 3.6 tiếng. Lần tiếp theo: {formatDateTime(data?.nextRefreshAt)}
          </p>
        </div>

        <div className="stats-card">
          <div className="stats-card-header">
            <div className="stats-card-icon-wrapper"><Medal /></div>
          </div>
          <h3 className="stats-card-title">Vị trí của bạn</h3>
          <div className="stats-card-value" style={{ fontSize: '1.25rem' }}>
            {data?.currentUserEntry ? `Top ${data.currentUserEntry.rank}` : 'Chưa vào top 10'}
          </div>
          <p style={{ marginTop: '8px', color: 'var(--color-ink-muted-48)', font: 'var(--text-fine-print)' }}>
            {data?.currentUserEntry ? `${data.currentUserEntry.task_count} nhiệm vụ` : 'Hãy hoàn thành thêm nhiệm vụ để leo bảng.'}
          </p>
        </div>
      </div>

      {data?.rewardWarning && (
        <div className="dash-alert dash-alert-warning" style={{ marginBottom: '24px' }}>
          <span>{data.rewardWarning}</span>
        </div>
      )}

      <div className="stats-card" style={{ padding: 0, overflow: 'hidden', marginBottom: '24px' }}>
        <div style={{ padding: '18px 20px', borderBottom: '1px solid var(--color-hairline)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '12px' }}>
          <div>
            <h2 style={{ font: 'var(--text-heading-3)' }}>Bảng xếp hạng tuần này</h2>
            <p style={{ color: 'var(--color-ink-muted-48)', font: 'var(--text-fine-print)', marginTop: '4px' }}>
              Chỉ tính nhiệm vụ đã hoàn thành thành công trong tuần hiện tại.
            </p>
          </div>
          <button
            className="dash-btn"
            onClick={() => fetchTop(true)}
            disabled={refreshing}
            style={{ border: '1px solid var(--color-hairline)', opacity: refreshing ? 0.7 : 1 }}
          >
            {refreshing ? 'Đang cập nhật...' : 'Tải lại ngay'}
          </button>
        </div>

        {leaderboard.length > 0 ? (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ textAlign: 'left', color: 'var(--color-ink-muted-48)', font: 'var(--text-caption-strong)' }}>
                  <th style={{ padding: '12px 16px' }}>Hạng</th>
                  <th style={{ padding: '12px 16px' }}>Người dùng</th>
                  <th style={{ padding: '12px 16px' }}>Nhiệm vụ</th>
                  <th style={{ padding: '12px 16px' }}>Thưởng nếu giữ hạng</th>
                </tr>
              </thead>
              <tbody>
                {leaderboard.map((entry) => (
                  <tr key={entry.user_id} style={{ borderTop: '1px solid var(--color-hairline)' }}>
                    <td style={{ padding: '14px 16px' }}>
                      <span style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: '36px', height: '36px', borderRadius: '999px', background: rankBadge(entry.rank), color: '#fff', fontWeight: 800 }}>
                        {entry.rank}
                      </span>
                    </td>
                    <td style={{ padding: '14px 16px' }}>
                      <div style={{ font: 'var(--text-body-strong)' }}>{entry.display_name}</div>
                      <div style={{ color: 'var(--color-ink-muted-48)', font: 'var(--text-fine-print)' }}>@{entry.username}</div>
                    </td>
                    <td style={{ padding: '14px 16px', font: 'var(--text-body-strong)' }}>
                      {entry.task_count.toLocaleString('vi-VN')}
                    </td>
                    <td style={{ padding: '14px 16px', color: 'var(--color-primary)', font: 'var(--text-body-strong)' }}>
                      +{rewardForRank(entry.rank)} Cam
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div style={{ padding: '24px', color: 'var(--color-ink-muted-48)' }}>
            Chưa có dữ liệu top tuần. Hệ thống sẽ hiển thị khi có nhiệm vụ hoàn thành.
          </div>
        )}
      </div>

      {data?.rewards && data.rewards.length > 0 && (
        <div className="stats-card" style={{ marginBottom: '24px' }}>
          <h2 style={{ font: 'var(--text-heading-3)', display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
            <Gift width={22} height={22} style={{ color: 'var(--color-primary)' }} />
            Lịch sử nhận thưởng top của bạn
          </h2>
          <div style={{ display: 'grid', gap: '10px' }}>
            {data.rewards.map((reward) => (
              <div key={`${reward.period}-${reward.rank}`} style={{ padding: '12px', border: '1px solid var(--color-hairline)', borderRadius: '10px', display: 'flex', justifyContent: 'space-between', gap: '12px', flexWrap: 'wrap' }}>
                <span>Tuần {reward.period}: Top {reward.rank} với {reward.task_count} nhiệm vụ</span>
                <strong style={{ color: 'var(--color-primary)' }}>+{Number(reward.reward_cam).toFixed(2)} Cam</strong>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="stats-card" style={{ background: 'var(--color-canvas-parchment)' }}>
        <h2 style={{ font: 'var(--text-heading-3)', display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '16px' }}>
          <Award width={22} height={22} style={{ color: 'var(--color-primary)' }} />
          Phần thưởng và quy chế nhận
        </h2>

        <div className="stats-grid" style={{ marginBottom: '18px' }}>
          {REWARD_RULES.map((rule) => (
            <div key={rule.rank} style={{ padding: '12px', borderRadius: '12px', border: '1px solid var(--color-hairline)', background: 'var(--color-canvas)' }}>
              <div style={{ color: 'var(--color-ink-muted-48)', font: 'var(--text-fine-print)' }}>{rule.rank}</div>
              <div style={{ color: 'var(--color-primary)', font: 'var(--text-body-strong)' }}>{rule.reward}</div>
            </div>
          ))}
        </div>

        <ul style={{ display: 'flex', flexDirection: 'column', gap: '8px', paddingLeft: '18px', margin: 0, color: 'var(--color-ink-muted-80)', font: 'var(--text-body)' }}>
          <li>Bảng top tính theo tuần Việt Nam, từ 00:00 Thứ Hai đến 23:59 Chủ Nhật.</li>
          <li>Hệ thống đếm số nhiệm vụ kiếm Cam đã hoàn thành thành công của từng người.</li>
          <li>Bảng xếp hạng được cache và cập nhật lại tối đa mỗi 3.6 tiếng để web tải mượt hơn.</li>
          <li>Sang tuần mới, hệ thống tự xét top 10 của tuần trước và cộng thưởng một lần duy nhất.</li>
          <li>Điều kiện nhận giải: người nằm trong top 10 phải hoàn thành trên 5 nhiệm vụ trong tuần đó.</li>
          <li>Nếu cùng số nhiệm vụ, người đạt mốc sớm hơn sẽ được xếp trước.</li>
        </ul>
      </div>
    </div>
  )
}
