import React from 'react'
import { GlobalNav } from '@/components/layout/GlobalNav'
import { DashboardSidebar } from '@/components/layout/DashboardSidebar'
import { SidebarProvider } from '@/contexts/SidebarContext'
import { createAdminClient, createClient } from '@/lib/supabase/server'
import { ensureUserProfile } from '@/lib/auth/profile'
import GlobalNotificationPopup from '@/components/GlobalNotificationPopup'

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  let profile = null
  if (user) {
    const supabaseAdmin = createAdminClient()
    const { data } = await supabaseAdmin
      .from('profiles')
      .select('display_name, username, role')
      .eq('id', user.id)
      .maybeSingle()
    profile = data

    if (!profile) {
      const repairedProfile = await ensureUserProfile(supabaseAdmin, user)
      if (repairedProfile.profile) {
        profile = {
          display_name: repairedProfile.profile.display_name,
          username: repairedProfile.profile.username,
          role: repairedProfile.profile.role,
        }
      }
    }
  }

  return (
    <SidebarProvider>
      <div className="dash-layout-wrapper">
        <GlobalNav />
        <div className="dash-main-container">
          <DashboardSidebar initialProfile={profile} />
          <main className="dash-main-content">
            {children}
          </main>
        </div>
      </div>
      <GlobalNotificationPopup />
    </SidebarProvider>
  )
}
