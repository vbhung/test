import React from 'react'
import { CamBalanceWidget } from '@/components/dashboard/CamBalanceWidget'
import { StatsCard } from '@/components/dashboard/StatsCard'
import { Users, Link as LinkIcon, HandCoins } from 'lucide-react'
import { createAdminClient, createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { TransactionItem } from '@/components/dashboard/TransactionItem'
import { ensureUserProfile } from '@/lib/auth/profile'

function toSafeNumber(value: number | string | null | undefined) {
  const numberValue = Number(value ?? 0)
  return Number.isFinite(numberValue) ? numberValue : 0
}

export default async function DashboardPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    redirect('/login')
  }

  const supabaseAdmin = createAdminClient()
  const { data: profileData, error: profileError } = await supabaseAdmin
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .maybeSingle()

  let profile = profileData
  if (!profile) {
    console.warn('[DASHBOARD] Missing profile for authenticated user, attempting repair', {
      userId: user.id,
      error: profileError?.message,
    })

    const repairedProfile = await ensureUserProfile(supabaseAdmin, user)
    if (!repairedProfile.profile) {
      console.error('[DASHBOARD] Failed to repair missing profile', {
        userId: user.id,
        code: repairedProfile.code,
        error: repairedProfile.error,
      })
      redirect('/login?error=missing_profile')
    }
    profile = repairedProfile.profile
  }

  // Fetch recent transactions
  const { data: transactions } = await supabaseAdmin
    .from('cam_transactions')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(5)
  const totalEarned = toSafeNumber(profile.cam_total_earned)

  // Stats thuc: so ban be da moi + tong hoa hồng
  const { count: friendsCount } = await supabaseAdmin
    .from('profiles')
    .select('*', { count: 'exact', head: true })
    .eq('referred_by', user.id)

  const { data: referralEarnings } = await supabaseAdmin
    .from('referral_earnings')
    .select('amount')
    .eq('referrer_id', user.id)
  const totalReferralCam = (referralEarnings || []).reduce(
    (sum, r) => sum + Number(r.amount || 0),
    0
  )

  // So link verify da dung (link_verifications used_by)
  const { count: linksUsed } = await supabaseAdmin
    .from('link_verifications')
    .select('*', { count: 'exact', head: true })
    .eq('used_by', user.id)

  // So earn task completed (tinh tong ca link verify + earn task)
  const { count: earnTasks } = await supabaseAdmin
    .from('earn_tasks')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', user.id)
    .eq('status', 'completed')

  const totalClicks = (linksUsed || 0) + (earnTasks || 0)

  return (
    <div className="dash-section animate-in fade-in duration-500">
      <header className="dash-header">
        <h1 className="dash-header-title">Xin chào, {profile.display_name}!</h1>
        <p className="dash-header-subtitle">Chào mừng bạn quay trở lại trung tâm quản lý CamLink.</p>
      </header>

      <section className="dash-section">
        <CamBalanceWidget balance={profile.cam_balance} />
      </section>

      <section className="stats-grid">
        <StatsCard 
          title="Tổng Cam đã kiếm" 
          value={totalEarned.toFixed(2)}
          icon={HandCoins} 
          trend=""
        />
        <StatsCard 
          title="Số bạn bè đã mời" 
          value={String(friendsCount || 0)} 
          icon={Users} 
        />
        <StatsCard 
          title="Lượt vượt link" 
          value={String(totalClicks)} 
          icon={LinkIcon} 
        />
      </section>

      <section className="dash-section" style={{ marginTop: '40px' }}>
        <h2 className="dash-header-subtitle" style={{ marginBottom: '24px', fontSize: '28px', color: 'var(--color-ink)' }}>Hoạt động gần đây</h2>
        
        <div className="bg-canvas border border-[var(--color-hairline)] rounded-[12px] overflow-hidden">
          {(!transactions || transactions.length === 0) ? (
            <div className="empty-state-box border-0">
              Chưa có giao dịch nào phát sinh.
            </div>
          ) : (
            <div className="divide-y divide-[var(--color-hairline)]">
              {transactions.map((tx: any) => (
                <TransactionItem key={tx.id} tx={tx} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
