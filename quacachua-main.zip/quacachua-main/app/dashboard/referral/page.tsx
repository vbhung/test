import React from 'react'
import { createClient, createAdminClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { ReferralClient } from '@/components/dashboard/ReferralClient'

export default async function ReferralPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const supabaseAdmin = createAdminClient()

  // Lấy profile (dùng admin để không bị RLS chặn)
  const { data: profile } = await supabaseAdmin
    .from('profiles')
    .select('referral_code, display_name')
    .eq('id', user.id)
    .maybeSingle()

  // Tổng số bạn bè đã mời (dùng admin để đọc profiles của người khác)
  const { data: referredProfiles } = await supabaseAdmin
    .from('profiles')
    .select('id')
    .eq('referred_by', user.id)

  const allFriends = referredProfiles || []
  const allFriendIds = allFriends.map((p) => p.id)

  // Trong số đó, ai đã làm ít nhất 1 earn_task hoàn thành
  let activeFriendIds: string[] = []
  if (allFriendIds.length > 0) {
    const { data: activeTasks } = await supabaseAdmin
      .from('earn_tasks')
      .select('user_id')
      .in('user_id', allFriendIds)
      .eq('status', 'completed')

    // Dùng Set để đếm distinct user
    activeFriendIds = [...new Set((activeTasks || []).map((t) => t.user_id))]
  }

  const totalFriends = allFriendIds.length
  const activeFriends = activeFriendIds.length
  const inactiveFriends = totalFriends - activeFriends

  // Tổng hoa hồng nhận được
  const { data: earnings } = await supabaseAdmin
    .from('referral_earnings')
    .select('amount')
    .eq('referrer_id', user.id)

  const totalReferralCam = (earnings || []).reduce(
    (sum, r) => sum + Number(r.amount || 0),
    0
  )

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://quacachua.shop'

  return (
    <ReferralClient
      referralCode={profile?.referral_code || ''}
      siteUrl={siteUrl}
      totalFriends={totalFriends}
      activeFriends={activeFriends}
      inactiveFriends={inactiveFriends}
      totalReferralCam={totalReferralCam}
    />
  )
}
