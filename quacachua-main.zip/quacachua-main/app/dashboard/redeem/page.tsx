'use client'

import React, { useState, useRef, useEffect } from 'react'
import { Gift, CreditCard, Gamepad2, Smartphone, AlertCircle, CheckCircle2, UploadCloud, X } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { createRedeemTicket } from '@/app/actions/redeem'
import { TermsModal } from '@/components/ui/TermsModal'

const REDEEM_OPTIONS = [
  { id: 'phone_card', label: 'Thẻ Điện Thoại', icon: Smartphone, rate: 250 },
  { id: 'game_card', label: 'Thẻ Game', icon: Gamepad2, rate: 250 },
  { id: 'bank', label: 'Rút Ngân Hàng', icon: CreditCard, rate: 200 },
]

const PHONE_PROVIDERS: Record<string, number[]> = {
  'Viettel': [10000, 20000, 30000, 50000, 100000, 200000, 300000, 500000],
  'Vinaphone': [10000, 20000, 50000, 100000, 200000, 300000, 500000],
  'Mobifone': [10000, 20000, 30000, 50000, 100000, 200000, 300000, 500000],
  'Vietnamobile': [10000, 20000, 50000, 100000, 200000, 500000]
}

const GAME_PROVIDERS: Record<string, number[]> = {
  'Garena': [5000, 10000, 20000, 50000, 100000, 200000, 500000],
  'Zing': [10000, 20000, 50000, 100000, 200000, 500000, 1000000],
  'Vcoin': [10000, 20000, 50000, 100000, 200000, 500000]
}

export default function RedeemPage() {
  const [activeTab, setActiveTab] = useState('phone_card')
  const [amount, setAmount] = useState('') // For bank
  const [info, setInfo] = useState('') // For bank
  const [file, setFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState('')
  const [error, setError] = useState('')
  const [isDragging, setIsDragging] = useState(false)
  
  const [provider, setProvider] = useState('')
  const [denomination, setDenomination] = useState<number>(0)

  const [showTerms, setShowTerms] = useState(false)
  const [agreed, setAgreed] = useState(false)
  const [captchaToken, setCaptchaToken] = useState('')

  const fileInputRef = useRef<HTMLInputElement>(null)

  const activeOption = REDEEM_OPTIONS.find(o => o.id === activeTab)
  const supabase = createClient()
  const bankRate = activeTab === 'bank' ? (file ? 220 : 200) : (activeOption?.rate || 0)
  const bankRateLabel = activeTab === 'bank'
    ? `1 Cam = ${(file ? 220 : 200).toLocaleString('vi-VN')} VNĐ${file ? ' (có QR)' : ' (không QR)'}`
    : `1 Cam = ${activeOption?.rate.toLocaleString('vi-VN')} VNĐ`

  // Reset states when tab changes
  useEffect(() => {
    setSuccess('')
    setError('')
    setFile(null)
    setPreviewUrl(null)
    setProvider('')
    setDenomination(0)
    setAmount('')
    setInfo('')
    // agreed and captchaToken can persist across tabs
  }, [activeTab])

  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      if (activeTab !== 'bank') return
      const items = e.clipboardData?.items
      if (!items) return
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const blob = items[i].getAsFile()
          if (blob) {
            setFile(blob)
            setPreviewUrl(URL.createObjectURL(blob))
          }
          break
        }
      }
    }
    document.addEventListener('paste', handlePaste)
    return () => document.removeEventListener('paste', handlePaste)
  }, [activeTab])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      setFile(selectedFile)
      setPreviewUrl(URL.createObjectURL(selectedFile))
    }
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    if (activeTab !== 'bank') return
    const droppedFile = e.dataTransfer.files?.[0]
    if (droppedFile && droppedFile.type.startsWith('image/')) {
      setFile(droppedFile)
      setPreviewUrl(URL.createObjectURL(droppedFile))
    }
  }

  const clearFile = () => {
    setFile(null)
    setPreviewUrl(null)
    if (fileInputRef.current) fileInputRef.current.value = ''
  }

  const handleRedeem = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setSuccess('')
    setError('')

    if (!agreed || !captchaToken) {
      setError('Vui lòng đồng ý Điều khoản và xác minh Captcha.')
      setLoading(false)
      return
    }

    let numAmount = 0
    let amountVnd = 0
    let detailsObj: any = {}

    if (activeTab === 'bank') {
      numAmount = Number(amount)
      if (numAmount < 44) {
        setError('Số tiền rút tối thiểu là 44 Cam.')
        setLoading(false)
        return
      }
      if (!file && !info) {
        setError('Vui lòng nhập Thông tin ngân hàng hoặc tải lên Mã QR.')
        setLoading(false)
        return
      }

      let qrCodeUrl = ''
      if (file) {
        const fileExt = file.name.split('.').pop()
        const { data: { user } } = await supabase.auth.getUser()
        if (!user) {
          setError('Không thể xác thực tài khoản.')
          setLoading(false)
          return
        }
        const fileName = `${user.id}/${crypto.randomUUID()}.${fileExt || 'png'}`
        const { error: uploadError } = await supabase.storage
          .from('qrcodes')
          .upload(fileName, file)

        if (uploadError) {
          setError('Lỗi upload ảnh QR code: ' + uploadError.message)
          setLoading(false)
          return
        }

        // Dung path de tao signed URL sau, KHONG luu public URL
        qrCodeUrl = `${fileName}`
      }

      amountVnd = numAmount * bankRate
      detailsObj = {
        info,
        ...(qrCodeUrl && { qrCodeUrl }),
      }
    } else {
      // Phone or Game card
      if (!provider || !denomination) {
        setError('Vui lòng chọn Loại thẻ và Mệnh giá.')
        setLoading(false)
        return
      }
      amountVnd = denomination
      numAmount = Math.ceil(denomination / (activeOption?.rate || 250))
      detailsObj = {
        provider,
        denomination,
      }
    }

    const res = await createRedeemTicket({
      type: activeTab as any,
      amountCam: numAmount,
      amountVnd,
      details: detailsObj,
      captchaToken,
    })

    if (res?.error) {
      setError(res.error)
    } else {
      setSuccess(`Đã tạo yêu cầu rút ${numAmount} Cam qua ${activeOption?.label}. Quản trị viên sẽ xử lý sớm nhất.`)
      setAmount('')
      setInfo('')
      setProvider('')
      setDenomination(0)
      clearFile()
    }
    
    setLoading(false)
  }

  const providersMap = activeTab === 'phone_card' ? PHONE_PROVIDERS : GAME_PROVIDERS
  const providersList = Object.keys(providersMap)
  const denominationsList = provider && providersMap[provider] ? providersMap[provider] : []

  return (
    <div className="dash-section animate-in fade-in duration-500">
      <header className="dash-header">
        <h1 className="dash-header-title">Rút Cam</h1>
        <p className="dash-header-subtitle">Quy đổi Cam thành tiền mặt, thẻ cào điện thoại hoặc thẻ game.</p>
      </header>

      <div className="dash-tab-container">
        {REDEEM_OPTIONS.map((opt) => (
          <button
            key={opt.id}
            onClick={() => setActiveTab(opt.id)}
            className={`dash-tab ${activeTab === opt.id ? 'active' : ''}`}
          >
            <opt.icon style={{ width: '20px', height: '20px', marginRight: '8px' }} />
            {opt.label}
          </button>
        ))}
      </div>

      <div className="stats-card">
        {success && (
          <div className="dash-alert dash-alert-success">
            <CheckCircle2 className="dash-alert-icon" />
            <span>{success}</span>
          </div>
        )}

        {error && (
          <div className="dash-alert dash-alert-error">
            <AlertCircle className="dash-alert-icon" />
            <span>{error}</span>
          </div>
        )}

        <div className="dash-alert dash-alert-warning" style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', maxWidth: '500px', margin: '0 auto 24px auto' }}>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: activeTab === 'bank' ? '8px' : '0' }}>
            <AlertCircle className="dash-alert-icon" />
            <div>
              Tỷ giá quy đổi: <br/>
              <strong style={{ fontSize: '1.125rem' }}>{bankRateLabel}</strong>
            </div>
          </div>
          {activeTab === 'bank' && (
            <div className="dash-alert dash-alert-error" style={{ width: '100%', marginTop: '8px', padding: '12px', marginBottom: '0', display: 'block' }}>
              <strong>LƯU Ý QUAN TRỌNG:</strong> Xin vui lòng điền thật chính xác thông tin nhận tiền. Nếu yêu cầu rút bị từ chối do thông tin sai lệch, bạn sẽ bị <strong>trừ 1 Cam</strong> phí làm phiền khi hoàn tiền.
            </div>
          )}
        </div>

        <form onSubmit={handleRedeem} style={{ maxWidth: '500px', margin: '0 auto' }}>
          {activeTab === 'bank' ? (
            <>
                <div className="dash-form-group">
                <label className="dash-label">Số lượng Cam cần rút</label>
                <div style={{ position: 'relative' }}>
                  <input 
                    type="number" 
                    step="1"
                    min="44"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Tối thiểu 44 Cam" 
                    className="dash-input"
                    style={{ paddingRight: '60px' }}
                    required
                  />
                  <span style={{ position: 'absolute', right: '16px', top: '12px', color: 'var(--color-ink-muted-48)', font: 'var(--text-body-strong)' }}>Cam</span>
                </div>
                <p style={{ marginTop: '8px', color: 'var(--color-ink-muted-48)', font: 'var(--text-fine-print)' }}>
                  Sẽ nhận được khoảng: <strong style={{ color: 'var(--color-primary)' }}>{amount ? (Number(amount) * bankRate).toLocaleString('vi-VN') : '0'} VNĐ</strong>
                </p>
                <p style={{ marginTop: '4px', color: 'var(--color-ink-muted-48)', font: 'var(--text-fine-print)', fontSize: '12px' }}>
                  <span style={file ? { textDecoration: 'line-through', opacity: 0.5 } : {}}>Không QR: 1 Cam = 200đ</span>
                  &nbsp;|&nbsp;
                  <span style={!file ? { textDecoration: 'line-through', opacity: 0.5 } : {}}>Có QR: 1 Cam = 220đ</span>
                </p>
              </div>

              <div className="dash-form-group">
                <label className="dash-label">
                  Thông tin Ngân hàng (Không bắt buộc nếu đã tải QR Code)
                </label>
                <textarea 
                  value={info}
                  onChange={(e) => setInfo(e.target.value)}
                  placeholder="VD: Vietcombank - 0123456789 - NGUYEN VAN A"
                  className="dash-input"
                  style={{ minHeight: '100px', resize: 'vertical' }}
                  required={!file}
                />
              </div>

              <div className="dash-form-group">
                <label className="dash-label">
                  Ảnh mã QR Code nhận tiền (Kéo thả, Paste hoặc Chọn ảnh)
                  <span style={{ display: 'block', color: 'var(--color-ink-muted-48)', fontSize: '12px', fontWeight: 'normal', marginTop: '4px' }}>
                    * Lưu ý: Ngoài việc điền đúng thông tin, hình ảnh QR Code phải rõ nét để admin duyệt nhanh nhất.
                  </span>
                </label>
                <div 
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  onClick={() => !file && fileInputRef.current?.click()}
                  style={{
                    border: `2px dashed ${isDragging ? 'var(--color-primary)' : 'var(--color-hairline)'}`,
                    backgroundColor: isDragging ? 'rgba(238, 114, 20, 0.05)' : 'var(--color-canvas)',
                    borderRadius: 'var(--rounded-lg)',
                    padding: '24px',
                    textAlign: 'center',
                    cursor: file ? 'default' : 'pointer',
                    transition: 'all 0.2s ease',
                    position: 'relative'
                  }}
                >
                  <input 
                    type="file" 
                    accept="image/*"
                    onChange={handleFileChange}
                    ref={fileInputRef}
                    style={{ display: 'none' }}
                  />
                  
                  {previewUrl ? (
                    <div style={{ position: 'relative', display: 'inline-block' }}>
                      <img src={previewUrl} alt="QR Code Preview" style={{ maxWidth: '100%', maxHeight: '200px', borderRadius: '8px' }} />
                      <button 
                        type="button"
                        onClick={(e) => { e.stopPropagation(); clearFile(); }}
                        style={{
                          position: 'absolute', top: '-8px', right: '-8px',
                          background: 'var(--color-error)', color: 'white', border: 'none',
                          borderRadius: '50%', width: '24px', height: '24px',
                          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer'
                        }}
                      >
                        <X width={14} height={14} />
                      </button>
                    </div>
                  ) : (
                    <div style={{ color: 'var(--color-ink-muted-48)' }}>
                      <UploadCloud width={32} height={32} style={{ margin: '0 auto 8px', color: 'var(--color-primary)' }} />
                      <p style={{ font: 'var(--text-body-strong)' }}>Bấm để chọn ảnh hoặc Kéo thả vào đây</p>
                      <p style={{ font: 'var(--text-fine-print)', marginTop: '4px' }}>Hỗ trợ dán (Ctrl+V) ảnh từ Clipboard</p>
                    </div>
                  )}
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="dash-form-group">
                <label className="dash-label">Nhà cung cấp</label>
                <select 
                  value={provider}
                  onChange={(e) => setProvider(e.target.value)}
                  className="dash-input"
                  required
                >
                  <option value="">-- Chọn loại thẻ --</option>
                  {providersList.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>

              <div className="dash-form-group">
                <label className="dash-label">Mệnh giá</label>
                <select 
                  value={denomination || ''}
                  onChange={(e) => setDenomination(Number(e.target.value))}
                  className="dash-input"
                  required
                >
                  <option value="">-- Chọn mệnh giá --</option>
                  {denominationsList.map(d => <option key={d} value={d}>{d.toLocaleString('vi-VN')}đ</option>)}
                </select>
                
                {denomination > 0 && (
                  <p style={{ marginTop: '8px', color: 'var(--color-ink-muted-48)', font: 'var(--text-fine-print)' }}>
                    Chi phí: <strong style={{ color: 'var(--color-primary)' }}>{Math.ceil(denomination / (activeOption?.rate || 250))} Cam</strong>
                  </p>
                )}
              </div>
              
              <div style={{ padding: '12px', backgroundColor: 'var(--color-canvas-parchment)', borderRadius: '8px', fontSize: '13px', color: 'var(--color-ink-muted-80)' }}>
                <strong>Lưu ý:</strong> Mã thẻ và Số Serial sẽ được Admin gửi trực tiếp vào mục Thông báo của bạn sau khi duyệt thành công.
              </div>
            </>
          )}

          <div style={{ display: 'flex', alignItems: 'center', marginTop: '24px', marginBottom: '16px' }}>
            <input 
              type="checkbox" 
              id="termsCheck" 
              checked={agreed}
              onChange={(e) => {
                if (e.target.checked && !agreed) {
                  setShowTerms(true)
                } else {
                  setAgreed(false)
                  setCaptchaToken('')
                }
              }}
              style={{ marginRight: '8px', cursor: 'pointer' }}
            />
            <label htmlFor="termsCheck" style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-80)' }}>
              Tôi đồng ý với <a href="#" onClick={(e) => { e.preventDefault(); setShowTerms(true); }} style={{ color: 'var(--color-primary)' }}>Điều khoản Sử dụng Dịch vụ</a>
            </label>
          </div>

          <button 
            type="submit" 
            disabled={loading || !agreed}
            className="dash-btn dash-btn-primary"
            style={{ width: '100%' }}
          >
            {loading ? 'Đang gửi yêu cầu...' : 'Tạo Yêu Cầu Rút Cam'}
          </button>
        </form>

        <div className="stats-card" style={{ maxWidth: '500px', margin: '24px auto 0 auto', padding: '16px', background: 'var(--color-canvas-parchment)' }}>
          <h2 style={{ font: 'var(--text-body-strong)', marginBottom: '10px' }}>Nội quy rút thưởng mới</h2>
          <ul style={{ display: 'flex', flexDirection: 'column', gap: '8px', paddingLeft: '18px', margin: 0, color: 'var(--color-ink-muted-80)', font: 'var(--text-body)' }}>
            <li>Rút thẻ cào (thẻ điện thoại, thẻ game) không cần điều kiện mời bạn.</li>
            <li>Rút ngân hàng có 3 lần đầu không cần điều kiện mời bạn.</li>
            <li>Sau khi hết lượt miễn điều kiện, rút dưới 51.000đ cần ít nhất 1 người được mời hợp lệ.</li>
            <li>Rút từ 51.000đ đến 100.000đ cần ít nhất 3 người được mời hợp lệ.</li>
            <li>Rút từ 101.000đ đến 500.000đ cần ít nhất 5 người được mời hợp lệ.</li>
            <li>Rút trên 500.000đ cần ít nhất 10 người được mời hợp lệ.</li>
            <li>Người được mời chỉ được tính hợp lệ sau khi đã hoàn thành ít nhất 1 nhiệm vụ kiếm Cam.</li>
            <li>Số người mời hợp lệ không bị reset sau khi rút. Nếu bạn đã đủ mốc 3 người, các lần rút cùng mốc đó về sau không cần mời thêm.</li>
            <li>Sau khi tạo yêu cầu rút thành công, bạn cần chờ 12 giờ mới được rút tiếp.</li>
          </ul>
        </div>
      </div>

      <TermsModal 
        isOpen={showTerms} 
        onClose={() => setShowTerms(false)} 
        onAccept={(token) => {
          setCaptchaToken(token)
          setAgreed(true)
          setShowTerms(false)
        }} 
      />
    </div>
  )
}
