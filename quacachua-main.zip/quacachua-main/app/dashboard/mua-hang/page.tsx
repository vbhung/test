'use client'

import React, { useState, useEffect, useRef } from 'react'
import { ShoppingCart, Info } from 'lucide-react'

export default function MuaHangPage() {
  const [token, setToken] = useState('')
  const [loading, setLoading] = useState(true)
  const scriptInjected = useRef(false)

  useEffect(() => {
    fetch('/api/cashback/config')
      .then(r => r.json())
      .then(d => {
        if (d.token) {
          setToken(d.token)
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    if (!token || scriptInjected.current) return
    scriptInjected.current = true
    if ((window as any).__pcsLoaded) return
    ;(window as any).__pcsLoaded = true

    const script = document.createElement('script')
    script.src = `https://phienchoso.com/api/ketnoi_api.php?token=${encodeURIComponent(token)}&url=${encodeURIComponent(window.location.href)}`
    script.async = true
    document.body.appendChild(script)

    const poll = setInterval(() => {
      const root = document.getElementById('CSHH_COM')
      if (!root || !root.querySelector('*')) return
      clearInterval(poll)

      const readVar = (name: string, fallback: string) =>
        getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback

      const apply = () => {
        const bg = readVar('--color-canvas', '#18181b')
        const text = readVar('--color-ink', '#e4e4e7')
        root.style.setProperty('background', bg, 'important')
        root.querySelectorAll('*').forEach(el => {
          const html = el as HTMLElement
          const s = html.style
          const oldBg = s.getPropertyValue('background-color') || s.getPropertyValue('background')
          const oldColor = s.getPropertyValue('color')
          if (oldBg && (oldBg.includes('#fff') || oldBg.includes('rgb(255') || oldBg === 'white')) {
            s.setProperty('background-color', bg, 'important')
          }
          if (oldColor && (oldColor.includes('#000') || oldColor.includes('rgb(0,') || oldColor === 'black')) {
            s.setProperty('color', text, 'important')
          }
        })
      }
      apply()
      const obs = new MutationObserver(apply)
      obs.observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ['style'] })
    }, 500)
  }, [token])

  return (
    <div className="dash-content-inner" style={{ maxWidth: '900px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '24px' }}>
        <div style={{ width: '48px', height: '48px', borderRadius: '12px', backgroundColor: 'var(--color-success-bg)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <ShoppingCart size={24} style={{ color: 'var(--color-primary)' }} />
        </div>
        <div>
          <h1 style={{ font: 'var(--text-title)', fontSize: '24px' }}>Mua Hàng Hoàn Tiền</h1>
          <p style={{ color: 'var(--color-ink-muted-80)', fontSize: '14px' }}>Tìm kiếm sản phẩm, mua hàng và nhận hoàn tiền trực tiếp</p>
        </div>
      </div>

      {loading && (
        <div style={{ padding: '40px', textAlign: 'center', color: 'var(--color-ink-muted-60)' }}>Đang tải...</div>
      )}

      {!loading && token && (
        <>
          <div id="CSHH_COM" className="MAIN-CSHH-COM" token={token} />

          <style>{`
            #CSHH_COM, #CSHH_COM * {
              border-color: var(--color-hairline) !important;
            }
            #CSHH_COM { background: var(--color-canvas); }
            #CSHH_COM div, #CSHH_COM span, #CSHH_COM p, #CSHH_COM h1, #CSHH_COM h2, #CSHH_COM h3,
            #CSHH_COM label, #CSHH_COM li, #CSHH_COM td, #CSHH_COM th {
              color: var(--color-ink) !important;
              font-family: var(--font-family) !important;
            }
            #CSHH_COM input, #CSHH_COM textarea, #CSHH_COM select {
              background: var(--color-canvas-parchment) !important;
              border: 1px solid var(--color-hairline) !important;
              border-radius: 8px !important;
              color: var(--color-ink) !important;
              padding: 8px 12px !important;
            }
            #CSHH_COM input:focus {
              border-color: var(--color-primary) !important;
              outline: none !important;
            }
            #CSHH_COM button, #CSHH_COM [class*="btn"], #CSHH_COM [class*="button"] {
              background: var(--color-primary) !important;
              color: #fff !important;
              border: none !important;
              border-radius: 8px !important;
              padding: 8px 16px !important;
              cursor: pointer !important;
              font-weight: 600 !important;
            }
            #CSHH_COM a { color: var(--color-primary) !important; text-decoration: none !important; }
            #CSHH_COM a:hover { text-decoration: underline !important; }
            #CSHH_COM [class*="price"] { color: var(--color-primary) !important; font-weight: 600 !important; }
            #CSHH_COM [class*="muted"], #CSHH_COM [class*="small"], #CSHH_COM [class*="desc"],
            #CSHH_COM .loi_cshh {
              color: var(--color-ink-muted-48) !important;
            }
          `}</style>

          <div style={{ marginTop: '20px', backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-hairline)', borderRadius: '12px', padding: '24px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '16px' }}>
              <Info size={18} style={{ color: 'var(--color-primary)' }} />
              <h2 style={{ fontSize: '18px', fontWeight: 600 }}>Điều kiện để được ghi nhận hoàn tiền</h2>
            </div>
            <div style={{ fontSize: '14px', lineHeight: 1.7, color: 'var(--color-ink-muted-80)' }}>
              <ol style={{ paddingLeft: '20px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                <li>
                  <strong>Bước 1:</strong> Bắt buộc phải <strong>"Dán link"</strong> sản phẩm TikTok để kiểm tra hoàn tiền. Sau đó nhấn <strong>"Mua hàng"</strong> để gắn tag hoàn tiền và mở đúng kênh TikTok của Chia sẻ hoa hồng.
                </li>
                <li>
                  <strong>Bước 2:</strong> Trên kênh TikTok vừa mở, vào <strong>"Phần trưng bày"</strong>, tìm sản phẩm trong mục <strong>"Đề xuất"</strong> hoặc <strong>"Lựa chọn của nhà sáng tạo"</strong>, sau đó thêm vào giỏ hàng và tiến hành đặt hàng.
                </li>
                <li>
                  <strong>Bước 3:</strong> Với mỗi sản phẩm cần mua, bạn phải lặp lại đầy đủ các bước: <strong>"Dán link"</strong> → nhấn <strong>"Mua ngay"</strong> (để gắn tag) → thêm vào giỏ hàng từ <strong>"Phần trưng bày"</strong>.
                  <div style={{ marginTop: '8px', padding: '10px 14px', backgroundColor: 'var(--color-warning-bg)', borderRadius: '8px', border: '1px solid var(--color-warning)', fontSize: '13px', color: 'var(--color-ink-muted-80)' }}>
                    <strong>Lưu ý:</strong> Nếu không thực hiện đúng quy trình trên, đơn hàng sẽ không được ghi nhận hoàn tiền.
                  </div>
                </li>
                <li>
                  <strong>Bước 4:</strong> Trường hợp đã làm đúng nhưng chưa thấy hoàn tiền, hãy copy mã đơn hàng TikTok và nhấn <strong>"Tìm đơn TikTok"</strong> để kiểm tra chính xác.
                </li>
              </ol>
            </div>
          </div>
        </>
      )}

      {!loading && !token && (
        <div style={{ padding: '40px', textAlign: 'center', color: 'var(--color-ink-muted-60)' }}>Chưa cấu hình</div>
      )}
    </div>
  )
}
