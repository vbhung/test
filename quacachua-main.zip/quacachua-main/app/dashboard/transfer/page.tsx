'use client'

import React, { useState } from 'react'
import { Send, AlertCircle } from 'lucide-react'

export default function TransferPage() {
  const [recipient, setRecipient] = useState('')
  const [amount, setAmount] = useState('')
  const [note, setNote] = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState('')
  const [error, setError] = useState('')

  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    setSuccess('')

    if (Number(amount) <= 0) {
      setError('Số tiền chuyển phải lớn hơn 0')
      setLoading(false)
      return
    }
    if (!recipient) {
      setError('Vui lòng nhập Username người nhận')
      setLoading(false)
      return
    }

    try {
      const res = await fetch('/api/wallet/transfer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recipient, amount, note })
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Có lỗi xảy ra khi chuyển Cam.')
      } else {
        setSuccess(data.message || `Đã chuyển thành công ${amount} Cam cho ${recipient}.`)
        setRecipient('')
        setAmount('')
        setNote('')
        
        // Refresh page slightly delayed to update balance widget
        setTimeout(() => {
          window.location.reload()
        }, 2000)
      }
    } catch (err: any) {
      setError('Lỗi kết nối. Vui lòng thử lại.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="dash-section animate-in fade-in duration-500">
      <header className="dash-header">
        <h1 className="dash-header-title">Chuyển Cam</h1>
        <p className="dash-header-subtitle">Chuyển số dư nội bộ cho người dùng khác qua Username (Phí: 1 Cam/Giao dịch).</p>
      </header>

      <div className="stats-card">
        {success && (
          <div className="dash-alert dash-alert-success">
            <Send className="dash-alert-icon" />
            {success}
          </div>
        )}

        {error && (
          <div className="dash-alert dash-alert-error">
            <AlertCircle className="dash-alert-icon" />
            {error}
          </div>
        )}

        <form onSubmit={handleTransfer} style={{ maxWidth: '500px', margin: '0 auto' }}>
          <div className="dash-form-group">
            <label className="dash-label">Username người nhận</label>
            <input 
              type="text" 
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              placeholder="Nhập tên đăng nhập (VD: nguyenvana123)" 
              className="dash-input"
              required
            />
          </div>

          <div className="dash-form-group">
            <label className="dash-label">Số lượng Cam cần chuyển</label>
            <div style={{ position: 'relative' }}>
              <input 
                type="number" 
                step="0.01"
                min="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00" 
                className="dash-input"
                style={{ paddingRight: '60px' }}
                required
              />
              <span style={{ position: 'absolute', right: '16px', top: '12px', color: 'var(--color-ink-muted-48)', font: 'var(--text-body-strong)' }}>Cam</span>
            </div>
            <p style={{ marginTop: '8px', color: 'var(--color-ink-muted-48)', font: 'var(--text-fine-print)' }}>Thực nhận: {amount ? Math.max(0, Number(amount) - 1).toFixed(2) : '0.00'} Cam (Phí: 1 Cam)</p>
          </div>

          <div className="dash-form-group">
            <label className="dash-label">Ghi chú (Tùy chọn)</label>
            <input 
              type="text" 
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Nhập lời nhắn..." 
              className="dash-input"
              maxLength={100}
            />
          </div>

          <button 
            type="submit" 
            disabled={loading}
            className="dash-btn dash-btn-primary"
            style={{ width: '100%', marginTop: '16px' }}
          >
            {loading ? 'Đang xử lý...' : 'Xác nhận Chuyển'}
          </button>
        </form>
      </div>
    </div>
  )
}
