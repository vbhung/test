'use client'

import React, { useState, useEffect, useRef, useMemo } from 'react'
import { Anchor, Loader2 } from 'lucide-react'

const RAW_URL = (process.env.NEXT_PUBLIC_BATTLESHIP_WORKER_URL || '').replace(/\/+$/, '')
const WORKER_URL = RAW_URL ? RAW_URL : ''
const GAME_BASE = WORKER_URL ? `${WORKER_URL}/game` : ''

type Tier = 'little' | 'middle' | 'large'

interface BetOption {
  amount: number
  tier: Tier
  label: string
}

interface SessionData {
  token: string
  tier: Tier
  amount: number
  matchId?: string
  createdAt: number
}

const TIER_META: Record<Tier, { label: string; desc: string }> = {
  little: { label: 'Little', desc: '10×10 · Tàu tự động · 5 tàu' },
  middle: { label: 'Middle', desc: '10×10 · Tự xếp tàu · 5 tàu' },
  large: { label: 'Large', desc: '20×20 · Tự xếp tàu · 8 tàu' },
}

const BET_OPTIONS: BetOption[] = [
  { amount: 4, tier: 'little', label: '4 CAM' },
  { amount: 12, tier: 'little', label: '12 CAM' },
  { amount: 20, tier: 'middle', label: '20 CAM' },
  { amount: 40, tier: 'middle', label: '40 CAM' },
  { amount: 80, tier: 'large', label: '80 CAM' },
  { amount: 200, tier: 'large', label: '200 CAM' },
]

const TIER_ORDER: Tier[] = ['little', 'middle', 'large']

type Selection = { amount: number; tier: Tier }

function saveSession(token: string, tier: Tier, amount: number, matchId?: string) {
  const data: SessionData = { token, tier, amount, matchId, createdAt: Date.now() }
  try { sessionStorage.setItem('battleship_session', JSON.stringify(data)) } catch {}
}

function clearSession() {
  try { sessionStorage.removeItem('battleship_session') } catch {}
}

function loadSession(): SessionData | null {
  try {
    const raw = sessionStorage.getItem('battleship_session')
    if (!raw) return null
    const data = JSON.parse(raw) as SessionData
    if (Date.now() - data.createdAt > 1800 * 1000) {
      clearSession()
      return null
    }
    return data
  } catch {
    return null
  }
}

export default function BattleshipPage() {
  const [token, setToken] = useState<string | null>(null)
  const [selection, setSelection] = useState<Selection | null>(null)
  const [selectedBet, setSelectedBet] = useState<BetOption | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const iframeRef = useRef<HTMLIFrameElement>(null)
  const tokenRef = useRef<string | null>(null)
  const selectionRef = useRef<Selection | null>(null)
  const reconnectMatchIdRef = useRef<string | null>(null)

  const leaveGame = () => {
    setToken(null); setSelection(null); setSelectedBet(null)
    tokenRef.current = null; selectionRef.current = null; reconnectMatchIdRef.current = null
    clearSession()
  }

  const startGame = async (bet: BetOption) => {
    setLoading(true)
    setError('')
    setSelectedBet(bet)
    setSelection(bet)
    try {
      const res = await fetch('/api/battleship/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: bet.amount }),
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error || 'Lỗi tạo token')
        return
      }
      tokenRef.current = data.token
      selectionRef.current = bet
      saveSession(data.token, bet.tier, bet.amount)
      setToken(data.token)
    } catch {
      setError('Lỗi kết nối')
    } finally {
      setLoading(false)
    }
  }

  // Restore session on mount
  useEffect(() => {
    const session = loadSession()
    if (session) {
      tokenRef.current = session.token
      selectionRef.current = { amount: session.amount, tier: session.tier }
      setSelection({ amount: session.amount, tier: session.tier })
      if (session.matchId) {
        reconnectMatchIdRef.current = session.matchId
        setToken(session.token)
      }
    }
  }, [])

  // Build iframe src with init data in URL hash
  const gameSrc = useMemo(() => {
    if (!token || !selection) return GAME_BASE
    const data: Record<string, unknown> = {
      token: tokenRef.current,
      betTier: selection.tier,
      amount: selection.amount,
    }
    if (reconnectMatchIdRef.current) {
      data.reconnectMatchId = reconnectMatchIdRef.current
    }
    return GAME_BASE + '?init=' + encodeURIComponent(btoa(JSON.stringify(data)))
  }, [token, selection])

  // Listen for matchState/ended from iframe
  useEffect(() => {
    if (!token || !WORKER_URL) return
    const handler = (e: MessageEvent) => {
      if (e.origin !== WORKER_URL) return
      if (e.data?.type === 'battleship:matchState' && e.data.matchId && selectionRef.current) {
        reconnectMatchIdRef.current = e.data.matchId
        saveSession(tokenRef.current!, selectionRef.current.tier, selectionRef.current.amount, e.data.matchId)
      }
      if (e.data?.type === 'battleship:ended') {
        clearSession()
      }
    }
    window.addEventListener('message', handler)
    return () => window.removeEventListener('message', handler)
  }, [token])

  if (!WORKER_URL) {
    return (
      <div style={{ padding: '24px' }}>
        <p style={{ color: 'var(--color-ink-muted-48)' }}>
          Battleship chưa được cấu hình. Thiếu NEXT_PUBLIC_BATTLESHIP_WORKER_URL.
        </p>
      </div>
    )
  }

  return (
    <div style={{ padding: '24px', maxWidth: '1200px', margin: '0 auto' }}>
      <div style={{ marginBottom: '24px' }}>
        <h1 style={{ fontSize: '28px', fontWeight: 600, letterSpacing: '-0.374px', display: 'flex', alignItems: 'center', gap: '10px' }}>
          <Anchor size={28} />
          Battleship
        </h1>
        <p style={{ color: 'var(--color-ink-muted-48)', fontSize: '17px', marginTop: '4px' }}>
          Đối kháng hạm đội PvP. Bắn chìm toàn bộ tàu địch để thắng Cam.
        </p>
      </div>

      {!token && !loading && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {TIER_ORDER.map((tier) => {
            const meta = TIER_META[tier]
            const options = BET_OPTIONS.filter((o) => o.tier === tier)
            return (
              <div
                key={tier}
                style={{
                  padding: '24px',
                  borderRadius: '18px',
                  border: '1px solid var(--color-hairline)',
                  background: 'var(--color-surface)',
                }}
              >
                <div style={{ fontSize: '21px', fontWeight: 600, marginBottom: '4px' }}>{meta.label}</div>
                <div style={{ fontSize: '15px', color: 'var(--color-ink-muted-48)', marginBottom: '16px' }}>{meta.desc}</div>
                <div style={{ display: 'flex', gap: '12px' }}>
                  {options.map((opt) => (
                    <button
                      key={opt.amount}
                      onClick={() => startGame(opt)}
                      disabled={loading}
                      style={{
                        flex: 1,
                        padding: '14px 20px',
                        borderRadius: '14px',
                        border: '2px solid var(--color-primary)',
                        background: selectedBet?.amount === opt.amount ? 'var(--color-primary)' : 'transparent',
                        color: selectedBet?.amount === opt.amount ? '#fff' : 'var(--color-primary)',
                        fontSize: '17px',
                        fontWeight: 700,
                        cursor: loading ? 'wait' : 'pointer',
                        transition: 'all 0.15s ease',
                      }}
                      onMouseDown={(e) => (e.currentTarget.style.transform = 'scale(0.97)')}
                      onMouseUp={(e) => (e.currentTarget.style.transform = 'scale(1)')}
                      onMouseLeave={(e) => (e.currentTarget.style.transform = 'scale(1)')}
                    >
                      Cược {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            )
          })}
        </div>
      )}

      {loading && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: 'var(--color-ink-muted-48)', marginTop: '16px' }}>
          <Loader2 size={20} className="animate-spin" />
          Đang tạo phiên đấu...
        </div>
      )}

      {error && (
        <div style={{ marginTop: '16px', padding: '12px 16px', borderRadius: '8px', background: 'var(--color-error-bg)', color: 'var(--color-error)', fontSize: '15px' }}>
          {error}
        </div>
      )}

      {token && selection && (
        <div style={{ marginTop: '16px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
            <span style={{ fontSize: '15px', fontWeight: 600 }}>
              {TIER_META[selection.tier].label} — Cược {selection.amount} CAM — Đang đấu
            </span>
            <button
              onClick={leaveGame}
              style={{
                padding: '6px 14px',
                borderRadius: '9999px',
                border: '1px solid var(--color-hairline)',
                background: 'var(--color-surface-pearl)',
                fontSize: '14px',
                cursor: 'pointer',
              }}
            >
              Rời trận
            </button>
          </div>
          <iframe
            key={gameSrc}
            ref={iframeRef}
            src={gameSrc}
            title="Battleship"
            style={{ width: '100%', height: '820px', border: '1px solid var(--color-hairline)', borderRadius: '18px' }}
          />
        </div>
      )}
    </div>
  )
}
