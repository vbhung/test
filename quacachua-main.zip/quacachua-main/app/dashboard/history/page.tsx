import React from 'react'
import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { HistoryTabs } from '@/components/dashboard/HistoryTabs'

export default async function HistoryPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/login')

  const { data: transactions } = await supabase
    .from('cam_transactions')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(50)

  return (
    <div className="dash-section animate-in fade-in duration-500">
      <header className="dash-header">
        <h1 className="dash-header-title">Lịch sử giao dịch</h1>
        <p className="dash-header-subtitle">Theo dõi luồng Cam vào và ra của bạn.</p>
      </header>

      {(!transactions || transactions.length === 0) ? (
        <div className="bg-canvas border border-[var(--color-hairline)] rounded-[12px] p-8">
          <div className="empty-state-box border-0">Chưa có giao dịch nào phát sinh.</div>
        </div>
      ) : (
        <HistoryTabs transactions={transactions} />
      )}
    </div>
  )
}
