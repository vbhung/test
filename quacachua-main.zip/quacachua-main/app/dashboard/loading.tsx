import React from 'react'

export default function DashboardLoading() {
  return (
    <div className="dash-section animate-in fade-in duration-500" style={{ opacity: 0.5 }}>
      <header className="dash-header">
        <div style={{ height: '32px', width: '200px', backgroundColor: 'var(--color-surface-sunken)', borderRadius: '6px', marginBottom: '8px' }}></div>
        <div style={{ height: '20px', width: '300px', backgroundColor: 'var(--color-surface-sunken)', borderRadius: '6px' }}></div>
      </header>

      <div className="stats-grid" style={{ marginTop: '32px' }}>
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="stats-card" style={{ height: '180px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div style={{ height: '24px', width: '120px', backgroundColor: 'var(--color-surface-sunken)', borderRadius: '4px' }}></div>
            <div style={{ height: '32px', width: '80px', backgroundColor: 'var(--color-surface-sunken)', borderRadius: '4px' }}></div>
            <div style={{ height: '16px', width: '100%', backgroundColor: 'var(--color-surface-sunken)', borderRadius: '4px', marginTop: 'auto' }}></div>
          </div>
        ))}
      </div>
    </div>
  )
}
