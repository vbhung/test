'use client'

import React, { useEffect, useState } from 'react'
import { adminGetStatistics } from '@/app/actions/admin'
import { Users, Coins, BarChart3, TrendingUp, CreditCard, Banknote, DollarSign } from 'lucide-react'

export default function AdminStatisticsPage() {
  const [data, setData] = useState<{
    totalUsers: number | null
    totalCirculating: number
    totalEarnCompletions: number
    totalEarnCam: number
    shortlinkStats: { code: string; name: string; count: number; totalCam: number }[]
    totalPaidVnd: number
    cardPaidVnd: number
    bankPaidVnd: number
  } | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    adminGetStatistics().then(res => {
      setData(res)
      setLoading(false)
    })
  }, [])

  return (
    <div className="dash-section animate-in fade-in duration-500">
      <header className="dash-header">
        <h1 className="dash-header-title">Thống kê</h1>
        <p className="dash-header-subtitle">Tổng quan hệ thống — số liệu được tổng hợp từ dữ liệu giao dịch.</p>
      </header>

      {loading ? (
        <p>Đang tải...</p>
      ) : (
        <>
          <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)', marginBottom: 'var(--spacing-xl)' }}>
            <div className="stats-card">
              <div className="stats-card-header">
                <div className="stats-card-icon-wrapper">
                  <Users />
                </div>
              </div>
              <p className="stats-card-title">Tổng người dùng</p>
              <p className="stats-card-value">{data?.totalUsers ?? 0}</p>
            </div>

            <div className="stats-card">
              <div className="stats-card-header">
                <div className="stats-card-icon-wrapper">
                  <Coins />
                </div>
              </div>
              <p className="stats-card-title">Cam đang lưu hành</p>
              <p className="stats-card-value">{Number(data?.totalCirculating ?? 0).toFixed(2)}</p>
            </div>

            <div className="stats-card">
              <div className="stats-card-header">
                <div className="stats-card-icon-wrapper">
                  <TrendingUp />
                </div>
              </div>
              <p className="stats-card-title">Nhiệm vụ hoàn thành</p>
              <p className="stats-card-value">{data?.totalEarnCompletions ?? 0}</p>
            </div>

            <div className="stats-card">
              <div className="stats-card-header">
                <div className="stats-card-icon-wrapper">
                  <Coins />
                </div>
              </div>
              <p className="stats-card-title">Cam nhiệm vụ đã trả</p>
              <p className="stats-card-value">{Number(data?.totalEarnCam ?? 0).toFixed(2)}</p>
            </div>
          </div>

          <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)', marginBottom: 'var(--spacing-xl)' }}>
            <div className="stats-card">
              <div className="stats-card-header">
                <div className="stats-card-icon-wrapper">
                  <DollarSign />
                </div>
              </div>
              <p className="stats-card-title">Tổng tiền đã thanh toán</p>
              <p className="stats-card-value">{data?.totalPaidVnd?.toLocaleString('vi-VN') || 0}đ</p>
            </div>

            <div className="stats-card">
              <div className="stats-card-header">
                <div className="stats-card-icon-wrapper">
                  <CreditCard />
                </div>
              </div>
              <p className="stats-card-title">Thẻ đã thanh toán</p>
              <p className="stats-card-value">{data?.cardPaidVnd?.toLocaleString('vi-VN') || 0}đ</p>
            </div>

            <div className="stats-card">
              <div className="stats-card-header">
                <div className="stats-card-icon-wrapper">
                  <Banknote />
                </div>
              </div>
              <p className="stats-card-title">Ngân hàng đã chuyển</p>
              <p className="stats-card-value">{data?.bankPaidVnd?.toLocaleString('vi-VN') || 0}đ</p>
            </div>
          </div>

          <div className="stats-card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: '20px 24px', borderBottom: '1px solid var(--color-hairline)', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <BarChart3 size={18} style={{ color: 'var(--color-ink-muted-48)' }} />
              <span style={{ font: 'var(--text-body-strong)' }}>Thống kê</span>
              <span style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-48)', marginLeft: 'auto' }}>Theo bảng nhiệm vụ đã hoàn thành</span>
            </div>
            {data?.shortlinkStats && data.shortlinkStats.length > 0 ? (
              <table className="dash-table" style={{ minWidth: 'auto' }}>
                <thead>
                  <tr>
                    <th style={{ width: '48px', textAlign: 'center' }}>#</th>
                    <th>Nhà cung cấp</th>
                    <th>Mã</th>
                    <th style={{ textAlign: 'right' }}>Lượt hoàn thành</th>
                    <th style={{ textAlign: 'right' }}>Cam đã trả</th>
                  </tr>
                </thead>
                <tbody>
                  {data.shortlinkStats.map((s, i) => (
                    <tr key={s.code}>
                      <td style={{ textAlign: 'center', color: 'var(--color-ink-muted-48)' }}>{i + 1}</td>
                      <td style={{ font: 'var(--text-body-strong)' }}>{s.name}</td>
                      <td style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-48)' }}>{s.code}</td>
                      <td style={{ textAlign: 'right' }}>
                        <span style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '4px',
                          padding: '4px 10px',
                          borderRadius: '999px',
                          fontSize: '13px',
                          fontWeight: 600,
                          backgroundColor: 'var(--color-primary-muted)',
                          color: 'var(--color-primary)'
                        }}>
                          <TrendingUp size={14} />
                          {s.count}
                        </span>
                      </td>
                      <td style={{ textAlign: 'right', font: 'var(--text-body-strong)' }}>{Number(s.totalCam ?? 0).toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <p style={{ padding: '40px 24px', textAlign: 'center', color: 'var(--color-ink-muted-48)' }}>
                Chưa có dữ liệu giao dịch earn nào.
              </p>
            )}
          </div>
        </>
      )}
    </div>
  )
}
