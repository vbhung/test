'use client'

import React, { useEffect, useState } from 'react'
import { Modal } from '@/components/ui/Modal'
import { TransactionItem } from '@/components/dashboard/TransactionItem'
import { Users, Edit, ShieldAlert, History, Ban, Trash2, CheckCircle2 } from 'lucide-react'
import { adminListUsers, adminUpdateUserBalance, adminGetUserTransactions } from '@/app/actions/admin'
import { adminBanUser, adminUnbanUser, adminDeleteUser } from '@/app/actions/admin_users'

export default function AdminUsersPage() {
  const [users, setUsers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [editingUser, setEditingUser] = useState<any>(null)
  const [changeAmount, setChangeAmount] = useState('')
  const [reason, setReason] = useState('')
  const [toast, setToast] = useState<{message: string, isError: boolean} | null>(null)
  
  const [historyUser, setHistoryUser] = useState<any>(null)
  const [userHistory, setUserHistory] = useState<any[]>([])
  const [historyLoading, setHistoryLoading] = useState(false)

  const [banUser, setBanUser] = useState<any>(null)
  const [banType, setBanType] = useState<'permanent' | 'temporary'>('permanent')
  const [banDays, setBanDays] = useState(7)
  const [banReason, setBanReason] = useState('')

  const [deleteUser, setDeleteUser] = useState<any>(null)
  const fetchUsers = async () => {
    setLoading(true)
    const { data, error } = await adminListUsers()
    if (error) {
      setToast({ message: error, isError: true })
    } else if (data) {
      setUsers(data)
    }
    setLoading(false)
  }

  useEffect(() => {
    fetchUsers()
  }, [])

  const handleUpdateBalance = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingUser) return
    const amount = Number(changeAmount)
    if (isNaN(amount) || amount === 0) return

    const res = await adminUpdateUserBalance(editingUser.id, amount, reason)
    if (res.error) {
      setToast({ message: res.error, isError: true })
    } else {
      setToast({ message: 'Cập nhật số dư thành công!', isError: false })
      setEditingUser(null)
      setChangeAmount('')
      setReason('')
      fetchUsers()
    }
    setTimeout(() => setToast(null), 3000)
  }

  const handleViewHistory = async (u: any) => {
    setHistoryUser(u)
    setHistoryLoading(true)
    const { data } = await adminGetUserTransactions(u.id)
    if (data) setUserHistory(data)
    setHistoryLoading(false)
  }

  const handleBan = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!banUser) return
    const res = await adminBanUser(banUser.id, banType, banReason, banType === 'temporary' ? banDays : undefined)
    if (res.error) setToast({ message: res.error, isError: true })
    else {
      setToast({ message: 'Đã khóa tài khoản thành công.', isError: false })
      setBanUser(null)
      fetchUsers()
    }
    setTimeout(() => setToast(null), 3000)
  }

  const handleUnban = async (u: any) => {
    if (!confirm(`Bạn có chắc chắn muốn mở khóa cho @${u.username}?`)) return
    const res = await adminUnbanUser(u.id)
    if (res.error) setToast({ message: res.error, isError: true })
    else {
      setToast({ message: 'Đã mở khóa tài khoản.', isError: false })
      fetchUsers()
    }
    setTimeout(() => setToast(null), 3000)
  }

  const handleDelete = async () => {
    if (!deleteUser) return
    const res = await adminDeleteUser(deleteUser.id)
    if (res.error) setToast({ message: res.error, isError: true })
    else {
      setToast({ message: 'Đã xóa tài khoản vĩnh viễn.', isError: false })
      setDeleteUser(null)
      fetchUsers()
    }
    setTimeout(() => setToast(null), 3000)
  }

  return (
    <div className="dash-section animate-in fade-in duration-500">
      {toast && (
        <div style={{
          position: 'fixed', bottom: '24px', right: '24px', 
          backgroundColor: toast.isError ? 'var(--color-error)' : 'var(--color-success)', 
          color: 'white', padding: '12px 24px', borderRadius: '8px', zIndex: 9999,
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)', animation: 'slideUp 0.3s ease-out'
        }}>
          {toast.message}
        </div>
      )}

      <header className="dash-header">
        <h1 className="dash-header-title">Quản lý Users</h1>
        <p className="dash-header-subtitle">Dành riêng cho Admin. Xem danh sách người dùng và điều chỉnh số dư Cam.</p>
      </header>

      <div className="stats-card" style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', minWidth: '600px', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--color-hairline)', textAlign: 'left' }}>
              <th style={{ padding: '12px 16px', font: 'var(--text-caption-strong)' }}>User</th>
              <th style={{ padding: '12px 16px', font: 'var(--text-caption-strong)' }}>Email</th>
              <th style={{ padding: '12px 16px', font: 'var(--text-caption-strong)' }}>Role</th>
              <th style={{ padding: '12px 16px', font: 'var(--text-caption-strong)' }}>Số Dư (Cam)</th>
              <th style={{ padding: '12px 16px', font: 'var(--text-caption-strong)' }}>Hành động</th>
            </tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u.id} style={{ borderBottom: '1px solid var(--color-hairline)' }}>
                <td style={{ padding: '12px 16px' }}>
                  <div style={{ font: 'var(--text-body-strong)' }}>{u.display_name}</div>
                  <div style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-48)' }}>@{u.username}</div>
                </td>
                <td style={{ padding: '12px 16px', font: 'var(--text-body)' }}>{u.email_canonical}</td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{ 
                    padding: '4px 8px', 
                    borderRadius: '4px', 
                    fontSize: '12px', 
                    fontWeight: 600,
                    backgroundColor: u.role === 'admin' ? 'var(--color-error-bg)' : 'var(--color-success-bg)',
                    color: u.role === 'admin' ? 'var(--color-error)' : 'var(--color-success)'
                  }}>
                    {u.role.toUpperCase()}
                  </span>
                </td>
                <td style={{ padding: '12px 16px', font: 'var(--text-body-strong)' }}>{Number(u.cam_balance || 0).toFixed(2)}</td>
                <td style={{ padding: '12px 16px' }}>
                  <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                    <button 
                      onClick={() => setEditingUser(u)}
                      className="dash-btn"
                      style={{ padding: '6px 12px', fontSize: '13px', border: '1px solid var(--color-primary)', color: 'var(--color-primary)', backgroundColor: 'var(--color-canvas)' }}
                      title="Điều chỉnh số dư"
                    >
                      <Edit width={14} height={14} />
                    </button>
                    <button 
                      onClick={() => handleViewHistory(u)}
                      className="dash-btn"
                      style={{ padding: '6px 12px', fontSize: '13px', border: '1px solid var(--color-success)', color: 'var(--color-success)', backgroundColor: 'var(--color-canvas)' }}
                      title="Lịch sử giao dịch"
                    >
                      <History width={14} height={14} />
                    </button>
                    {u.is_banned ? (
                      <button 
                        onClick={() => handleUnban(u)}
                        className="dash-btn"
                        style={{ padding: '6px 12px', fontSize: '13px', color: 'var(--color-success)', border: '1px solid var(--color-success)', backgroundColor: 'var(--color-canvas)' }}
                        title="Mở khóa tài khoản"
                      >
                        <CheckCircle2 width={14} height={14} />
                      </button>
                    ) : (
                      <button 
                        onClick={() => { setBanUser(u); setBanReason(''); setBanType('permanent'); }}
                        className="dash-btn"
                        style={{ padding: '6px 12px', fontSize: '13px', color: 'var(--color-error)', border: '1px solid var(--color-error)', backgroundColor: 'var(--color-canvas)' }}
                        title="Khóa tài khoản"
                      >
                        <Ban width={14} height={14} />
                      </button>
                    )}
                    <button 
                      onClick={() => setDeleteUser(u)}
                      className="dash-btn"
                      style={{ padding: '6px 12px', fontSize: '13px', color: 'var(--color-error)', border: '1px solid var(--color-error)', backgroundColor: 'var(--color-canvas)' }}
                      title="Xóa tài khoản"
                    >
                      <Trash2 width={14} height={14} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {users.length === 0 && !loading && (
              <tr>
                <td colSpan={5} style={{ padding: '24px', textAlign: 'center', color: 'var(--color-ink-muted-48)' }}>Không có người dùng nào.</td>
              </tr>
            )}
            {loading && (
              <tr>
                <td colSpan={5} style={{ padding: '24px', textAlign: 'center', color: 'var(--color-ink-muted-48)' }}>Đang tải...</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Modal 
        isOpen={!!editingUser} 
        onClose={() => setEditingUser(null)} 
        title={`Điều chỉnh số dư: ${editingUser?.username}`}
      >
        <form onSubmit={handleUpdateBalance}>
          <div className="dash-form-group">
            <label className="dash-label">Số lượng Cam (Có thể nhập số âm để trừ)</label>
            <input 
              type="number" 
              step="0.01" 
              value={changeAmount} 
              onChange={e => setChangeAmount(e.target.value)}
              className="dash-input" 
              required 
            />
          </div>
          <div className="dash-form-group">
            <label className="dash-label">Lý do điều chỉnh (sẽ lưu vào lịch sử)</label>
            <input 
              type="text" 
              value={reason} 
              onChange={e => setReason(e.target.value)}
              className="dash-input" 
              required 
            />
          </div>
          <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end', marginTop: '16px' }}>
            <button type="button" className="dash-btn" onClick={() => setEditingUser(null)} style={{ border: '1px solid var(--color-hairline)' }}>Hủy</button>
            <button type="submit" className="dash-btn dash-btn-primary">Xác nhận</button>
          </div>
        </form>
      </Modal>

      {/* Modal Lịch Sử */}
      <Modal 
        isOpen={!!historyUser} 
        onClose={() => setHistoryUser(null)} 
        title={`Lịch sử giao dịch: ${historyUser?.username}`}
      >
        <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
          {historyLoading ? (
            <p>Đang tải...</p>
          ) : userHistory.length === 0 ? (
            <p style={{ color: 'var(--color-ink-muted-48)' }}>Chưa có giao dịch nào.</p>
          ) : (
            <div className="divide-y divide-[var(--color-hairline)]">
              {userHistory.map(tx => (
                <TransactionItem key={tx.id} tx={tx} />
              ))}
            </div>
          )}
        </div>
      </Modal>

      {/* Modal Ban User */}
      <Modal 
        isOpen={!!banUser} 
        onClose={() => setBanUser(null)} 
        title={`Khóa tài khoản: ${banUser?.username}`}
      >
        <form onSubmit={handleBan}>
          <div className="dash-form-group">
            <label className="dash-label">Loại khóa</label>
            <select className="dash-input" value={banType} onChange={e => setBanType(e.target.value as any)}>
              <option value="permanent">Khóa vĩnh viễn</option>
              <option value="temporary">Khóa tạm thời</option>
            </select>
          </div>
          {banType === 'temporary' && (
            <div className="dash-form-group">
              <label className="dash-label">Số ngày khóa</label>
              <input 
                type="number" 
                min="1" 
                value={banDays} 
                onChange={e => setBanDays(Number(e.target.value))}
                className="dash-input" 
                required 
              />
            </div>
          )}
          <div className="dash-form-group">
            <label className="dash-label">Lý do khóa (User sẽ thấy)</label>
            <input 
              type="text" 
              value={banReason} 
              onChange={e => setBanReason(e.target.value)}
              className="dash-input" 
              required 
            />
          </div>
          <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end', marginTop: '16px' }}>
            <button type="button" className="dash-btn" onClick={() => setBanUser(null)} style={{ border: '1px solid var(--color-hairline)' }}>Hủy</button>
            <button type="submit" className="dash-btn" style={{ backgroundColor: 'var(--color-error)', color: 'white', border: 'none' }}>Xác nhận Khóa</button>
          </div>
        </form>
      </Modal>

      {/* Modal Xóa User */}
      <Modal 
        isOpen={!!deleteUser} 
        onClose={() => setDeleteUser(null)} 
        title={`CẢNH BÁO: Xóa tài khoản ${deleteUser?.username}`}
      >
        <div style={{ backgroundColor: 'var(--color-error-bg)', color: 'var(--color-error)', padding: '16px', borderRadius: '8px', marginBottom: '16px' }}>
          <strong>Hành động này không thể hoàn tác!</strong><br/>
          Tất cả dữ liệu lịch sử, giao dịch, và thông tin của user này sẽ bị xóa sạch khỏi hệ thống.
        </div>
        <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end' }}>
          <button type="button" className="dash-btn" onClick={() => setDeleteUser(null)} style={{ border: '1px solid var(--color-hairline)' }}>Hủy</button>
          <button type="button" onClick={handleDelete} className="dash-btn" style={{ backgroundColor: 'var(--color-error)', color: 'white', border: 'none' }}>Xóa Vĩnh Viễn</button>
        </div>
      </Modal>
    </div>
  )
}
