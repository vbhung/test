import React from 'react'
import { requireAdminPageAccess } from '@/lib/authz'
import { createAdminClient } from '@/lib/supabase/server'
import { AdminXoaCamClient } from '@/components/dashboard/admin/AdminXoaCamClient'

export const metadata = {
  title: 'Xóa Cam | Admin',
}

export default async function AdminXoaCamPage() {
  await requireAdminPageAccess()
  const supabaseAdmin = createAdminClient()

  const { data: batches } = await supabaseAdmin
    .from('cam_revoke_batches')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(50)

  return (
    <div className="dash-section animate-in fade-in duration-500">
      <header className="dash-header">
        <h1 className="dash-header-title">Xóa Cam</h1>
        <p className="dash-header-subtitle">
          Trừ toàn bộ Cam kiếm được từ nhà cung cấp nhapma/layma. Người đã tiêu Cam sẽ bị âm số dư. Bấm "Hoàn" để trả lại.
        </p>
      </header>

      <AdminXoaCamClient initialBatches={batches || []} />
    </div>
  )
}
