'use client'

import React, { useEffect, useState } from 'react'
import { CheckCircle2, XCircle, ExternalLink, History, CreditCard, Banknote, Zap, Ban } from 'lucide-react'
import { adminListPendingTickets, processRedemptionTicket, adminGetUserTransactions, adminCancelAllPendingTickets } from '@/app/actions/admin'
import { Modal } from '@/components/ui/Modal'
import { TransactionItem } from '@/components/dashboard/TransactionItem'

export default function AdminTicketsPage() {
  const [tickets, setTickets] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [processingTicket, setProcessingTicket] = useState<any>(null)
  const [adminNote, setAdminNote] = useState('')
  const [actionType, setActionType] = useState<'completed' | 'rejected'>('completed')
  const [applyFee, setApplyFee] = useState(false)
  const [buyMode, setBuyMode] = useState<'auto' | 'manual'>('auto')

  const [toast, setToast] = useState<{message: string, isError: boolean} | null>(null)
  const [qrSignedUrl, setQrSignedUrl] = useState<string | null>(null)
  const [qrLoading, setQrLoading] = useState(false)

  const [historyUser, setHistoryUser] = useState<{id: string; username: string; displayName: string} | null>(null)
  const [userTransactions, setUserTransactions] = useState<any[]>([])
  const [historyLoading, setHistoryLoading] = useState(false)

  const [buyingCard, setBuyingCard] = useState(false)
  const [cancelingAll, setCancelingAll] = useState(false)

  const fetchTickets = async () => {
    setLoading(true)
    const { data, error } = await adminListPendingTickets()
    if (error) {
      setToast({ message: error, isError: true })
    } else if (data) {
      setTickets(data)
    }
    setLoading(false)
  }

  useEffect(() => {
    fetchTickets()
  }, [])

  const totalCardVnd = tickets
    .filter(t => t.type === 'phone_card' || t.type === 'game_card')
    .reduce((sum, t) => sum + (t.amount_vnd || 0), 0)

  const totalBankVnd = tickets
    .filter(t => t.type === 'bank')
    .reduce((sum, t) => sum + (t.amount_vnd || 0), 0)

  const handleViewHistory = async (userId: string, profile: any) => {
    setHistoryLoading(true)
    setHistoryUser({ id: userId, username: profile?.username, displayName: profile?.display_name })
    const res = await adminGetUserTransactions(userId)
    setUserTransactions(res.data || [])
    setHistoryLoading(false)
  }

  const handleViewQr = async (fileName: string) => {
    setQrLoading(true)
    setQrSignedUrl(null)
    try {
      setQrSignedUrl(`/api/admin/qrcode?file=${encodeURIComponent(fileName)}`)
    } catch (e) {
      console.error('QR signed URL error', e)
    } finally {
      setQrLoading(false)
    }
  }

  const handleAutoBuy = async (ticket: any) => {
    setBuyingCard(true)
    try {
      const res = await fetch('/api/admin/buy-card', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ticketId: ticket.id }),
      })
      const data = await res.json()

      if (!res.ok || !data.success) {
        setToast({ message: data.error || 'Mua thẻ thất bại', isError: true })
        return
      }

      const cardInfo = `Mã thẻ: ${data.card.code} - Serial: ${data.card.serial} - ${data.card.name}`
      const processRes = await processRedemptionTicket(ticket.id, cardInfo, 'completed', false)
      if (processRes.error) {
        setToast({ message: `Đã mua thẻ nhưng lỗi khi duyệt: ${processRes.error}`, isError: true })
      } else {
        setToast({ message: `Mua thẻ + duyệt thành công! ${cardInfo}`, isError: false })
        fetchTickets()
      }
    } catch (err: any) {
      setToast({ message: `Lỗi: ${err.message}`, isError: true })
    } finally {
      setBuyingCard(false)
    }
  }

  const isCardTicket = (t: any) => t?.type === 'phone_card' || t?.type === 'game_card'

  const handleProcess = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!processingTicket) return

    const res = await processRedemptionTicket(processingTicket.id, adminNote, actionType, applyFee)
    if (res.error) {
      setToast({ message: res.error, isError: true })
    } else {
      setToast({ message: 'Xử lý thành công!', isError: false })
      setProcessingTicket(null)
      setAdminNote('')
      setApplyFee(false)
      fetchTickets()
    }
    setTimeout(() => setToast(null), 3000)
  }

  const openProcessModal = (t: any, type: 'completed' | 'rejected') => {
    setProcessingTicket(t)
    setActionType(type)
    setAdminNote('')
    setApplyFee(false)
    setBuyMode(type === 'completed' && isCardTicket(t) ? 'auto' : 'manual')
  }

  const handleCancelAll = async () => {
    if (!confirm(
      `CẢNH BÁO: Hủy TẤT CẢ ${tickets.length} yêu cầu rút tiền đang chờ?\n\n` +
      `Số tiền Cam của từng người sẽ được hoàn lại ĐẦY ĐỦ (không thu phí).\n\nBạn có chắc chắn?`
    )) return

    setCancelingAll(true)
    const res = await adminCancelAllPendingTickets()
    setCancelingAll(false)

    if (res.error) {
      setToast({ message: res.error, isError: true })
      return
    }
    setToast({ message: `Đã hủy ${res.canceled} yêu cầu, hoàn ${Number(res.refundedCam ?? 0).toFixed(2)} Cam. Không thu phí.`, isError: false })
    fetchTickets()
    setTimeout(() => setToast(null), 4000)
  }

  return (
    <div className="dash-section animate-in fade-in duration-500">
      {toast && (
        <div style={{
          position: 'fixed', bottom: '24px', right: '24px',
          backgroundColor: toast.isError ? 'var(--color-error)' : 'var(--color-success)',
          color: 'white', padding: '12px 24px', borderRadius: '8px', zIndex: 9999,
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)', animation: 'slideUp 0.3s ease-out'
        }}>
          {toast.message}
        </div>
      )}

      <header className="dash-header">
        <h1 className="dash-header-title">Duyệt Yêu Cầu Rút Tiền</h1>
        <p className="dash-header-subtitle">Xử lý các yêu cầu đổi thẻ, rút ngân hàng đang chờ duyệt.</p>
      </header>

      {/* Summary */}
      {!loading && tickets.length > 0 && (
        <div style={{
          display: 'flex', gap: '16px', marginBottom: '20px', flexWrap: 'wrap'
        }}>
          <div style={{ flex: '1 1 200px', padding: '16px 20px', background: 'var(--color-surface)', borderRadius: '12px', border: '1px solid var(--color-hairline)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
              <CreditCard size={18} style={{ color: 'var(--color-primary)' }} />
              <span style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-48)' }}>Thẻ cần thanh toán</span>
            </div>
            <span style={{ font: 'var(--text-h3)', color: 'var(--color-primary)' }}>
              {totalCardVnd.toLocaleString('vi-VN')}đ
            </span>
          </div>
          <div style={{ flex: '1 1 200px', padding: '16px 20px', background: 'var(--color-surface)', borderRadius: '12px', border: '1px solid var(--color-hairline)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
              <Banknote size={18} style={{ color: 'var(--color-warning)' }} />
              <span style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-48)' }}>Ngân hàng cần chuyển</span>
            </div>
            <span style={{ font: 'var(--text-h3)', color: 'var(--color-warning)' }}>
              {totalBankVnd.toLocaleString('vi-VN')}đ
            </span>
          </div>
          <div style={{ flex: '1 1 200px', padding: '16px 20px', background: 'var(--color-surface)', borderRadius: '12px', border: '1px solid var(--color-hairline)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
              <span style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-48)' }}>Tổng duyệt</span>
            </div>
            <span style={{ font: 'var(--text-h3)' }}>
              {(totalCardVnd + totalBankVnd).toLocaleString('vi-VN')}đ
            </span>
          </div>
          <div style={{ flex: '1 1 220px', padding: '16px 20px', background: 'var(--color-error-bg)', borderRadius: '12px', border: '1px solid var(--color-error)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <button
              onClick={handleCancelAll}
              disabled={cancelingAll}
              className="dash-btn"
              style={{ width: '100%', padding: '12px', backgroundColor: cancelingAll ? 'var(--color-ink-muted-48)' : 'var(--color-error)', color: 'white', border: 'none', fontWeight: 600 }}
            >
              <Ban width={16} height={16} style={{ marginRight: '8px' }} />
              {cancelingAll ? 'Đang hủy tất cả...' : `Hủy tất cả (${tickets.length}) & hoàn Cam`}
            </button>
          </div>
        </div>
      )}

      <div className="stats-card" style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', minWidth: '800px', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--color-hairline)', textAlign: 'left' }}>
              <th style={{ padding: '12px 16px', font: 'var(--text-caption-strong)' }}>Ngày tạo</th>
              <th style={{ padding: '12px 16px', font: 'var(--text-caption-strong)' }}>User</th>
              <th style={{ padding: '12px 16px', font: 'var(--text-caption-strong)' }}>Loại</th>
              <th style={{ padding: '12px 16px', font: 'var(--text-caption-strong)' }}>Số lượng</th>
              <th style={{ padding: '12px 16px', font: 'var(--text-caption-strong)' }}>Chi tiết nhận tiền</th>
              <th style={{ padding: '12px 16px', font: 'var(--text-caption-strong)' }}>Hành động</th>
            </tr>
          </thead>
          <tbody>
            {tickets.map(t => (
              <tr key={t.id} style={{ borderBottom: '1px solid var(--color-hairline)' }}>
                <td style={{ padding: '12px 16px', font: 'var(--text-fine-print)' }}>
                  {new Date(t.created_at).toLocaleString('vi-VN')}
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ font: 'var(--text-body-strong)' }}>{t.profiles?.display_name}</span>
                    <button
                      onClick={() => handleViewHistory(t.user_id, t.profiles)}
                      title="Xem lịch sử giao dịch"
                      style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', fontSize: '12px', color: 'var(--color-primary)', background: 'transparent', border: '1px solid var(--color-hairline)', borderRadius: '6px', padding: '2px 8px', cursor: 'pointer' }}
                    >
                      <History width={12} height={12} /> LS
                    </button>
                  </div>
                  <div style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-48)' }}>@{t.profiles?.username}</div>
                </td>
                <td style={{ padding: '12px 16px', font: 'var(--text-body-strong)' }}>
                  {t.type === 'phone_card' ? 'Thẻ ĐT' : t.type === 'game_card' ? 'Thẻ Game' : 'Ngân Hàng'}
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <div style={{ font: 'var(--text-body-strong)', color: 'var(--color-primary)' }}>{t.amount_cam} Cam</div>
                  <div style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-48)' }}>≈ {t.amount_vnd.toLocaleString('vi-VN')}đ</div>
                </td>
                <td style={{ padding: '12px 16px', maxWidth: '250px' }}>
                  {t.type === 'bank' ? (
                    <>
                      <p style={{ font: 'var(--text-fine-print)', whiteSpace: 'pre-wrap', marginBottom: '8px' }}>{t.details.info || '(Không có info)'}</p>
                      {t.details.qrCodeUrl && (
                        <button
                          onClick={() => handleViewQr(t.details.qrCodeUrl)}
                          style={{ display: 'inline-flex', alignItems: 'center', color: 'var(--color-primary)', font: 'var(--text-fine-print)', background: 'transparent', border: 'none', cursor: 'pointer', padding: 0 }}
                        >
                          <ExternalLink width={14} height={14} style={{ marginRight: '4px' }} />
                          {qrLoading ? 'Đang tạo link...' : 'Xem QR Code'}
                        </button>
                      )}
                    </>
                  ) : (
                    <div style={{ font: 'var(--text-fine-print)' }}>
                      <strong>Nhà mạng:</strong> {t.details.provider}<br/>
                      <strong>Mệnh giá:</strong> {t.details.denomination?.toLocaleString('vi-VN')}đ
                    </div>
                  )}
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <div style={{ display: 'flex', gap: '8px', flexDirection: 'column' }}>
                    <div style={{ display: 'flex', gap: '8px' }}>
                      <button
                        onClick={() => openProcessModal(t, 'completed')}
                        className="dash-btn"
                        style={{ padding: '6px 12px', fontSize: '14px', backgroundColor: 'var(--color-success)', color: 'white' }}
                      >
                        <CheckCircle2 width={16} height={16} style={{ marginRight: '4px' }} /> Duyệt
                      </button>
                      <button
                        onClick={() => openProcessModal(t, 'rejected')}
                        className="dash-btn"
                        style={{ padding: '6px 12px', fontSize: '14px', backgroundColor: 'var(--color-error)', color: 'white' }}
                      >
                        <XCircle width={16} height={16} style={{ marginRight: '4px' }} /> Từ chối
                      </button>
                    </div>
                    {isCardTicket(t) && (
                      <button
                        onClick={() => handleAutoBuy(t)}
                        disabled={buyingCard}
                        className="dash-btn"
                        style={{
                          padding: '4px 10px', fontSize: '12px',
                          backgroundColor: buyingCard ? '#ccc' : 'var(--color-primary)',
                          color: 'white', border: 'none'
                        }}
                      >
                        <Zap width={14} height={14} style={{ marginRight: '4px' }} />
                        {buyingCard ? 'Đang mua...' : 'Tự động mua thẻ'}
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
            {tickets.length === 0 && !loading && (
              <tr>
                <td colSpan={6} style={{ padding: '24px', textAlign: 'center', color: 'var(--color-ink-muted-48)' }}>Không có yêu cầu rút tiền nào cần duyệt.</td>
              </tr>
            )}
            {loading && (
              <tr>
                <td colSpan={6} style={{ padding: '24px', textAlign: 'center', color: 'var(--color-ink-muted-48)' }}>Đang tải...</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Modal
        isOpen={!!qrSignedUrl}
        onClose={() => setQrSignedUrl(null)}
        title="QR Code nhận tiền"
      >
        <div style={{ textAlign: 'center', padding: '16px' }}>
          {qrSignedUrl ? (
            <img src={qrSignedUrl} alt="QR Code" style={{ maxWidth: '100%', borderRadius: '8px' }} />
          ) : (
            <p>Đang tải...</p>
          )}
          <p style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-48)', marginTop: '12px' }}>
            Ảnh được tải an toàn qua máy chủ.
          </p>
        </div>
      </Modal>

      <Modal
        isOpen={!!processingTicket}
        onClose={() => setProcessingTicket(null)}
        title={actionType === 'completed' ? 'Xác nhận Đã Thanh Toán' : 'Từ chối & Hoàn tiền'}
      >
        <p style={{ font: 'var(--text-fine-print)', marginBottom: '16px' }}>
          User: <strong>@{processingTicket?.profiles?.username}</strong> <br/>
          Số tiền: <strong>{processingTicket?.amount_vnd?.toLocaleString('vi-VN')} VNĐ</strong>
        </p>

        {actionType === 'completed' && isCardTicket(processingTicket) && (
          <div style={{ display: 'flex', gap: '8px', marginBottom: '16px' }}>
            <button
              type="button"
              onClick={() => { setBuyMode('auto'); setAdminNote('') }}
              className="dash-btn"
              style={{
                flex: 1, padding: '8px',
                backgroundColor: buyMode === 'auto' ? 'var(--color-primary)' : 'var(--color-surface)',
                color: buyMode === 'auto' ? 'white' : 'var(--color-ink)',
                border: buyMode === 'auto' ? '2px solid var(--color-primary)' : '1px solid var(--color-hairline)',
              }}
            >
              <Zap width={16} height={16} style={{ marginRight: '4px' }} /> Mua tự động
            </button>
            <button
              type="button"
              onClick={() => setBuyMode('manual')}
              className="dash-btn"
              style={{
                flex: 1, padding: '8px',
                backgroundColor: buyMode === 'manual' ? 'var(--color-primary)' : 'var(--color-surface)',
                color: buyMode === 'manual' ? 'white' : 'var(--color-ink)',
                border: buyMode === 'manual' ? '2px solid var(--color-primary)' : '1px solid var(--color-hairline)',
              }}
            >
              Nhập thủ công
            </button>
          </div>
        )}

        {buyMode === 'auto' && actionType === 'completed' && isCardTicket(processingTicket) ? (
          <div style={{ padding: '16px', backgroundColor: 'var(--color-surface)', borderRadius: '8px', border: '1px solid var(--color-hairline)', marginBottom: '16px' }}>
            <p style={{ font: 'var(--text-fine-print)', marginBottom: '8px' }}>
              Hệ thống sẽ tự động mua thẻ <strong>{processingTicket?.details?.provider}</strong> mệnh giá{' '}
              <strong>{processingTicket?.details?.denomination?.toLocaleString('vi-VN')}đ</strong>{' '}
              và gửi mã thẻ cho user.
            </p>
            <button
              type="button"
              onClick={() => {
                if (!processingTicket) return
                setBuyingCard(true)
                fetch('/api/admin/buy-card', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ ticketId: processingTicket.id }),
                })
                  .then(r => r.json())
                  .then(data => {
                    if (!data.success) {
                      setToast({ message: data.error || 'Mua thẻ thất bại', isError: true })
                      return
                    }
                    const cardInfo = `Mã thẻ: ${data.card.code} - Serial: ${data.card.serial} - ${data.card.name}`
                    processRedemptionTicket(processingTicket.id, cardInfo, 'completed', false).then(res => {
                      if (res.error) {
                        setToast({ message: `Đã mua thẻ nhưng lỗi duyệt: ${res.error}`, isError: true })
                      } else {
                        setToast({ message: `Thành công! ${cardInfo}`, isError: false })
                        setProcessingTicket(null)
                        fetchTickets()
                      }
                    })
                  })
                  .catch(err => setToast({ message: `Lỗi: ${err.message}`, isError: true }))
                  .finally(() => setBuyingCard(false))
              }}
              disabled={buyingCard}
              className="dash-btn"
              style={{
                width: '100%', padding: '10px', backgroundColor: buyingCard ? 'var(--color-ink-muted-48)' : 'var(--color-primary)',
                color: 'white', fontSize: '15px'
              }}
            >
              {buyingCard ? 'Đang mua thẻ...' : 'Xác nhận & Mua thẻ tự động'}
            </button>
          </div>
        ) : (
          <form onSubmit={handleProcess}>
            <div className="dash-form-group">
              <label className="dash-label">
                Ghi chú cho User {actionType === 'completed' && !isCardTicket(processingTicket) && ' (ĐIỀN NỘI DUNG CK)'}
              </label>
              <input
                type="text"
                value={adminNote}
                onChange={e => setAdminNote(e.target.value)}
                className="dash-input"
                placeholder={
                  actionType === 'completed' && !isCardTicket(processingTicket)
                    ? 'Nội dung chuyển khoản...'
                    : 'Nhập lời nhắn...'
                }
                required={actionType === 'rejected' || (actionType === 'completed' && buyMode === 'manual')}
              />
            </div>
            {actionType === 'rejected' && (
              <div style={{ display: 'flex', alignItems: 'center', marginTop: '12px', padding: '12px', backgroundColor: 'var(--color-error-bg)', borderRadius: '8px' }}>
                <input
                  type="checkbox"
                  id="applyFee"
                  checked={applyFee}
                  onChange={e => setApplyFee(e.target.checked)}
                  style={{ marginRight: '8px', cursor: 'pointer' }}
                />
                <label htmlFor="applyFee" style={{ font: 'var(--text-fine-print)', color: 'var(--color-error)', cursor: 'pointer' }}>
                  Áp phí 1 Cam làm phiến (chỉ dùng khi user điền sai thông tin cố ý)
                </label>
              </div>
            )}
            <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end', marginTop: '16px' }}>
              <button type="button" className="dash-btn" onClick={() => setProcessingTicket(null)} style={{ border: '1px solid var(--color-hairline)' }}>Hủy</button>
              <button type="submit" className="dash-btn" style={{ backgroundColor: actionType === 'completed' ? 'var(--color-success)' : 'var(--color-error)', color: 'white' }}>Xác nhận</button>
            </div>
          </form>
        )}
      </Modal>

      <Modal
        isOpen={!!historyUser}
        onClose={() => setHistoryUser(null)}
        title={`Lịch sử giao dịch - ${historyUser?.displayName || ''} (@${historyUser?.username || ''})`}
      >
        <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
          {historyLoading ? (
            <p style={{ padding: '16px', textAlign: 'center', color: 'var(--color-ink-muted-48)' }}>Đang tải...</p>
          ) : userTransactions.length === 0 ? (
            <p style={{ padding: '16px', textAlign: 'center', color: 'var(--color-ink-muted-48)' }}>Chưa có giao dịch nào.</p>
          ) : (
            <div className="divide-y divide-[var(--color-hairline)]">
              {userTransactions.map((tx: any) => (
                <TransactionItem key={tx.id} tx={tx} />
              ))}
            </div>
          )}
        </div>
      </Modal>
    </div>
  )
}
