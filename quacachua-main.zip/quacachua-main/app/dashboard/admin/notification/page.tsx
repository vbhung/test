'use client'

import React, { useEffect, useState } from 'react'
import { Megaphone, Save } from 'lucide-react'

export default function AdminNotificationPage() {
  const [content, setContent] = useState('')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState<{message: string; isError: boolean} | null>(null)

  useEffect(() => {
    fetch('/api/notification')
      .then(r => r.json())
      .then(data => { setContent(data.content || ''); setLoading(false) })
      .catch(() => { setLoading(false) })
  }, [])

  const handleSave = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/notification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content }),
      })
      const data = await res.json()
      if (data.success) {
        setToast({ message: 'Đã lưu thông báo!', isError: false })
      } else {
        setToast({ message: data.error || 'Lỗi', isError: true })
      }
    } catch {
      setToast({ message: 'Lỗi kết nối', isError: true })
    }
    setSaving(false)
    setTimeout(() => setToast(null), 3000)
  }

  return (
    <div className="dash-section animate-in fade-in duration-500">
      {toast && (
        <div style={{
          position: 'fixed', bottom: '24px', right: '24px',
          backgroundColor: toast.isError ? 'var(--color-error)' : 'var(--color-success)',
          color: 'white', padding: '12px 24px', borderRadius: '8px', zIndex: 9999,
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
        }}>
          {toast.message}
        </div>
      )}

      <header className="dash-header">
        <h1 className="dash-header-title">Thông báo toàn hệ thống</h1>
        <p className="dash-header-subtitle">Nội dung sẽ hiện popup cho tất cả user khi vào Dashboard.</p>
      </header>

      <div className="stats-card" style={{ maxWidth: '600px' }}>
        {loading ? (
          <p>Đang tải...</p>
        ) : (
          <div className="dash-form-group">
            <label className="dash-label" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Megaphone size={18} /> Nội dung thông báo
            </label>
            <p style={{ font: 'var(--text-fine-print)', color: 'var(--color-ink-muted-48)', marginBottom: '8px' }}>
              Để trống nếu không muốn hiện thông báo. HTML cơ bản được hỗ trợ.
            </p>
            <textarea
              value={content}
              onChange={e => setContent(e.target.value)}
              className="dash-input"
              style={{ minHeight: '150px', resize: 'vertical' }}
              placeholder="Nhập nội dung thông báo..."
            />
            <button
              onClick={handleSave}
              disabled={saving}
              className="dash-btn"
              style={{ marginTop: '12px', backgroundColor: 'var(--color-primary)', color: 'white', padding: '10px 24px' }}
            >
              <Save size={16} style={{ marginRight: '6px' }} />
              {saving ? 'Đang lưu...' : 'Lưu thông báo'}
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
