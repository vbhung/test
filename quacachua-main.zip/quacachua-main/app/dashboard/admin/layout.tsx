import type { ReactNode } from 'react'
import { requireAdminPageAccess } from '@/lib/authz'

export default async function AdminLayout({ children }: { children: ReactNode }) {
  await requireAdminPageAccess()
  return children
}
