import React from 'react'
import { requireAdminPageAccess } from '@/lib/authz'
import { createAdminClient } from '@/lib/supabase/server'
import { AdminProvidersClient } from '@/components/dashboard/admin/AdminProvidersClient'

export const metadata = {
  title: 'Quản lý Nhiệm vụ Kiếm Cam | Admin',
}

export default async function AdminProvidersPage() {
  await requireAdminPageAccess()
  const supabaseAdmin = createAdminClient()
  const { data: providers } = await supabaseAdmin
    .from('earn_providers')
    .select('*')
    .order('created_at', { ascending: true })

  return (
    <div className="dash-section animate-in fade-in duration-500">
      <header className="dash-header">
        <h1 className="dash-header-title">Quản lý Nhà cung cấp (Kiếm Cam)</h1>
        <p className="dash-header-subtitle">Thêm, sửa, hoặc Bật/Tắt các nhà cung cấp nhiệm vụ vượt link rút gọn.</p>
      </header>

      <AdminProvidersClient initialProviders={providers || []} />
    </div>
  )
}
