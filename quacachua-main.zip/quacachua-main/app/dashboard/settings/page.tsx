'use client'

import React, { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { User, Shield, AlertTriangle } from 'lucide-react'
import { deleteUserAccount } from '@/app/actions/user'
import { getCurrentProfileAction } from '@/app/actions/profile'
import { updateProfileAction, changePasswordAction } from '@/app/actions/settings'
import { useRouter } from 'next/navigation'
import { ConfirmModal } from '@/components/ui/ConfirmModal'

export default function SettingsPage() {
  const supabase = createClient()
  const router = useRouter()
  const [profile, setProfile] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState<'profile' | 'security'>('profile')
  const [isDeleting, setIsDeleting] = useState(false)

  const [displayName, setDisplayName] = useState('')
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')

  const [showConfirmDelete, setShowConfirmDelete] = useState(false)
  const [toast, setToast] = useState<{message: string, isError: boolean} | null>(null)

  useEffect(() => {
    getCurrentProfileAction().then((res) => {
      if (res.data) {
        setProfile(res.data)
        setDisplayName(res.data.display_name || '')
      }
    })
  }, [])

  const showToast = (message: string, isError: boolean) => {
    setToast({ message, isError })
    setTimeout(() => setToast(null), 3000)
  }

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    const res = await updateProfileAction(displayName)
    setLoading(false)
    if (res.error) {
      showToast(res.error, true)
    } else {
      showToast('Đã lưu thông tin hồ sơ.', false)
    }
  }

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    const res = await changePasswordAction(currentPassword, newPassword)
    setLoading(false)
    if (res.error) {
      showToast(res.error, true)
    } else {
      showToast('Đã đổi mật khẩu thành công.', false)
      setCurrentPassword('')
      setNewPassword('')
    }
  }

  const handleDeleteAccount = async () => {
    setIsDeleting(true)
    const res = await deleteUserAccount()
    if (res.error) {
      showToast(res.error, true)
      setIsDeleting(false)
      setShowConfirmDelete(false)
    } else {
      await supabase.auth.signOut()
      router.push('/register')
    }
  }

  return (
    <div className="dash-section animate-in fade-in duration-500">
      {toast && (
        <div style={{
          position: 'fixed', bottom: '24px', right: '24px', 
          backgroundColor: toast.isError ? 'var(--color-error)' : 'var(--color-success)', 
          color: 'white', padding: '12px 24px', borderRadius: '8px', zIndex: 9999,
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)', animation: 'slideUp 0.3s ease-out'
        }}>
          {toast.message}
        </div>
      )}

      <header className="dash-header">
        <h1 className="dash-header-title">Cài đặt</h1>
        <p className="dash-header-subtitle">Quản lý thông tin cá nhân và bảo mật tài khoản của bạn.</p>
      </header>

      <div className="dash-tab-container">
        <button 
          className={`dash-tab ${activeTab === 'profile' ? 'active' : ''}`}
          onClick={() => setActiveTab('profile')}
        >
          <User style={{ width: '20px', height: '20px', marginRight: '8px' }} />
          Hồ sơ cá nhân
        </button>
        <button 
          className={`dash-tab ${activeTab === 'security' ? 'active' : ''}`}
          onClick={() => setActiveTab('security')}
        >
          <Shield style={{ width: '20px', height: '20px', marginRight: '8px' }} />
          Bảo mật
        </button>
      </div>

      <div className="stats-card">
        {activeTab === 'profile' ? (
          <form onSubmit={handleSaveProfile} style={{ maxWidth: '600px', margin: '0 auto' }}>
            <h2 style={{ font: 'var(--text-display-md)', color: 'var(--color-ink)', marginBottom: '24px' }}>Thông tin cơ bản</h2>
            
            <div className="dash-form-group">
              <label className="dash-label">Họ và tên</label>
              <input 
                type="text" 
                className="dash-input" 
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
              />
            </div>

            <div className="dash-form-group">
              <label className="dash-label">Tên đăng nhập (Username)</label>
              <input 
                type="text" 
                className="dash-input" 
                defaultValue={profile?.username || ''} 
                disabled 
                style={{ backgroundColor: 'var(--color-canvas-parchment)', color: 'var(--color-ink-muted-48)', cursor: 'not-allowed' }}
              />
              <p style={{ marginTop: '8px', color: 'var(--color-ink-muted-48)', font: 'var(--text-fine-print)' }}>Username không thể thay đổi sau khi đăng ký.</p>
            </div>

            <div className="dash-form-group">
              <label className="dash-label">Địa chỉ Email</label>
              <input 
                type="email" 
                className="dash-input" 
                defaultValue={profile?.email_canonical || ''} 
                disabled 
                style={{ backgroundColor: 'var(--color-canvas-parchment)', color: 'var(--color-ink-muted-48)', cursor: 'not-allowed' }}
              />
              <p style={{ marginTop: '8px', color: 'var(--color-ink-muted-48)', font: 'var(--text-fine-print)' }}>Liên hệ hỗ trợ nếu bạn cần đổi email.</p>
            </div>

            <button 
              type="submit" 
              disabled={loading}
              className="dash-btn dash-btn-primary"
              style={{ marginTop: '16px' }}
            >
              {loading ? 'Đang lưu...' : 'Lưu Thay Đổi'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleChangePassword} style={{ maxWidth: '600px', margin: '0 auto' }}>
            <h2 style={{ font: 'var(--text-display-md)', color: 'var(--color-ink)', marginBottom: '24px' }}>Đổi mật khẩu</h2>
            
            <div className="dash-form-group">
              <label className="dash-label">Mật khẩu hiện tại</label>
              <input 
                type="password" 
                className="dash-input" 
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                required
              />
            </div>

            <div className="dash-form-group">
              <label className="dash-label">Mật khẩu mới</label>
              <input 
                type="password" 
                className="dash-input" 
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Tối thiểu 8 ký tự"
                required
              />
            </div>

            <button 
              type="submit" 
              disabled={loading}
              className="dash-btn dash-btn-primary"
              style={{ marginTop: '16px' }}
            >
              {loading ? 'Đang lưu...' : 'Đổi Mật Khẩu'}
            </button>
          </form>
        )}
      </div>

      {activeTab === 'security' && (
        <div className="stats-card" style={{ marginTop: '24px', borderColor: 'var(--color-error)', maxWidth: '600px', margin: '24px auto 0 auto' }}>
          <h2 style={{ font: 'var(--text-display-md)', color: 'var(--color-error)', marginBottom: '16px', display: 'flex', alignItems: 'center' }}>
            <AlertTriangle style={{ width: '24px', height: '24px', marginRight: '8px' }} />
            Vùng nguy hiểm
          </h2>
          <p style={{ font: 'var(--text-body)', color: 'var(--color-ink-muted-80)', marginBottom: '24px' }}>
            Hành động này sẽ xóa vĩnh viễn tài khoản của bạn và toàn bộ số dư Cam. Không thể khôi phục.
          </p>
          <button 
            type="button"
            className="dash-btn" 
            style={{ backgroundColor: 'transparent', border: '1px solid var(--color-error)', color: 'var(--color-error)' }}
            onClick={() => setShowConfirmDelete(true)}
          >
            Xóa Tài Khoản
          </button>
        </div>
      )}

      <ConfirmModal 
        isOpen={showConfirmDelete}
        onClose={() => setShowConfirmDelete(false)}
        onConfirm={handleDeleteAccount}
        title="Xóa vĩnh viễn tài khoản?"
        message="Bạn có chắc chắn muốn xóa vĩnh viễn tài khoản và toàn bộ số dư Cam? Hành động này không thể hoàn tác!"
        confirmText="Xác nhận xóa"
        isDanger={true}
        loading={isDeleting}
      />
    </div>
  )
}
