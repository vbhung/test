const status = document.querySelector("#status"), setup = document.querySelector("#setup"), game = document.querySelector("#game"), ownBoard = document.querySelector("#own-board"), enemyBoard = document.querySelector("#enemy-board"), turn = document.querySelector("#turn"), events = document.querySelector("#events"), weapons = document.querySelector("#weapons"), clock = document.querySelector("#placement-clock"), fleetDock = document.querySelector("#fleet-dock"), ownBadge = document.querySelector("#own-badge"), enemyBadge = document.querySelector("#enemy-badge");
let token, playerId, socket, state, activeMatchId, reconnectTimer, placement = [], selectedShipId = null, selectedLength = 5, timer, initialized = false;
let cellCache = { own: null, enemy: null };

const fleetNames = { 2: "Patrol", 3: "Submarine", 4: "Destroyer", 5: "Battleship", 6: "Carrier", 7: "Titan" };
const weaponMeta = {
  single: { label: "Single", icon: "🔫" },
  cross: { label: "Cross", icon: "✚" },
  diamond: { label: "Diamond", icon: "◆" },
  bomber: { label: "Bomber", icon: "💣" },
};

const partnerOrigin = window.__PARTNER_ORIGIN__ || "http://localhost:3000";
window.addEventListener("message", event => { if ((event.origin === partnerOrigin || event.origin === "http://localhost:3000" || event.origin === "http://127.0.0.1:3000") && event.data?.type === "battleship:init" && !initialized) { initialized = true; ({ token, playerId } = event.data); connectQueue(event.data.betTier, event.data.amount); } });
window.parent.postMessage({ type: "battleship:ready" }, partnerOrigin);

document.querySelector("#ready").addEventListener("click", () => { const expected = fleetConfig(state?.boardSize || 10); if (placement.length !== expected.length) return note(`Deploy all ${expected.length} ships before locking your fleet.`); socket.send(JSON.stringify({ type: "placeShips", ships: placement })); status.textContent = "Fleet locked. Waiting for your opponent..."; });
document.querySelector("#random-fleet").addEventListener("click", () => { if (!state || state.phase !== "placing") return; const cfg = fleetConfig(state.boardSize); const ships = randomFleet(state.boardSize, cfg); if (ships) { placement = ships; renderBoard(ownBoard, placement, [], [], false, true, false); updateDock(); selectedShipId = null; note("Random fleet deployed. You can still drag ships to adjust."); } });

function buildDock(config) {
  fleetDock.replaceChildren();
  for (const entry of config) {
    const card = document.createElement("button");
    card.className = "ship-card"; card.draggable = true; card.dataset.id = entry.id; card.dataset.length = String(entry.length);
    const art = document.createElement("span"); art.className = "ship-art";
    for (let i = 0; i < entry.length; i++) art.append(document.createElement("i"));
    const meta = document.createElement("span"); meta.innerHTML = `${fleetNames[entry.length] || "Ship"} <small>${entry.length} cells</small>`;
    card.append(art, meta);
    card.addEventListener("dragstart", event => { selectedShipId = entry.id; selectedLength = entry.length; event.dataTransfer.setData("text/plain", entry.id); });
    card.addEventListener("click", () => { selectedShipId = entry.id; selectedLength = entry.length; note(`Selected ${entry.length}-cell ${fleetNames[entry.length] || "ship"}. Click an empty cell or drag it.`); });
    fleetDock.append(card);
  }
  const next = config.find(entry => !placement.some(ship => ship.id === entry.id));
  if (next) { selectedShipId = next.id; selectedLength = next.length; }
}

function connectQueue(tier, amount) {
  status.textContent = "Joining matchmaking fleet class...";
  const s = new WebSocket(ws(`/ws/queue/${encodeURIComponent(tier)}/${encodeURIComponent(amount)}`));
  socket = s;
  s.addEventListener("open", () => { if (socket === s) s.send(JSON.stringify({ type: "join", token })); });
  s.addEventListener("message", event => {
    const message = JSON.parse(event.data);
    if (message.type === "queueWaiting") status.textContent = `Searching in the ${message.betTier} fleet class...`;
    if (message.type === "matchFound") connectMatch(message.matchId);
    if (message.type === "error") note(`Queue error: ${message.code}`);
  });
  s.addEventListener("close", () => { if (!state && socket === s) status.textContent = "Queue connection closed."; });
}
function connectMatch(matchId) {
  activeMatchId = matchId; clearTimeout(reconnectTimer); clearInterval(timer); clock.textContent = "";
  cellCache = { own: null, enemy: null };
  status.textContent = "Opponent found. Connecting to match...";
  const s = new WebSocket(ws(`/ws/match/${matchId}`));
  socket = s;
  s.addEventListener("open", () => { if (socket === s) s.send(JSON.stringify({ type: "auth", token })); });
  s.addEventListener("message", event => { if (socket === s) handle(JSON.parse(event.data)); });
  s.addEventListener("close", () => { if (socket === s && (!state || !["finished", "cancelled"].includes(state.phase))) { note("Connection lost. Reconnecting for up to 60 seconds before forfeit."); reconnectTimer = setTimeout(() => connectMatch(activeMatchId), 2500); } });
}
function ws(path) { return `${location.protocol === "https:" ? "wss" : "ws"}://${location.host}${path}`; }
function handle(message) {
  if (message.type === "error") return note(`Game error: ${message.code}`);
  if (message.type === "matchCancelled") { status.textContent = "Match cancelled"; return note(`Match cancelled: ${message.reason}. No settlement was made.`); }
  if (message.type === "shotResult") {
    const hits = message.impacts.filter(i => i.result === "hit").length;
    const bonus = message.bonus ? " — Bonus single shot!" : "";
    const mystery = message.mysteryAward ? ` — Mystery: +1 ${weaponMeta[message.mysteryAward].label}!` : "";
    note(`${weaponMeta[message.weapon].label} strike: ${hits} hit${hits === 1 ? "" : "s"}${message.sunkLengths?.length ? ` — Sunk ${message.sunkLengths.join(",")}-cell ship!` : ""}${bonus}${mystery}.`);
    const board = state?.you?.seat === message.actorSeat ? enemyBoard : ownBoard;
    for (const impact of message.impacts) spawnFx(board, impact.x, impact.y, impact.result);
    // If mystery was consumed, clear it immediately so the cell shows miss marker
    if (message.mysteryAward && state) { state.mysteryCell = null; }
  }
  if (message.type === "matchState") { state = message.state; render(); }
}

function render() {
  const placing = state.phase === "placing";
  setup.classList.toggle("hidden", !placing || state.tier === "little");
  game.classList.remove("hidden");
  const config = fleetConfig(state.boardSize);
  if (placing && state.tier !== "little" && fleetDock.children.length !== config.length) buildDock(config);
  ownBoard.style.setProperty("--size", state.boardSize); enemyBoard.style.setProperty("--size", state.boardSize);
  fitBoard(ownBoard); fitBoard(enemyBoard);
  const myTurn = state.phase === "playing" && state.turn === state.you.seat;
  const bonusActive = myTurn && state.lastHitShipId;
  ownBadge.textContent = `${state.you.ships.length}/${config.length} ships`;
  enemyBadge.textContent = `${state.opponent.shots.length} shots`;
  const mysteryActive = state.mysteryCell;
  if (placing) {
    turn.textContent = state.tier === "little" ? "Fleet auto-deployed. Waiting for opponent..." : "Deploy your fleet before the timer runs out.";
    setTimer(state.placementDeadline);
  } else if (state.phase === "finished") {
    turn.textContent = state.winnerId === playerId ? `🏆 Victory! ${state.finishReason}` : `💀 Defeat: ${state.finishReason}`;
    setTimer(0);
  } else {
    turn.textContent = bonusActive ? "🔥 Bonus single shot! Keep hitting the same ship." : myTurn ? (mysteryActive ? "❓ A mystery cell appeared! Click it for a bonus weapon." : "Your turn. Pick a weapon and fire!") : `${state.opponent.displayName}${state.opponent.connected ? " is plotting..." : " disconnected — 60s grace"}`;
    setTimer(0);
  }
  const finished = state.phase === "finished";
  renderBoard(ownBoard, state.you.ships, state.you.incomingShots, state.you.incomingHitShots, false, true, false, null, "own");
  renderBoard(enemyBoard, state.opponent.ships, state.opponent.shots, state.opponent.hitShots, myTurn, true, !finished, mysteryActive ? state.mysteryCell : null, "enemy");
  renderWeapons(myTurn);
  updateDock();
}

function setTimer(deadline) {
  clearInterval(timer);
  if (!deadline) { clock.textContent = ""; return; }
  const update = () => { const seconds = Math.max(0, Math.ceil((deadline - Date.now()) / 1000)); clock.textContent = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`; };
  update(); timer = setInterval(update, 500);
}

function ensureBoardStructure(container, size, which) {
  if (cellCache[which] && cellCache[which].size === size) return cellCache[which];
  container.replaceChildren();
  const cellMap = new Map();
  // Labels
  for (let x = 0; x < size; x++) { const label = document.createElement("div"); label.className = "coord-label col"; label.textContent = String.fromCharCode(65 + x); label.style.left = `calc(var(--gap) + ${x} * (var(--cell) + var(--gap)))`; container.append(label); }
  for (let y = 0; y < size; y++) { const label = document.createElement("div"); label.className = "coord-label row"; label.textContent = String(y + 1); label.style.top = `calc(var(--gap) + ${y} * (var(--cell) + var(--gap)))`; container.append(label); }
  // Overlay container
  const overlayLayer = document.createElement("div"); overlayLayer.className = "overlay-layer"; container.append(overlayLayer);
  // Cells (plain divs, no per-cell listeners)
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const key = `${x},${y}`, cell = document.createElement("button");
    cell.className = "cell"; cell.dataset.key = key; cell.dataset.x = String(x); cell.dataset.y = String(y);
    cell.title = `${String.fromCharCode(65 + x)}${y + 1}`;
    cellMap.set(key, cell); container.append(cell);
  }
  // Event delegation: single listener on container
  container.addEventListener("click", (e) => {
    const cell = e.target.closest("button.cell");
    if (!cell || !cell.dataset.key) return;
    const cx = Number(cell.dataset.x), cy = Number(cell.dataset.y);
    const key = cell.dataset.key;
    if (cell.classList.contains("drop-target")) cell.classList.remove("drop-target");
    // Placing phase on own board
    if (which === "own" && state?.phase === "placing" && state.tier !== "little") {
      const placedShip = placement.find(s => cells(s).includes(key));
      if (placedShip) { pickupShip(placedShip.id); return; }
      if (selectedShipId) dropShip(cx, cy, selectedShipId, selectedLength);
      return;
    }
    // Playing phase on enemy board
    if (which === "enemy" && state?.phase === "playing" && state.turn === state.you.seat) {
      if (cell.classList.contains("miss") || cell.classList.contains("hit") || cell.classList.contains("ship-hit")) return;
      const mysteryKey = state.mysteryCell ? `${state.mysteryCell.x},${state.mysteryCell.y}` : null;
      if (key === mysteryKey) { const prev = selectedWeapon; selectedWeapon = "single"; fire(cx, cy); selectedWeapon = prev; }
      else fire(cx, cy);
    }
  });
  container.addEventListener("dragover", (e) => {
    if (which !== "own" || state?.phase !== "placing") return;
    const cell = e.target.closest("button.cell"); if (!cell) return;
    const placedShip = placement.find(s => cells(s).includes(cell.dataset.key));
    if (placedShip) return;
    e.preventDefault(); cell.classList.add("drop-target");
  });
  container.addEventListener("dragleave", (e) => {
    const cell = e.target.closest("button.cell"); if (cell) cell.classList.remove("drop-target");
  });
  container.addEventListener("drop", (e) => {
    if (which !== "own" || state?.phase !== "placing") return;
    const cell = e.target.closest("button.cell"); if (!cell) return;
    e.preventDefault(); cell.classList.remove("drop-target");
    const cx = Number(cell.dataset.x), cy = Number(cell.dataset.y);
    const data = e.dataTransfer.getData("text/plain");
    dropShip(cx, cy, data || selectedShipId, selectedLength);
  });
  container.addEventListener("dragstart", (e) => {
    if (which !== "own" || state?.phase !== "placing") return;
    const cell = e.target.closest("button.cell"); if (!cell) return;
    const placedShip = placement.find(s => cells(s).includes(cell.dataset.key));
    if (placedShip) { selectedShipId = placedShip.id; selectedLength = placedShip.length; e.dataTransfer.setData("text/plain", placedShip.id); }
  });
  const cache = { size, cellMap, overlayLayer };
  cellCache[which] = cache;
  return cache;
}

function renderBoard(container, ships, shots, hitShots, clickable, showShips, onlySunk = false, mystery = null, which = "own") {
  const size = state.boardSize;
  const cache = ensureBoardStructure(container, size, which);
  const { cellMap, overlayLayer } = cache;
  const visibleShips = showShips ? (onlySunk ? ships.filter(ship => shipCells(ship).every(cell => shots.includes(cell))) : ships) : [];
  const shipSet = new Set(visibleShips.flatMap(cells));
  const shotSet = new Set(shots);
  const hitSet = new Set(hitShots);
  const mysteryKey = mystery ? `${mystery.x},${mystery.y}` : null;
  // Update cells — only change classes and children, no DOM recreation
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const key = `${x},${y}`, cell = cellMap.get(key);
    if (!cell) continue;
    let cls = "cell";
    if (clickable) cls += " enemy";
    if (shipSet.has(key) && shotSet.has(key)) cls += " ship-hit";
    else if (hitSet.has(key)) cls += " hit";
    else if (shotSet.has(key)) cls += " miss";
    if (key === mysteryKey) cls += " mystery";
    if (cell.className !== cls) cell.className = cls;
    // Update children only if needed
    const hasMarker = cell.firstChild !== null;
    const needMarker = (shotSet.has(key) || hitSet.has(key)) || key === mysteryKey;
    if (hasMarker !== needMarker) {
      cell.replaceChildren();
      if (key === mysteryKey) { const m = document.createElement("span"); m.className = "marker mystery-marker"; m.textContent = "?"; cell.append(m); }
      if (shotSet.has(key) || hitSet.has(key)) { const marker = document.createElement("span"); marker.className = `marker ${shipSet.has(key) || hitSet.has(key) ? "hit" : "miss"}`; marker.textContent = shipSet.has(key) || hitSet.has(key) ? "✦" : "•"; cell.append(marker); }
    }
  }
  // Ship overlays
  overlayLayer.replaceChildren();
  if (visibleShips.length) renderShipOverlays(overlayLayer, visibleShips, shots);
  if (container === ownBoard && state.phase !== "placing") renderDamagedSegments(overlayLayer, ships, shots);
}

function renderShipOverlays(layer, ships, shots) {
  const shotSet = new Set(shots);
  for (const ship of ships) {
    const overlay = document.createElement("div");
    const sunk = shipCells(ship).every(cell => shotSet.has(cell));
    overlay.className = `ship-overlay ${ship.orientation.toLowerCase()} ${sunk ? "sunk" : ""}`;
    if (ship.orientation === "H") {
      overlay.style.width = `calc(${ship.length} * var(--cell) + ${ship.length - 1} * var(--gap))`;
      overlay.style.height = `var(--cell)`;
    } else {
      overlay.style.width = `var(--cell)`;
      overlay.style.height = `calc(${ship.length} * var(--cell) + ${ship.length - 1} * var(--gap))`;
    }
    overlay.style.left = `calc(var(--gap) + ${ship.x} * (var(--cell) + var(--gap)))`;
    overlay.style.top = `calc(var(--gap) + ${ship.y} * (var(--cell) + var(--gap)))`;
    layer.append(overlay);
  }
}
function renderDamagedSegments(layer, ships, shots) {
  const shotSet = new Set(shots);
  for (const ship of ships) {
    for (const cell of shipCells(ship)) {
      if (!shotSet.has(cell)) continue;
      const [x, y] = cell.split(",").map(Number);
      const segment = document.createElement("div");
      segment.className = "ship-damaged";
      segment.style.left = `calc(var(--gap) + ${x} * (var(--cell) + var(--gap)))`;
      segment.style.top = `calc(var(--gap) + ${y} * (var(--cell) + var(--gap)))`;
      layer.append(segment);
    }
  }
}

function dropShip(x, y, shipId, length) {
  if (!shipId) return note("Select a ship from the dock first.");
  const orientation = Math.random() < 0.5 ? "H" : "V";
  const ship = { id: shipId, x, y, length, orientation };
  const proposed = cells(ship);
  if (proposed.some(key => { const [cx, cy] = key.split(",").map(Number); return cx >= state.boardSize || cy >= state.boardSize; })) return note("That ship would leave the board.");
  const otherCells = new Set(placement.filter(s => s.id !== shipId).flatMap(cells));
  if (proposed.some(key => otherCells.has(key))) return note("That ship overlaps another ship.");
  placement = placement.filter(s => s.id !== shipId);
  placement.push(ship);
  renderBoard(ownBoard, placement, [], [], false, true, false, null, "own");
  updateDock();
  const next = fleetConfig(state.boardSize).find(entry => !placement.some(p => p.id === entry.id));
  if (next) { selectedShipId = next.id; selectedLength = next.length; }
  else { selectedShipId = null; }
}
function pickupShip(shipId) {
  const ship = placement.find(s => s.id === shipId);
  if (!ship) return;
  selectedShipId = shipId;
  selectedLength = ship.length;
  note("Ship selected. Click or drag an empty cell to reposition. Orientation is random on each drop.");
}
function updateDock() {
  for (const card of document.querySelectorAll(".ship-card")) card.classList.toggle("placed", placement.some(ship => ship.id === card.dataset.id));
}
function renderWeapons(myTurn) {
  weapons.replaceChildren();
  if (!state || state.phase !== "playing") return;
  const bonusLocked = myTurn && state.lastHitShipId;
  for (const weapon of ["single", "cross", "diamond", "bomber"]) {
    const amount = state.you.weapons[weapon];
    if (weapon !== "single" && amount <= 0) continue;
    const meta = weaponMeta[weapon];
    const button = document.createElement("button");
    button.innerHTML = `<span class="icon">${meta.icon}</span><span>${meta.label}${weapon === "single" ? "" : ` x${amount}`}</span>`;
    button.classList.toggle("active", weapon === selectedWeapon);
    button.disabled = !myTurn || (bonusLocked && weapon !== "single");
    button.addEventListener("click", () => { selectedWeapon = weapon; renderWeapons(myTurn); });
    weapons.append(button);
  }
  if (bonusLocked && selectedWeapon !== "single") selectedWeapon = "single";
}
let selectedWeapon = "single";
function fire(x, y) { socket.send(JSON.stringify({ type: "shoot", x, y, weapon: selectedWeapon, moveId: crypto.randomUUID() })); selectedWeapon = "single"; }
function fleetSet(size) { return size === 20 ? [7, 6, 5, 4, 3, 3, 2, 2] : [5, 4, 3, 3, 2]; }
function fleetConfig(size) {
  const lengths = fleetSet(size);
  return lengths.map((length, index) => ({ id: `ship-${length}-${index}`, length }));
}
function cells(ship) { return Array.from({ length: ship.length }, (_, i) => `${ship.x + (ship.orientation === "H" ? i : 0)},${ship.y + (ship.orientation === "V" ? i : 0)}`); }
function shipCells(ship) { return cells(ship); }
function spawnFx(container, x, y, result) {
  const fx = document.createElement("div"); fx.className = `fx ${result === "hit" ? "explosion" : "splash"}`;
  fx.style.left = `calc(var(--gap) + ${x} * (var(--cell) + var(--gap)))`;
  fx.style.top = `calc(var(--gap) + ${y} * (var(--cell) + var(--gap)))`;
  container.append(fx);
  setTimeout(() => fx.remove(), 800);
}
function note(message) { events.textContent = message; }
function fitBoard(board) {
  const size = Number(board.style.getPropertyValue("--size")) || 10;
  const wrap = board.parentElement;
  if (!wrap) return;
  const wrapWidth = wrap.clientWidth - 8;
  const labelMargin = 28;
  const gap = 3;
  const availableWidth = wrapWidth - labelMargin - gap * 2;
  const cellSize = Math.max(14, Math.floor((availableWidth - gap * (size - 1)) / size));
  board.style.setProperty("--cell", cellSize + "px");
}
function randomFleet(size, config) {
  for (let attempt = 0; attempt < 5000; attempt++) {
    const ships = [];
    const occupied = new Set();
    let ok = true;
    for (const entry of config) {
      let placed = false;
      for (let tries = 0; tries < 200; tries++) {
        const orientation = Math.random() < 0.5 ? "H" : "V";
        const maxX = orientation === "H" ? size - entry.length : size - 1;
        const maxY = orientation === "V" ? size - entry.length : size - 1;
        const x = Math.floor(Math.random() * (maxX + 1));
        const y = Math.floor(Math.random() * (maxY + 1));
        const ship = { id: entry.id, x, y, length: entry.length, orientation };
        const shipCells = cells(ship);
        if (shipCells.some(c => occupied.has(c))) continue;
        ships.push(ship);
        shipCells.forEach(c => occupied.add(c));
        placed = true;
        break;
      }
      if (!placed) { ok = false; break; }
    }
    if (ok) return ships;
  }
  return null;
}
window.addEventListener("resize", () => { if (state) { fitBoard(ownBoard); fitBoard(enemyBoard); } });
