export interface Env {
  QUEUE_ROOM: DurableObjectNamespace;
  MATCH_ROOM: DurableObjectNamespace;
  ASSETS: Fetcher;
  PARTNER_ID: string;
  PARTNER_ORIGIN: string;
  WEBHOOK_URL: string;
  INTEGRATION_SECRET: string;
}

export interface SessionClaims {
  version: 1;
  partnerId: string;
  playerId: string;
  displayName: string;
  betTier: string;
  amount: number;
  wagerContextId: string;
  issuedAt: number;
  expiresAt: number;
  nonce: string;
}

export interface Player {
  playerId: string;
  displayName: string;
  seat: 0 | 1;
}

export interface Ship {
  id: string;
  x: number;
  y: number;
  length: 2 | 3 | 4 | 5 | 6 | 7;
  orientation: "H" | "V";
}

export type ShotResult = "hit" | "miss" | "sunk";
