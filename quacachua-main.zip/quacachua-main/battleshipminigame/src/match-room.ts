import { signBody, verifyToken } from "./auth";
import type { Env, Player, Ship } from "./types";

type Tier = "little" | "middle" | "large";
type Phase = "placing" | "playing" | "finished" | "cancelled";
type Weapon = "single" | "cross" | "diamond" | "bomber";
interface MatchPlayer extends Player { wagerContextId: string; ships: Ship[]; shots: string[]; hitShots: string[]; ready: boolean; connected: boolean; disconnectedAt?: number; weapons: Record<Weapon, number>; mysteryBomberCount: number; mysteryNextMove: number; mysteryCell: { x: number; y: number } | null; }
interface MatchState { matchId: string; tier: Tier; amount: number; boardSize: number; phase: Phase; placementDeadline: number; players: MatchPlayer[]; turn: 0 | 1; moveNo: number; moves: unknown[]; winnerId?: string; finishReason?: string; lastHitShipId?: string; completed: boolean; }

const PLACEMENT_MS_LITTLE = 60_000;
const PLACEMENT_MS_LARGE = 120_000;
const DISCONNECT_GRACE_MS = 60_000;

const tierConfig: Record<Tier, { boardSize: number; manualPlacement: boolean; cross: number; diamond: number; bomber: number; mysteryStart: number; mysteryInterval: number; diamondChance: number }> = {
  little: { boardSize: 10, manualPlacement: false, cross: 2, diamond: 0, bomber: 0, mysteryStart: 0, mysteryInterval: 0, diamondChance: 0 },
  middle: { boardSize: 10, manualPlacement: true, cross: 2, diamond: 0, bomber: 0, mysteryStart: 6, mysteryInterval: 10, diamondChance: 0 },
  large: { boardSize: 20, manualPlacement: true, cross: 3, diamond: 0, bomber: 1, mysteryStart: 8, mysteryInterval: 10, diamondChance: 0.25 },
};

const fleetSets: Record<10 | 20, number[]> = {
  10: [5, 4, 3, 3, 2],
  20: [7, 6, 5, 4, 3, 3, 2, 2],
};

export class MatchRoom {
  private sockets = new Map<WebSocket, string>();
  private match: MatchState | null = null;

  constructor(private state: DurableObjectState, private env: Env) {
    this.state.blockConcurrencyWhile(async () => { this.match = await this.state.storage.get<MatchState>("match") ?? null; });
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    if (url.pathname === "/create" && request.method === "POST") return this.create(request);
    if (request.headers.get("Upgrade")?.toLowerCase() !== "websocket") return new Response("WebSocket required", { status: 426 });
    const pair = new WebSocketPair(); const [client, server] = Object.values(pair);
    server.accept();
    server.addEventListener("message", (event) => void this.onMessage(server, String(event.data)));
    server.addEventListener("close", () => void this.onClose(server));
    server.addEventListener("error", () => void this.onClose(server));
    return new Response(null, { status: 101, webSocket: client });
  }

  async alarm(): Promise<void> {
    if (!this.match || this.match.phase === "finished" || this.match.phase === "cancelled") return;
    const now = Date.now();
    if (this.match.phase === "placing" && now >= this.match.placementDeadline) {
      await this.cancelMatch("placement_timeout");
      return;
    }
    if (this.match.phase === "playing") {
      const disconnected = this.match.players.find((player) => player.disconnectedAt && now - player.disconnectedAt >= DISCONNECT_GRACE_MS);
      if (disconnected) await this.finishMatch(this.match.players[disconnected.seat === 0 ? 1 : 0].playerId, "disconnect_timeout");
      else await this.scheduleAlarm();
    }
  }

  private async create(request: Request): Promise<Response> {
    if (this.match) return Response.json({ error: "ALREADY_CREATED" }, { status: 409 });
    const body = await request.json() as { matchId: string; tier: Tier; amount: number; players: Array<MatchPlayer> };
    if (!body.matchId || !tierConfig[body.tier] || body.players.length !== 2) return Response.json({ error: "INVALID_MATCH" }, { status: 400 });
    const config = tierConfig[body.tier];
    const placementMs = body.tier === "large" ? PLACEMENT_MS_LARGE : PLACEMENT_MS_LITTLE;
    this.match = {
      matchId: body.matchId, tier: body.tier, amount: body.amount, boardSize: config.boardSize, phase: "placing", placementDeadline: Date.now() + placementMs,
      players: body.players.map((player) => ({ ...player, ships: config.manualPlacement ? [] : randomShips(config.boardSize), shots: [], hitShots: [], ready: !config.manualPlacement, connected: false, weapons: { single: -1, cross: config.cross, diamond: config.diamond, bomber: config.bomber }, mysteryBomberCount: 0, mysteryNextMove: config.mysteryStart, mysteryCell: null })),
      turn: 0, moveNo: 0, moves: [], completed: false,
    };
    if (!config.manualPlacement) this.match.phase = "playing";
    await this.persist(); await this.scheduleAlarm();
    return Response.json({ ok: true });
  }

  private async onMessage(socket: WebSocket, raw: string): Promise<void> {
    let message: { type?: string; token?: string; ships?: Array<{ x: number; y: number; length: number; orientation: "H" | "V" }>; x?: number; y?: number; moveId?: string; weapon?: Weapon };
    try { message = JSON.parse(raw); } catch { return this.send(socket, { type: "error", code: "BAD_MESSAGE" }); }
    if (message.type === "ping") return this.send(socket, { type: "pong" });
    if (message.type === "auth") return this.authenticate(socket, message.token ?? "");
    const player = this.playerForSocket(socket);
    if (!player) return this.send(socket, { type: "error", code: "AUTH_REQUIRED" });
    if (message.type === "placeShips") return this.placeShips(socket, player, message.ships ?? []);
    if (message.type === "shoot") return this.shoot(socket, player, message.x, message.y, message.weapon ?? "single", message.moveId);
    this.send(socket, { type: "error", code: "UNKNOWN_ACTION" });
  }

  private async authenticate(socket: WebSocket, token: string): Promise<void> {
    const claims = await verifyToken(token, this.env);
    const player = claims && this.match?.players.find((entry) => entry.playerId === claims.playerId);
    if (!player || !this.match || this.match.phase === "finished" || this.match.phase === "cancelled") return this.send(socket, { type: "error", code: "INVALID_MATCH_TOKEN" });
    if (player.wagerContextId !== claims.wagerContextId || claims.betTier !== this.match.tier) return this.send(socket, { type: "error", code: "MATCH_MISMATCH" });
    this.sockets.set(socket, player.playerId); player.connected = true; delete player.disconnectedAt;
    await this.persist(); await this.scheduleAlarm(); this.send(socket, { type: "matchState", state: this.clientState(player.playerId) });
  }

  private async placeShips(socket: WebSocket, player: MatchPlayer, ships: Array<{ x: number; y: number; length: number; orientation: "H" | "V" }>): Promise<void> {
    if (!this.match || this.match.phase !== "placing") return this.send(socket, { type: "error", code: "NOT_PLACING" });
    if (!tierConfig[this.match.tier].manualPlacement) return this.send(socket, { type: "error", code: "AUTO_PLACED_TIER" });
    const shipsWithId: Ship[] = ships.map((ship, index) => ({ ...ship, id: `${player.seat}-${index}`, length: ship.length as Ship["length"] }));
    if (!validShips(shipsWithId, this.match.boardSize)) return this.send(socket, { type: "error", code: "INVALID_SHIPS" });
    player.ships = shipsWithId; player.ready = true;
    if (this.match.players.every((entry) => entry.ready)) this.match.phase = "playing";
    await this.persist(); await this.scheduleAlarm(); this.broadcastState();
  }

  private async shoot(socket: WebSocket, player: MatchPlayer, x: number | undefined, y: number | undefined, weapon: Weapon, moveId: string | undefined): Promise<void> {
    if (!this.match || this.match.phase !== "playing") return this.send(socket, { type: "error", code: "NOT_PLAYING" });
    if (player.seat !== this.match.turn) return this.send(socket, { type: "error", code: "NOT_YOUR_TURN" });
    if (!Number.isInteger(x) || !Number.isInteger(y) || x! < 0 || y! < 0 || x! >= this.match.boardSize || y! >= this.match.boardSize || !moveId) return this.send(socket, { type: "error", code: "INVALID_SHOT" });
    if (this.match.moves.some((move: any) => move.moveId === moveId)) return;
    if (this.match.lastHitShipId && weapon !== "single") return this.send(socket, { type: "error", code: "BONUS_SINGLE_ONLY" });
    if (!this.hasWeapon(player, weapon)) return this.send(socket, { type: "error", code: "WEAPON_UNAVAILABLE" });
    const target = this.match.players[player.seat === 0 ? 1 : 0];
    const cells = this.weaponCells(weapon, x!, y!, player);
    const freshCells = cells.filter((cell) => !player.shots.includes(cell));
    if (!freshCells.length) return this.send(socket, { type: "error", code: "AREA_ALREADY_REVEALED" });
    this.consumeWeapon(player, weapon);
    const targetCells = new Set(target.ships.flatMap(shipCells));
    const impacts = freshCells.map((cell) => ({ ...point(cell), result: targetCells.has(cell) ? "hit" : "miss" }));
    for (const cell of freshCells) { if (targetCells.has(cell)) player.hitShots.push(cell); }
    player.shots.push(...freshCells);

    const sunkShips = target.ships.filter((ship) => shipCells(ship).every((cell) => player.shots.includes(cell)));
    const sunkLengths = sunkShips.map((ship) => ship.length);
    const allSunk = target.ships.every((ship) => shipCells(ship).every((cell) => player.shots.includes(cell)));
    this.match.moveNo++; this.match.moves.push({ moveNo: this.match.moveNo, moveId, playerId: player.playerId, weapon, x, y, impacts });

    if (allSunk) { this.match.lastHitShipId = undefined; await this.finishMatch(player.playerId, "all_ships_sunk"); return; }

    let nextTurn = true;
    if (weapon === "single" && impacts[0].result === "hit") {
      const hitShip = target.ships.find((ship) => shipCells(ship).includes(`${impacts[0].x},${impacts[0].y}`));
      const hitShipId = hitShip?.id;
      if (hitShipId && !sunkShips.some((ship) => ship.id === hitShipId)) {
        if (!this.match.lastHitShipId || this.match.lastHitShipId === hitShipId) {
          this.match.lastHitShipId = hitShipId;
          nextTurn = false;
        } else {
          this.match.lastHitShipId = undefined;
        }
      } else {
        this.match.lastHitShipId = undefined;
      }
    } else {
      this.match.lastHitShipId = undefined;
    }

    // Mystery cell (per-player): if player shot their own mystery cell with single, award bonus weapon
    let mysteryAward: Weapon | null = null;
    if (player.mysteryCell && weapon === "single" && x === player.mysteryCell.x && y === player.mysteryCell.y) {
      const tier = this.match!.tier;
      const cfg = tierConfig[tier];
      if (tier === "middle") {
        mysteryAward = "bomber";
      } else if (tier === "large") {
        // 25% diamond, 75% bomber
        mysteryAward = Math.random() < cfg.diamondChance ? "diamond" : "bomber";
      }
      if (mysteryAward) {
        player.weapons[mysteryAward]++;
        if (mysteryAward === "bomber") player.mysteryBomberCount++;
      }
      player.mysteryCell = null;
      // Schedule next mystery
      player.mysteryNextMove = this.match.moveNo + cfg.mysteryInterval;
    }

    // Generate mystery cell for current player if threshold reached
    const cfg = tierConfig[this.match.tier];
    if (cfg.mysteryStart > 0 && !player.mysteryCell && this.match.moveNo >= player.mysteryNextMove) {
      this.generateMysteryCell(player);
    }

    // Also generate mystery for opponent if their threshold is reached (fairness: both get ? at same pace)
    const opponent = this.match.players[player.seat === 0 ? 1 : 0];
    if (cfg.mysteryStart > 0 && !opponent.mysteryCell && this.match.moveNo >= opponent.mysteryNextMove) {
      this.generateMysteryCell(opponent);
    }

    if (nextTurn) this.match.turn = this.match.turn === 0 ? 1 : 0;
    await this.persist();
    this.broadcast({ type: "shotResult", moveNo: this.match.moveNo, actorSeat: player.seat, weapon, x, y, impacts, sunkLengths, bonus: !nextTurn, mysteryAward, nextSeat: this.match.turn });
    this.broadcastState();
  }

  private hasWeapon(player: MatchPlayer, weapon: Weapon): boolean {
    if (!this.match) return false;
    if (weapon === "single") return true;
    return player.weapons[weapon] > 0;
  }
  private consumeWeapon(player: MatchPlayer, weapon: Weapon): void { if (!this.match || weapon === "single") return; player.weapons[weapon]--; }
  private weaponCells(weapon: Weapon, x: number, y: number, player: MatchPlayer): string[] {
    if (!this.match) return [];
    const size = this.match.boardSize;
    const base = areaOffsets(weapon, size);
    let offsets = base;
    if (weapon === "bomber") {
      const extra = this.match.tier === "middle" ? 3 : 4;
      const candidates = allCells(size).filter((cell) => cell !== `${x},${y}` && !player.shots.includes(cell));
      offsets = [[0, 0], ...shuffle(candidates).slice(0, extra).map((cell): [number, number] => { const [cx, cy] = cell.split(",").map(Number); return [cx - x, cy - y]; })];
    }
    return offsets.map(([dx, dy]) => [x + dx, y + dy]).filter(([cx, cy]) => cx >= 0 && cy >= 0 && cx < size && cy < size).map(([cx, cy]) => `${cx},${cy}`);
  }
  private playerForSocket(socket: WebSocket): MatchPlayer | undefined { return this.match?.players.find((player) => player.playerId === this.sockets.get(socket)); }
  private generateMysteryCell(player: MatchPlayer): void {
    if (!this.match || player.mysteryCell) return;
    const allShots = new Set(this.match.players.flatMap((p) => p.shots));
    const shipCellSet = new Set(this.match.players.flatMap((p) => p.ships.flatMap(shipCells)));
    const candidates: string[] = [];
    for (let y = 0; y < this.match.boardSize; y++) for (let x = 0; x < this.match.boardSize; x++) {
      const key = `${x},${y}`;
      if (!allShots.has(key) && !shipCellSet.has(key)) candidates.push(key);
    }
    if (!candidates.length) return;
    const key = candidates[Math.floor(Math.random() * candidates.length)];
    const [x, y] = key.split(",").map(Number);
    player.mysteryCell = { x, y };
  }

  private clientState(playerId: string): unknown {
    if (!this.match) return null;
    const me = this.match.players.find((player) => player.playerId === playerId)!; const opponent = this.match.players[me.seat === 0 ? 1 : 0];
    return { matchId: this.match.matchId, tier: this.match.tier, boardSize: this.match.boardSize, phase: this.match.phase, placementDeadline: this.match.placementDeadline, you: { playerId: me.playerId, displayName: me.displayName, seat: me.seat, ships: me.ships, incomingShots: opponent.shots, incomingHitShots: opponent.hitShots, shots: me.shots, hitShots: me.hitShots, weapons: me.weapons }, opponent: { playerId: opponent.playerId, displayName: opponent.displayName, seat: opponent.seat, ships: opponent.ships, shots: me.shots, hitShots: me.hitShots, connected: opponent.connected }, turn: this.match.turn, moveNo: this.match.moveNo, lastHitShipId: this.match.lastHitShipId ?? null, mysteryCell: me.mysteryCell, winnerId: this.match.winnerId ?? null, finishReason: this.match.finishReason ?? null };
  }
  private broadcastState(): void { for (const [socket, playerId] of this.sockets) this.send(socket, { type: "matchState", state: this.clientState(playerId) }); }
  private broadcast(data: unknown): void { for (const socket of this.sockets.keys()) this.send(socket, data); }
  private send(socket: WebSocket, data: unknown): void { try { socket.send(JSON.stringify(data)); } catch { void this.onClose(socket); } }
  private async persist(): Promise<void> { await this.state.storage.put("match", this.match); }
  private async scheduleAlarm(): Promise<void> {
    if (!this.match || this.match.phase === "finished" || this.match.phase === "cancelled") return this.state.storage.deleteAlarm();
    const disconnectDeadline = this.match.players.filter((player) => player.disconnectedAt).map((player) => player.disconnectedAt! + DISCONNECT_GRACE_MS);
    const deadline = this.match.phase === "placing" ? this.match.placementDeadline : Math.min(...disconnectDeadline);
    if (Number.isFinite(deadline)) await this.state.storage.setAlarm(deadline);
    else await this.state.storage.deleteAlarm();
  }
  private async onClose(socket: WebSocket): Promise<void> {
    const player = this.playerForSocket(socket); this.sockets.delete(socket);
    if (!player || !this.match || this.match.phase === "finished" || this.match.phase === "cancelled") return;
    if ([...this.sockets.values()].includes(player.playerId)) return;
    player.connected = false;
    if (this.match.phase === "placing") await this.cancelMatch("left_during_placement");
    else { player.disconnectedAt = Date.now(); await this.persist(); await this.scheduleAlarm(); this.broadcastState(); }
  }
  private async cancelMatch(reason: string): Promise<void> { if (!this.match) return; this.match.phase = "cancelled"; this.match.finishReason = reason; await this.persist(); await this.scheduleAlarm(); this.broadcast({ type: "matchCancelled", reason }); this.broadcastState(); await this.dispatchResult(); }
  private async finishMatch(winnerId: string, reason: string): Promise<void> {
    if (!this.match) return; this.match.phase = "finished"; this.match.winnerId = winnerId; this.match.finishReason = reason; this.match.completed = true; await this.persist(); await this.scheduleAlarm(); this.broadcastState(); await this.dispatchResult();
  }
  private async dispatchResult(): Promise<void> {
    if (!this.match) return;
    const status = this.match.phase === "finished" ? "finished" : "cancelled";
    const winnerId = this.match.winnerId ?? null;
    const loserId = status === "finished" && winnerId ? this.match.players.find((player) => player.playerId !== winnerId)?.playerId ?? null : null;
    const replay = JSON.stringify({ matchId: this.match.matchId, tier: this.match.tier, boards: this.match.players.map(({ playerId, ships }) => ({ playerId, ships })), moves: this.match.moves });
    const body = JSON.stringify({ matchId: this.match.matchId, partnerId: this.env.PARTNER_ID, status, winnerId, loserId, playerIds: this.match.players.map((player) => player.playerId), reason: this.match.finishReason, tier: this.match.tier, amount: this.match.amount, wagerContextIds: this.match.players.map((player) => player.wagerContextId), replayHash: await sha256(replay), completedAt: new Date().toISOString() });
    const signature = await signBody(body, this.env.INTEGRATION_SECRET);
    const webhookUrl = this.env.WEBHOOK_URL || 'http://www.quacachua.shop/api/battleship/match-result';
    console.log('[Battleship] dispatchResult WEBHOOK_URL:', webhookUrl, 'status:', status, 'winner:', winnerId);
    try {
      const resp = await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "User-Agent": "Mozilla/5.0 (compatible; Cloudflare-Worker)",
          "X-Battleship-Signature": signature,
          "X-Forwarded-Proto": "https",
          "X-Worker-Webhook": "true",
        },
        body,
      });
      console.log('[Battleship] dispatchResult response:', resp.status, await resp.text());
    } catch (e) {
      console.error('[Battleship] dispatchResult fetch error:', String(e));
    }
  }
}

function shipCells(ship: Ship): string[] { return Array.from({ length: ship.length }, (_, index) => `${ship.x + (ship.orientation === "H" ? index : 0)},${ship.y + (ship.orientation === "V" ? index : 0)}`); }
function validShips(ships: Ship[], size: number): boolean {
  const expected = fleetSets[size as 10 | 20];
  if (!expected || ships.length !== expected.length || ships.map((ship) => ship.length).sort((a, b) => a - b).join(",") !== expected.slice().sort((a, b) => a - b).join(",")) return false;
  const shipCellArrays = ships.map((ship) => ship.orientation !== "H" && ship.orientation !== "V" || ship.x < 0 || ship.y < 0 || ship.x + (ship.orientation === "H" ? ship.length : 1) > size || ship.y + (ship.orientation === "V" ? ship.length : 1) > size ? [] : shipCells(ship));
  const totalCells = expected.reduce((sum, length) => sum + length, 0);
  const allCells = shipCellArrays.flat();
  return allCells.length === totalCells && new Set(allCells).size === allCells.length;
}
function randomShips(size: number): Ship[] {
  const expected = fleetSets[size as 10 | 20];
  const ships: Ship[] = [];
  function place(index: number): boolean {
    if (index === expected.length) return true;
    const length = expected[index];
    const positions: [number, number][] = [];
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) positions.push([x, y]);
    const orientations: Ship["orientation"][] = Math.random() < 0.5 ? ["H", "V"] : ["V", "H"];
    for (const [x, y] of shuffle(positions)) {
      for (const orientation of orientations) {
        const ship: Ship = { id: `auto-${index}`, length: length as Ship["length"], orientation, x, y };
        if (canPlace(ship, ships, size)) {
          ships.push(ship);
          if (place(index + 1)) return true;
          ships.pop();
        }
      }
    }
    return false;
  }
  if (place(0)) return ships;
  throw new Error(`Failed to generate random fleet for ${size}x${size}`);
}
function canPlace(ship: Ship, existing: Ship[], size: number): boolean {
  if (ship.x < 0 || ship.y < 0 || ship.x + (ship.orientation === "H" ? ship.length : 1) > size || ship.y + (ship.orientation === "V" ? ship.length : 1) > size) return false;
  const cells = shipCells(ship);
  const existingCells = new Set(existing.flatMap(shipCells));
  for (const cell of cells) if (existingCells.has(cell)) return false;
  const newSet = new Set(cells);
  for (const cell of existingCells) {
    const [x, y] = cell.split(",").map(Number);
    for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) if (newSet.has(`${x + dx},${y + dy}`)) return false;
  }
  return true;
}
function areaOffsets(weapon: Weapon, _size: number): [number, number][] {
  if (weapon === "single") return [[0, 0]];
  if (weapon === "cross") return [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]];
  if (weapon === "diamond") return [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1], [2, 0], [-2, 0], [0, 2], [0, -2], [1, 1], [1, -1], [-1, 1], [-1, -1]];
  return [[0, 0]];
}
function allCells(size: number): string[] { return Array.from({ length: size * size }, (_, index) => `${index % size},${Math.floor(index / size)}`); }
function shuffle<T>(array: T[]): T[] { const copy = [...array]; for (let i = copy.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [copy[i], copy[j]] = [copy[j], copy[i]]; } return copy; }
function point(cell: string): { x: number; y: number } { const [x, y] = cell.split(",").map(Number); return { x, y }; }
async function sha256(value: string): Promise<string> { const hash = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)); return Array.from(new Uint8Array(hash), (byte) => byte.toString(16).padStart(2, "0")).join(""); }
