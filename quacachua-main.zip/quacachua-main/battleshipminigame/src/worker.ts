import { QueueRoom } from "./queue-room";
import { MatchRoom } from "./match-room";
import type { Env } from "./types";
import { STYLES_CSS, GAME_JS, INDEX_HTML } from "./embedded-assets";

export { QueueRoom, MatchRoom };

const SECURITY_HEADERS = {
  "Cross-Origin-Embedder-Policy": "unsafe-none",
  "Cross-Origin-Opener-Policy": "same-origin-allow-popups",
};

function serve(body: string, contentType: string, extraHeaders?: Record<string, string>): Response {
  const headers = new Headers({
    "Content-Type": contentType,
    "Cache-Control": "public, max-age=31536000, immutable",
    ...SECURITY_HEADERS,
    ...extraHeaders,
  });
  return new Response(body, { headers });
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const origin = request.headers.get("Origin") || "";
    const allowedOrigins = [env.PARTNER_ORIGIN, "http://localhost:3000", "http://127.0.0.1:3000"].filter(Boolean);
    const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0] || "*";
    const cors = {
      "Access-Control-Allow-Origin": corsOrigin,
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Vary": "Origin",
      ...SECURITY_HEADERS,
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });

    const queue = url.pathname.match(/^\/ws\/queue\/([^/]+)\/(\d+)$/);
    if (queue && request.headers.get("Upgrade")?.toLowerCase() === "websocket") {
      const [, tier, amount] = queue;
      const id = env.QUEUE_ROOM.idFromName(`${env.PARTNER_ID}:battleship:v2:${tier}:${amount}`);
      return env.QUEUE_ROOM.get(id).fetch(request);
    }

    const match = url.pathname.match(/^\/ws\/match\/([^/]+)$/);
    if (match && request.headers.get("Upgrade")?.toLowerCase() === "websocket") {
      const id = env.MATCH_ROOM.idFromName(match[1]);
      return env.MATCH_ROOM.get(id).fetch(request);
    }

    if (url.pathname === "/health") {
      return Response.json({ status: "ok", game: "battleship", version: 1 }, { headers: cors });
    }

    if (url.pathname === "/styles.css") {
      return serve(STYLES_CSS, "text/css;charset=utf-8");
    }

    if (url.pathname === "/game.js" || url.pathname.startsWith("/game.js?v=")) {
      return serve(GAME_JS, "application/javascript;charset=utf-8", {"Cache-Control": "no-cache, no-store, must-revalidate"});
    }

    if (url.pathname === "/game" || url.pathname === "/") {
      const initParam = url.searchParams.get("init");
      let initScript = "";
      if (initParam) {
        try { const decoded = JSON.parse(atob(initParam)); initScript = `<script>window.__INIT__=${JSON.stringify(decoded)}</script>`; } catch {}
      }
      const html = INDEX_HTML.replace("</head>", initScript + "</head>");
      const headers = new Headers({
        "Content-Type": "text/html;charset=utf-8",
        "Cache-Control": "no-cache, no-store, must-revalidate",
        ...SECURITY_HEADERS,
      });
      if (corsOrigin) headers.set("Access-Control-Allow-Origin", corsOrigin);
      return new Response(html, { headers });
    }

    return new Response("Not found", { status: 404 });
  },
};
