export const STYLES_CSS = `@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

:root {
  --qc-primary: #2997ff;
  --qc-primary-focus: #0071e3;
  --qc-canvas: #121212;
  --qc-parchment: #18181b;
  --qc-pearl: #27272a;
  --qc-tile-1: #18181b;
  --qc-tile-2: #27272a;
  --qc-tile-3: #3f3f46;
  --qc-ink: #e4e4e7;
  --qc-ink-muted-80: #a1a1aa;
  --qc-ink-muted-48: #71717a;
  --qc-body-muted: #a1a1aa;
  --qc-hairline: #27272a;
  --qc-divider-soft: rgba(255,255,255,0.05);
  --qc-shadow-product: rgba(0,0,0,0.45) 3px 5px 30px 0px;

  --font: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
  --sea: #0d1b26;
  --sea-deep: #0a1520;
  --cell-water: #111d29;
  --cell-water-hit: #162536;
  --ship-hull: #a0522d;
  --ship-hull-dark: #5c2e1a;
  --ship-inner: #3d1f12;
  --ship-border: #2a1209;
  --hit: #d84a3c;
  --hit-glow: #ff7b00;
  --miss: #4a7a94;
}

* { box-sizing: border-box; margin: 0; padding: 0; }

body {
  font-family: var(--font);
  background: var(--qc-canvas);
  color: var(--qc-ink);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  min-height: 100vh;
}

.game-shell { max-width: 1240px; margin: auto; padding: 12px 16px 16px; }

.game-header {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  background: var(--qc-tile-1);
  border: 1px solid var(--qc-hairline);
  border-radius: 14px;
  padding: 12px 18px;
  margin-bottom: 12px;
}
.brand .eyebrow {
  color: var(--qc-primary);
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}
.brand h1 { font-size: 22px; font-weight: 600; letter-spacing: -0.28px; margin-top: 2px; color: var(--qc-ink); }
.status-panel { display: flex; align-items: center; gap: 12px; }
.status-text { color: var(--qc-body-muted); font-size: 14px; font-weight: 500; }
.clock { color: var(--qc-primary); font-size: 20px; font-weight: 600; font-variant-numeric: tabular-nums; min-width: 60px; text-align: right; }

.hidden { display: none !important; }

.panel {
  background: var(--qc-tile-1);
  border: 1px solid var(--qc-hairline);
  border-radius: 14px;
  padding: 12px 16px;
  margin-bottom: 12px;
}
.setup-head { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 8px; }
.setup-head h2 { font-size: 16px; font-weight: 600; letter-spacing: -0.224px; margin: 0; }
.setup-head p { color: var(--qc-ink-muted-48); font-size: 13px; margin: 0; }
.fleet-dock, .setup-controls, .weapons { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 8px; }

button {
  font-family: var(--font);
  border: none;
  border-radius: 9999px;
  padding: 8px 14px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: transform 0.15s ease, background 0.15s ease, box-shadow 0.15s ease;
}
button:active { transform: scale(0.96); }

.primary {
  background: var(--qc-primary);
  color: #000;
}
.primary:hover { background: #5eb1ff; }

.ship-card {
  display: flex;
  align-items: center;
  gap: 8px;
  text-align: left;
  background: var(--qc-pearl);
  border: 1px solid var(--qc-hairline);
  border-radius: 9px;
  padding: 6px 10px;
  color: var(--qc-ink);
}
.ship-card.placed { opacity: 0.45; cursor: not-allowed; pointer-events: none; }
.ship-card .ship-art { display: flex; align-items: center; gap: 1px; }
.ship-card .ship-art i { display: block; width: 10px; height: 10px; background: var(--ship-hull); border-radius: 2px; }
.ship-card .ship-art i:first-child { border-radius: 5px 2px 2px 5px; }
.ship-card .ship-art i:last-child { clip-path: polygon(0 0, 100% 50%, 0 100%); }
.ship-card span { font-weight: 600; font-size: 12px; }
.ship-card small { display: block; color: var(--qc-ink-muted-48); font-weight: 400; font-size: 11px; }

.game { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
.board-section { min-width: 0; }
.section-title { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; }
.section-title span { font-size: 15px; font-weight: 600; letter-spacing: -0.224px; color: var(--qc-ink); }
.badge {
  font-size: 11px;
  font-weight: 600;
  padding: 3px 8px;
  border-radius: 9999px;
  background: var(--qc-pearl);
  color: var(--qc-ink-muted-80);
  border: 1px solid var(--qc-hairline);
}
.turn { min-height: 20px; color: var(--qc-primary); font-weight: 600; font-size: 13px; margin: 0 0 6px; }
.weapons { margin-bottom: 8px; }
.weapons button {
  padding: 6px 10px;
  font-size: 12px;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 5px;
  background: var(--qc-pearl);
  color: var(--qc-ink-muted-80);
  border: 1px solid var(--qc-hairline);
  border-radius: 9999px;
}
.weapons button.active { border-color: var(--qc-primary); color: var(--qc-primary); background: rgba(41,151,255,0.12); }
.weapons button:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }
.weapons button .icon { font-size: 13px; }

.board-wrap { padding: 4px; border: 1px solid var(--qc-hairline); border-radius: 12px; background: var(--qc-tile-1); }
.board {
  --size: 10;
  --cell: 38px;
  --gap: 3px;
  display: grid;
  grid-template-columns: repeat(var(--size), var(--cell));
  grid-template-rows: repeat(var(--size), var(--cell));
  gap: var(--gap);
  padding: var(--gap);
  position: relative;
  margin: 28px 0 0 28px;
  background: var(--sea);
  border-radius: 10px;
}
.board .coord-label { position: absolute; color: var(--qc-ink-muted-48); font-size: 11px; font-weight: 600; display: grid; place-items: center; }
.board .coord-label.col { top: -24px; width: var(--cell); height: 20px; }
.board .coord-label.row { left: -24px; width: 20px; height: var(--cell); }
.overlay-layer { position: absolute; inset: 0; pointer-events: none; z-index: 5; }

.cell {
  position: relative;
  border: 1px solid rgba(255,255,255,0.04);
  background: var(--cell-water);
  min-width: 0;
  border-radius: 4px;
  overflow: hidden;
}
.cell.enemy { cursor: crosshair; }
.cell.enemy:hover { background: var(--sea-deep); }
.cell.ship-hit { background: rgba(216,74,60,0.35); }
.cell.hit { background: var(--cell-water-hit); }
.cell.hit::after { content: ""; position: absolute; z-index: 2; inset: 0; background: radial-gradient(circle, rgba(216,74,60,0.25) 0%, transparent 70%); }
.cell.miss { background: var(--sea-deep); }
.cell.mystery { background: rgba(41,151,255,0.15); border-color: var(--qc-primary); animation: mystery-pulse 1.5s ease-in-out infinite; }
.mystery-marker { color: var(--qc-primary); font-weight: 800; font-size: 1.3rem; text-shadow: 0 0 8px rgba(41,151,255,0.5); }
@keyframes mystery-pulse { 0%, 100% { background: rgba(41,151,255,0.10); } 50% { background: rgba(41,151,255,0.25); } }
.cell .marker { position: absolute; z-index: 3; inset: 0; display: grid; place-items: center; pointer-events: none; font-size: 1.1rem; }
.cell .marker.hit { color: var(--hit-glow); font-weight: 700; text-shadow: 0 0 8px rgba(255,123,0,0.6); }
.cell .marker.miss { color: var(--qc-ink-muted-48); }
.cell.drop-target { outline: 2px solid var(--qc-primary); background: var(--sea-deep); }

.ship-overlay {
  position: absolute;
  z-index: 5;
  pointer-events: none;
  background:
    linear-gradient(90deg, transparent 48%, rgba(0,0,0,0.3) 48%, rgba(0,0,0,0.3) 52%, transparent 52%),
    linear-gradient(180deg, #b86a3a 0%, #8b4522 45%, #6b3418 100%);
  background-size: 12px 100%, 100% 100%;
  box-shadow: inset 0 0 0 2px var(--ship-border), 0 1px 4px rgba(0,0,0,0.3);
}
.ship-overlay.h {
  height: var(--cell);
  clip-path: polygon(
    6px 0,
    calc(100% - 0.42 * var(--cell)) 0,
    100% 50%,
    calc(100% - 0.42 * var(--cell)) 100%,
    6px 100%,
    0 50%
  );
}
.ship-overlay.v {
  width: var(--cell);
  clip-path: polygon(
    0 6px,
    100% 6px,
    100% calc(100% - 0.42 * var(--cell)),
    50% 100%,
    0 calc(100% - 0.42 * var(--cell))
  );
}
.ship-overlay::before {
  content: "";
  position: absolute;
  inset: 25%;
  background: rgba(42,18,9,0.7);
  border-radius: 2px;
}
.ship-overlay::after {
  content: "";
  position: absolute;
  inset: 0;
  background-image: radial-gradient(circle, #1a0d07 30%, transparent 35%);
  background-size: 14px 100%;
  background-position: 50% 50%;
  background-repeat: repeat-x;
  opacity: 0.5;
}
.ship-overlay.sunk {
  filter: grayscale(0.9) brightness(0.45) contrast(1.2);
  transform: rotate(1.5deg);
}

.ship-damaged {
  position: absolute;
  z-index: 6;
  width: var(--cell);
  height: var(--cell);
  pointer-events: none;
  background:
    radial-gradient(circle at 25% 30%, rgba(255,160,60,0.5) 0%, transparent 25%),
    radial-gradient(circle at 70% 60%, rgba(255,90,30,0.4) 0%, transparent 30%),
    linear-gradient(145deg, #8b4522 0%, #5c2e1a 50%, #3d1f12 100%);
  border-radius: 5px;
  box-shadow: inset 0 0 10px rgba(0,0,0,0.6), 0 0 8px rgba(216,74,60,0.5);
}
.ship-damaged::before {
  content: "";
  position: absolute;
  inset: 15%;
  background: repeating-linear-gradient(135deg, transparent 0 4px, rgba(0,0,0,0.3) 4px 5px, transparent 5px 10px);
  opacity: 0.8;
}
.ship-damaged::after {
  content: "\\00d7";
  position: absolute;
  z-index: 2;
  inset: 0;
  display: grid;
  place-items: center;
  color: rgba(0,0,0,0.55);
  font-size: 1.4rem;
  font-weight: 700;
}

.events {
  margin-top: 10px;
  min-height: 24px;
  padding: 8px 12px;
  border-radius: 9px;
  background: var(--qc-tile-1);
  border: 1px solid var(--qc-hairline);
  color: var(--qc-ink-muted-80);
  font-weight: 500;
  font-size: 13px;
}

.fx { position: absolute; z-index: 10; pointer-events: none; }
.fx.explosion { width: var(--cell); height: var(--cell); }
.fx.explosion::before { content: ""; position: absolute; inset: 8%; border-radius: 50%; background: radial-gradient(circle, #fff 0%, #ffcc00 25%, #ff4400 55%, transparent 70%); animation: explode 0.7s ease-out forwards; }
.fx.explosion::after { content: ""; position: absolute; inset: 0; background: radial-gradient(circle, transparent 40%, rgba(255,100,0,0.4) 50%, transparent 60%); animation: ring 0.7s ease-out forwards; }
.fx.splash { width: var(--cell); height: var(--cell); }
.fx.splash::before { content: ""; position: absolute; inset: 15%; border-radius: 50%; border: 3px solid var(--miss); animation: ripple 0.8s ease-out forwards; }

@keyframes explode { 0% { transform: scale(0); opacity: 1; } 40% { transform: scale(1.4); opacity: 1; } 100% { transform: scale(1.8); opacity: 0; } }
@keyframes ring { 0% { transform: scale(0.5); opacity: 0.8; } 100% { transform: scale(2.2); opacity: 0; } }
@keyframes ripple { 0% { transform: scale(0); opacity: 1; } 100% { transform: scale(2); opacity: 0; } }

@media (max-width: 900px) { .game { grid-template-columns: 1fr; } .game-header { flex-direction: column; align-items: flex-start; } }
@media (max-width: 520px) { .ship-card { min-width: 100px; } .brand h1 { font-size: 18px; } }
`;

export const GAME_JS = `const status = document.querySelector("#status"), setup = document.querySelector("#setup"), game = document.querySelector("#game"), ownBoard = document.querySelector("#own-board"), enemyBoard = document.querySelector("#enemy-board"), turn = document.querySelector("#turn"), events = document.querySelector("#events"), weapons = document.querySelector("#weapons"), clock = document.querySelector("#placement-clock"), fleetDock = document.querySelector("#fleet-dock"), ownBadge = document.querySelector("#own-badge"), enemyBadge = document.querySelector("#enemy-badge");
let token, playerId, socket, state, activeMatchId, reconnectTimer, placement = [], selectedShipId = null, selectedLength = 5, timer, initialized = false;
let cellCache = { own: null, enemy: null };

const fleetNames = { 2: "Patrol", 3: "Submarine", 4: "Destroyer", 5: "Battleship", 6: "Carrier", 7: "Titan" };
const weaponMeta = {
  single: { label: "Single", icon: "\\ud83d\\udd2b" },
  cross: { label: "Cross", icon: "\\u271a" },
  diamond: { label: "Diamond", icon: "\\u25c6" },
  bomber: { label: "Bomber", icon: "\\ud83d\\udca3" },
};

const initData = window.__INIT__;
if (initData && initData.token && !initialized) { initialized = true; token = initData.token; if (initData.reconnectMatchId) { connectMatch(initData.reconnectMatchId); } else { connectQueue(initData.betTier, initData.amount); } }
if (!initialized) { window.parent.postMessage({ type: "battleship:ready" }, "*"); window.addEventListener("message", event => { if (event.data?.type === "battleship:init" && !initialized && event.origin && event.origin !== "null") { initialized = true; token = event.data.token; if (event.data.reconnectMatchId) { connectMatch(event.data.reconnectMatchId); } else { connectQueue(event.data.betTier, event.data.amount); } } }); }

document.querySelector("#ready").addEventListener("click", () => { const expected = fleetConfig(state?.boardSize || 10); if (placement.length !== expected.length) return note(\`Deploy all \${expected.length} ships before locking your fleet.\`); socket.send(JSON.stringify({ type: "placeShips", ships: placement })); status.textContent = "Fleet locked. Waiting for your opponent..."; });
document.querySelector("#random-fleet").addEventListener("click", () => { if (!state || state.phase !== "placing") return; const cfg = fleetConfig(state.boardSize); const ships = randomFleet(state.boardSize, cfg); if (ships) { placement = ships; renderBoard(ownBoard, placement, [], [], false, true, false); updateDock(); selectedShipId = null; note("Random fleet deployed. You can still drag ships to adjust."); } });

function buildDock(config) {
  fleetDock.replaceChildren();
  for (const entry of config) {
    const card = document.createElement("button");
    card.className = "ship-card"; card.draggable = true; card.dataset.id = entry.id; card.dataset.length = String(entry.length);
    const art = document.createElement("span"); art.className = "ship-art";
    for (let i = 0; i < entry.length; i++) art.append(document.createElement("i"));
    const meta = document.createElement("span"); meta.innerHTML = \`\${fleetNames[entry.length] || "Ship"} <small>\${entry.length} cells</small>\`;
    card.append(art, meta);
    card.addEventListener("dragstart", event => { selectedShipId = entry.id; selectedLength = entry.length; event.dataTransfer.setData("text/plain", entry.id); });
    card.addEventListener("click", () => { selectedShipId = entry.id; selectedLength = entry.length; note(\`Selected \${entry.length}-cell \${fleetNames[entry.length] || "ship"}. Click an empty cell or drag it.\`); });
    fleetDock.append(card);
  }
  const next = config.find(entry => !placement.some(ship => ship.id === entry.id));
  if (next) { selectedShipId = next.id; selectedLength = next.length; }
}

function connectQueue(tier, amount) {
  status.textContent = "Joining matchmaking fleet class...";
  const s = new WebSocket(ws(\`/ws/queue/\${encodeURIComponent(tier)}/\${encodeURIComponent(amount)}\`));
  socket = s;
  s.addEventListener("open", () => { if (socket === s) s.send(JSON.stringify({ type: "join", token })); });
  s.addEventListener("message", event => {
    const message = JSON.parse(event.data);
    if (message.type === "queueWaiting") status.textContent = \`Searching in the \${message.betTier} fleet class...\`;
    if (message.type === "matchFound") connectMatch(message.matchId);
    if (message.type === "error") note(\`Queue error: \${message.code}\`);
  });
  s.addEventListener("close", () => { if (!state && socket === s) status.textContent = "Queue connection closed."; });
}
function connectMatch(matchId) {
  activeMatchId = matchId; clearTimeout(reconnectTimer); clearInterval(timer); clock.textContent = "";
  cellCache = { own: null, enemy: null };
  status.textContent = "Opponent found. Connecting to match...";
  const s = new WebSocket(ws(\`/ws/match/\${matchId}\`));
  socket = s;
  s.addEventListener("open", () => { if (socket === s) s.send(JSON.stringify({ type: "auth", token })); });
  s.addEventListener("message", event => { if (socket === s) handle(JSON.parse(event.data)); });
  s.addEventListener("close", () => { if (socket === s && (!state || !["finished", "cancelled"].includes(state.phase))) { note("Connection lost. Reconnecting for up to 60 seconds before forfeit."); reconnectTimer = setTimeout(() => connectMatch(activeMatchId), 2500); } });
}
function ws(path) { return \`\${location.protocol === "https:" ? "wss" : "ws"}://\${location.host}\${path}\`; }
function handle(message) {
  if (message.type === "error") return note(\`Game error: \${message.code}\`);
  if (message.type === "matchCancelled") { status.textContent = "Match cancelled"; window.parent.postMessage({ type: "battleship:ended" }, "*"); return note(\`Match cancelled: \${message.reason}. No settlement was made.\`); }
  if (message.type === "shotResult") {
    const hits = message.impacts.filter(i => i.result === "hit").length;
    const bonus = message.bonus ? " \\u2014 Bonus single shot!" : "";
    const mystery = message.mysteryAward ? \` \\u2014 Mystery: +1 \${weaponMeta[message.mysteryAward].label}!\` : "";
    note(\`\${weaponMeta[message.weapon].label} strike: \${hits} hit\${hits === 1 ? "" : "s"}\${message.sunkLengths?.length ? \` \\u2014 Sunk \${message.sunkLengths.join(",")}-cell ship!\` : ""}\${bonus}\${mystery}.\`);
    const board = state?.you?.seat === message.actorSeat ? enemyBoard : ownBoard;
    for (const impact of message.impacts) spawnFx(board, impact.x, impact.y, impact.result);
    if (message.mysteryAward && state) { state.mysteryCell = null; }
  }
  if (message.type === "matchState") { const prevPhase = state?.phase; state = message.state; render(); if (state.matchId) { window.parent.postMessage({ type: "battleship:matchState", matchId: state.matchId }, "*"); if ((state.phase === "finished" || state.phase === "cancelled") && prevPhase !== "finished" && prevPhase !== "cancelled") { window.parent.postMessage({ type: "battleship:ended" }, "*"); } } }
}

function render() {
  const placing = state.phase === "placing";
  setup.classList.toggle("hidden", !placing || state.tier === "little");
  game.classList.remove("hidden");
  const config = fleetConfig(state.boardSize);
  if (placing && state.tier !== "little" && fleetDock.children.length !== config.length) buildDock(config);
  ownBoard.style.setProperty("--size", state.boardSize); enemyBoard.style.setProperty("--size", state.boardSize);
  fitBoard(ownBoard); fitBoard(enemyBoard);
  const myTurn = state.phase === "playing" && state.turn === state.you.seat;
  const bonusActive = myTurn && state.lastHitShipId;
  ownBadge.textContent = \`\${state.you.ships.length}/\${config.length} ships\`;
  enemyBadge.textContent = \`\${state.opponent.shots.length} shots\`;
  const mysteryActive = state.mysteryCell;
  if (placing) {
    turn.textContent = state.tier === "little" ? "Fleet auto-deployed. Waiting for opponent..." : "Deploy your fleet before the timer runs out.";
    setTimer(state.placementDeadline);
  } else if (state.phase === "finished") {
    turn.textContent = state.winnerId === state.you.playerId ? \`\\ud83c\\udfc6 Victory! \${state.finishReason}\` : \`\\ud83d\\udc80 Defeat: \${state.finishReason}\`;
    setTimer(0);
  } else {
    turn.textContent = bonusActive ? "\\ud83d\\udd25 Bonus single shot! Keep hitting the same ship." : myTurn ? (mysteryActive ? "\\u2753 A mystery cell appeared! Click it for a bonus weapon." : "Your turn. Pick a weapon and fire!") : \`\${state.opponent.displayName}\${state.opponent.connected ? " is plotting..." : " disconnected \\u2014 60s grace"}\`;
    setTimer(0);
  }
  const finished = state.phase === "finished";
  renderBoard(ownBoard, state.you.ships, state.you.incomingShots, state.you.incomingHitShots, false, true, false, null, "own");
  renderBoard(enemyBoard, state.opponent.ships, state.opponent.shots, state.opponent.hitShots, myTurn, true, !finished, mysteryActive ? state.mysteryCell : null, "enemy");
  renderWeapons(myTurn);
  updateDock();
}

function setTimer(deadline) {
  clearInterval(timer);
  if (!deadline) { clock.textContent = ""; return; }
  const update = () => { const seconds = Math.max(0, Math.ceil((deadline - Date.now()) / 1000)); clock.textContent = \`\${String(Math.floor(seconds / 60)).padStart(2, "0")}:\${String(seconds % 60).padStart(2, "0")}\`; };
  update(); timer = setInterval(update, 500);
}

function ensureBoardStructure(container, size, which) {
  if (cellCache[which] && cellCache[which].size === size) return cellCache[which];
  container.replaceChildren();
  const cellMap = new Map();
  for (let x = 0; x < size; x++) { const label = document.createElement("div"); label.className = "coord-label col"; label.textContent = String.fromCharCode(65 + x); label.style.left = \`calc(var(--gap) + \${x} * (var(--cell) + var(--gap)))\`; container.append(label); }
  for (let y = 0; y < size; y++) { const label = document.createElement("div"); label.className = "coord-label row"; label.textContent = String(y + 1); label.style.top = \`calc(var(--gap) + \${y} * (var(--cell) + var(--gap)))\`; container.append(label); }
  const overlayLayer = document.createElement("div"); overlayLayer.className = "overlay-layer"; container.append(overlayLayer);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const key = \`\${x},\${y}\`, cell = document.createElement("button");
    cell.className = "cell"; cell.dataset.key = key; cell.dataset.x = String(x); cell.dataset.y = String(y);
    cell.title = \`\${String.fromCharCode(65 + x)}\${y + 1}\`;
    cellMap.set(key, cell); container.append(cell);
  }
  container.addEventListener("click", (e) => {
    const cell = e.target.closest("button.cell");
    if (!cell || !cell.dataset.key) return;
    const cx = Number(cell.dataset.x), cy = Number(cell.dataset.y);
    const key = cell.dataset.key;
    if (cell.classList.contains("drop-target")) cell.classList.remove("drop-target");
    if (which === "own" && state?.phase === "placing" && state.tier !== "little") {
      const placedShip = placement.find(s => cells(s).includes(key));
      if (placedShip) { pickupShip(placedShip.id); return; }
      if (selectedShipId) dropShip(cx, cy, selectedShipId, selectedLength);
      return;
    }
    if (which === "enemy" && state?.phase === "playing" && state.turn === state.you.seat) {
      if (cell.classList.contains("miss") || cell.classList.contains("hit") || cell.classList.contains("ship-hit")) return;
      const mysteryKey = state.mysteryCell ? \`\${state.mysteryCell.x},\${state.mysteryCell.y}\` : null;
      if (key === mysteryKey) { const prev = selectedWeapon; selectedWeapon = "single"; fire(cx, cy); selectedWeapon = prev; }
      else fire(cx, cy);
    }
  });
  container.addEventListener("dragover", (e) => {
    if (which !== "own" || state?.phase !== "placing") return;
    const cell = e.target.closest("button.cell"); if (!cell) return;
    const placedShip = placement.find(s => cells(s).includes(cell.dataset.key));
    if (placedShip) return;
    e.preventDefault(); cell.classList.add("drop-target");
  });
  container.addEventListener("dragleave", (e) => {
    const cell = e.target.closest("button.cell"); if (cell) cell.classList.remove("drop-target");
  });
  container.addEventListener("drop", (e) => {
    if (which !== "own" || state?.phase !== "placing") return;
    const cell = e.target.closest("button.cell"); if (!cell) return;
    e.preventDefault(); cell.classList.remove("drop-target");
    const cx = Number(cell.dataset.x), cy = Number(cell.dataset.y);
    const data = e.dataTransfer.getData("text/plain");
    dropShip(cx, cy, data || selectedShipId, selectedLength);
  });
  container.addEventListener("dragstart", (e) => {
    if (which !== "own" || state?.phase !== "placing") return;
    const cell = e.target.closest("button.cell"); if (!cell) return;
    const placedShip = placement.find(s => cells(s).includes(cell.dataset.key));
    if (placedShip) { selectedShipId = placedShip.id; selectedLength = placedShip.length; e.dataTransfer.setData("text/plain", placedShip.id); }
  });
  const cache = { size, cellMap, overlayLayer };
  cellCache[which] = cache;
  return cache;
}

function renderBoard(container, ships, shots, hitShots, clickable, showShips, onlySunk = false, mystery = null, which = "own") {
  const size = state.boardSize;
  const cache = ensureBoardStructure(container, size, which);
  const { cellMap, overlayLayer } = cache;
  const visibleShips = showShips ? (onlySunk ? ships.filter(ship => shipCells(ship).every(cell => shots.includes(cell))) : ships) : [];
  const shipSet = new Set(visibleShips.flatMap(cells));
  const shotSet = new Set(shots);
  const hitSet = new Set(hitShots);
  const mysteryKey = mystery ? \`\${mystery.x},\${mystery.y}\` : null;
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const key = \`\${x},\${y}\`, cell = cellMap.get(key);
    if (!cell) continue;
    let cls = "cell";
    if (clickable) cls += " enemy";
    if (shipSet.has(key) && shotSet.has(key)) cls += " ship-hit";
    else if (hitSet.has(key)) cls += " hit";
    else if (shotSet.has(key)) cls += " miss";
    if (key === mysteryKey) cls += " mystery";
    if (cell.className !== cls) cell.className = cls;
    const hasMarker = cell.firstChild !== null;
    const needMarker = (shotSet.has(key) || hitSet.has(key)) || key === mysteryKey;
    if (hasMarker !== needMarker) {
      cell.replaceChildren();
      if (key === mysteryKey) { const m = document.createElement("span"); m.className = "marker mystery-marker"; m.textContent = "?"; cell.append(m); }
      if (shotSet.has(key) || hitSet.has(key)) { const marker = document.createElement("span"); marker.className = \`marker \${shipSet.has(key) || hitSet.has(key) ? "hit" : "miss"}\`; marker.textContent = shipSet.has(key) || hitSet.has(key) ? "\\u2726" : "\\u2022"; cell.append(marker); }
    }
  }
  overlayLayer.replaceChildren();
  if (visibleShips.length) renderShipOverlays(overlayLayer, visibleShips, shots);
  if (container === ownBoard && state.phase !== "placing") renderDamagedSegments(overlayLayer, ships, shots);
}

function renderShipOverlays(layer, ships, shots) {
  const shotSet = new Set(shots);
  for (const ship of ships) {
    const overlay = document.createElement("div");
    const sunk = shipCells(ship).every(cell => shotSet.has(cell));
    overlay.className = \`ship-overlay \${ship.orientation.toLowerCase()} \${sunk ? "sunk" : ""}\`;
    if (ship.orientation === "H") {
      overlay.style.width = \`calc(\${ship.length} * var(--cell) + \${ship.length - 1} * var(--gap))\`;
      overlay.style.height = \`var(--cell)\`;
    } else {
      overlay.style.width = \`var(--cell)\`;
      overlay.style.height = \`calc(\${ship.length} * var(--cell) + \${ship.length - 1} * var(--gap))\`;
    }
    overlay.style.left = \`calc(var(--gap) + \${ship.x} * (var(--cell) + var(--gap)))\`;
    overlay.style.top = \`calc(var(--gap) + \${ship.y} * (var(--cell) + var(--gap)))\`;
    layer.append(overlay);
  }
}
function renderDamagedSegments(layer, ships, shots) {
  const shotSet = new Set(shots);
  for (const ship of ships) {
    for (const cell of shipCells(ship)) {
      if (!shotSet.has(cell)) continue;
      const [x, y] = cell.split(",").map(Number);
      const segment = document.createElement("div");
      segment.className = "ship-damaged";
      segment.style.left = \`calc(var(--gap) + \${x} * (var(--cell) + var(--gap)))\`;
      segment.style.top = \`calc(var(--gap) + \${y} * (var(--cell) + var(--gap)))\`;
      layer.append(segment);
    }
  }
}

function dropShip(x, y, shipId, length) {
  if (!shipId) return note("Select a ship from the dock first.");
  const orientation = Math.random() < 0.5 ? "H" : "V";
  const ship = { id: shipId, x, y, length, orientation };
  const proposed = cells(ship);
  if (proposed.some(key => { const [cx, cy] = key.split(",").map(Number); return cx >= state.boardSize || cy >= state.boardSize; })) return note("That ship would leave the board.");
  const otherCells = new Set(placement.filter(s => s.id !== shipId).flatMap(cells));
  if (proposed.some(key => otherCells.has(key))) return note("That ship overlaps another ship.");
  placement = placement.filter(s => s.id !== shipId);
  placement.push(ship);
  renderBoard(ownBoard, placement, [], [], false, true, false, null, "own");
  updateDock();
  const next = fleetConfig(state.boardSize).find(entry => !placement.some(p => p.id === entry.id));
  if (next) { selectedShipId = next.id; selectedLength = next.length; }
  else { selectedShipId = null; }
}
function pickupShip(shipId) {
  const ship = placement.find(s => s.id === shipId);
  if (!ship) return;
  selectedShipId = shipId;
  selectedLength = ship.length;
  note("Ship selected. Click or drag an empty cell to reposition. Orientation is random on each drop.");
}
function updateDock() {
  for (const card of document.querySelectorAll(".ship-card")) card.classList.toggle("placed", placement.some(ship => ship.id === card.dataset.id));
}
function renderWeapons(myTurn) {
  weapons.replaceChildren();
  if (!state || state.phase !== "playing") return;
  const bonusLocked = myTurn && state.lastHitShipId;
  for (const weapon of ["single", "cross", "diamond", "bomber"]) {
    const amount = state.you.weapons[weapon];
    if (weapon !== "single" && amount <= 0) continue;
    const meta = weaponMeta[weapon];
    const button = document.createElement("button");
    button.innerHTML = \`<span class="icon">\${meta.icon}</span><span>\${meta.label}\${weapon === "single" ? "" : \` x\${amount}\`}</span>\`;
    button.classList.toggle("active", weapon === selectedWeapon);
    button.disabled = !myTurn || (bonusLocked && weapon !== "single");
    button.addEventListener("click", () => { selectedWeapon = weapon; renderWeapons(myTurn); });
    weapons.append(button);
  }
  if (bonusLocked && selectedWeapon !== "single") selectedWeapon = "single";
}
let selectedWeapon = "single";
function fire(x, y) { socket.send(JSON.stringify({ type: "shoot", x, y, weapon: selectedWeapon, moveId: crypto.randomUUID() })); selectedWeapon = "single"; }
function fleetSet(size) { return size === 20 ? [7, 6, 5, 4, 3, 3, 2, 2] : [5, 4, 3, 3, 2]; }
function fleetConfig(size) {
  const lengths = fleetSet(size);
  return lengths.map((length, index) => ({ id: \`ship-\${length}-\${index}\`, length }));
}
function cells(ship) { return Array.from({ length: ship.length }, (_, i) => \`\${ship.x + (ship.orientation === "H" ? i : 0)},\${ship.y + (ship.orientation === "V" ? i : 0)}\`); }
function shipCells(ship) { return cells(ship); }
function spawnFx(container, x, y, result) {
  const fx = document.createElement("div"); fx.className = \`fx \${result === "hit" ? "explosion" : "splash"}\`;
  fx.style.left = \`calc(var(--gap) + \${x} * (var(--cell) + var(--gap)))\`;
  fx.style.top = \`calc(var(--gap) + \${y} * (var(--cell) + var(--gap)))\`;
  container.append(fx);
  setTimeout(() => fx.remove(), 800);
}
function note(message) { events.textContent = message; }
function fitBoard(board) {
  const size = Number(board.style.getPropertyValue("--size")) || 10;
  const wrap = board.parentElement;
  if (!wrap) return;
  const wrapWidth = wrap.clientWidth - 8;
  const labelMargin = 28;
  const gap = 3;
  const availableWidth = wrapWidth - labelMargin - gap * 2;
  const cellSize = Math.max(14, Math.floor((availableWidth - gap * (size - 1)) / size));
  board.style.setProperty("--cell", cellSize + "px");
}
function randomFleet(size, config) {
  for (let attempt = 0; attempt < 5000; attempt++) {
    const ships = [];
    const occupied = new Set();
    let ok = true;
    for (const entry of config) {
      let placed = false;
      for (let tries = 0; tries < 200; tries++) {
        const orientation = Math.random() < 0.5 ? "H" : "V";
        const maxX = orientation === "H" ? size - entry.length : size - 1;
        const maxY = orientation === "V" ? size - entry.length : size - 1;
        const x = Math.floor(Math.random() * (maxX + 1));
        const y = Math.floor(Math.random() * (maxY + 1));
        const ship = { id: entry.id, x, y, length: entry.length, orientation };
        const shipCells = cells(ship);
        if (shipCells.some(c => occupied.has(c))) continue;
        ships.push(ship);
        shipCells.forEach(c => occupied.add(c));
        placed = true;
        break;
      }
      if (!placed) { ok = false; break; }
    }
    if (ok) return ships;
  }
  return null;
}
window.addEventListener("resize", () => { if (state) { fitBoard(ownBoard); fitBoard(enemyBoard); } });
`;

export const INDEX_HTML = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Battleship Cam</title>
  <link rel="stylesheet" href="/styles.css">
</head>
<body>
  <main class="game-shell">
    <header class="game-header">
      <div class="brand">
        <span class="eyebrow">QUẢ CÀ CHUA</span>
        <h1>Battleship</h1>
      </div>
      <div class="status-panel">
        <span id="status" class="status-text">Waiting for the partner website...</span>
        <strong id="placement-clock" class="clock"></strong>
      </div>
    </header>

    <section id="setup" class="panel setup hidden">
      <div class="setup-head">
        <div>
          <h2>Deploy your fleet</h2>
          <p id="setup-copy">Drag a ship from the dock and drop it on your waters. Orientation is random on each drop. Drag a placed ship to move it again.</p>
        </div>
      </div>
      <div class="fleet-dock" id="fleet-dock"></div>
      <div class="setup-controls">
        <button id="random-fleet">\\ud83c\\udfb2 Random fleet</button>
        <button id="ready" class="primary">\\ud83d\\ude80 Lock fleet</button>
      </div>
    </section>

    <section id="game" class="game hidden">
      <div class="board-section">
        <div class="section-title"><span>Your waters</span><span class="badge" id="own-badge"></span></div>
        <div class="board-wrap" id="own-wrap"><div id="own-board" class="board" aria-label="Your board"></div></div>
      </div>
      <div class="board-section">
        <div class="section-title"><span>Enemy waters</span><span class="badge" id="enemy-badge"></span></div>
        <p class="turn" id="turn">Waiting for deployment</p>
        <div id="weapons" class="weapons"></div>
        <div class="board-wrap" id="enemy-wrap"><div id="enemy-board" class="board" aria-label="Opponent board"></div></div>
      </div>
    </section>

    <section id="events" class="events"></section>
  </main>
  <script type="module" src="/game.js?v=20260717"></script>
</body>
</html>`;
