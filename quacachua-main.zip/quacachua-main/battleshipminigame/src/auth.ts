import type { Env, SessionClaims } from "./types";

const encoder = new TextEncoder();

function base64UrlToBytes(value: string): Uint8Array {
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - value.length % 4) % 4);
  const binary = atob(base64);
  return Uint8Array.from(binary, (char) => char.charCodeAt(0));
}

function asBufferSource(bytes: Uint8Array): ArrayBuffer {
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
}

export async function verifyToken(token: string, env: Env): Promise<SessionClaims | null> {
  const [encodedPayload, encodedSignature, ...extra] = token.split(".");
  if (!encodedPayload || !encodedSignature || extra.length) return null;

  try {
    const key = await crypto.subtle.importKey(
      "raw",
      encoder.encode(env.INTEGRATION_SECRET),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["verify"]
    );
    const valid = await crypto.subtle.verify(
      "HMAC",
      key,
      asBufferSource(base64UrlToBytes(encodedSignature)),
      encoder.encode(encodedPayload)
    );
    if (!valid) return null;

    const claims = JSON.parse(new TextDecoder().decode(base64UrlToBytes(encodedPayload))) as SessionClaims;
    if (
      claims.version !== 1 ||
      claims.partnerId !== env.PARTNER_ID ||
      !claims.playerId ||
      !claims.displayName ||
      !claims.betTier ||
      typeof claims.amount !== "number" ||
      !claims.wagerContextId ||
      !claims.nonce ||
      claims.expiresAt <= Math.floor(Date.now() / 1000)
    ) return null;
    return claims;
  } catch {
    return null;
  }
}

export async function signBody(body: string, secret: string): Promise<string> {
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const signature = await crypto.subtle.sign("HMAC", key, encoder.encode(body));
  return Array.from(new Uint8Array(signature), (byte) => byte.toString(16).padStart(2, "0")).join("");
}
