import { verifyToken, signBody } from "./auth";
import type { Env, SessionClaims } from "./types";

interface QueueEntry {
  playerId: string;
  displayName: string;
  wagerContextId: string;
  betTier: string;
  amount: number;
}

export class QueueRoom {
  private connections = new Map<WebSocket, QueueEntry>();

  constructor(private state: DurableObjectState, private env: Env) {}

  async fetch(request: Request): Promise<Response> {
    if (request.headers.get("Upgrade")?.toLowerCase() !== "websocket") return new Response("WebSocket required", { status: 426 });
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    server.accept();
    server.addEventListener("message", (event) => void this.onMessage(server, String(event.data)));
    server.addEventListener("close", () => this.onClose(server));
    server.addEventListener("error", () => this.onClose(server));
    return new Response(null, { status: 101, webSocket: client });
  }

  private async onMessage(socket: WebSocket, raw: string): Promise<void> {
    let message: { type?: string; token?: string };
    try { message = JSON.parse(raw); } catch { return this.send(socket, { type: "error", code: "BAD_MESSAGE" }); }
    if (message.type === "ping") return this.send(socket, { type: "pong" });
    if (message.type !== "join" || !message.token) return this.send(socket, { type: "error", code: "AUTH_REQUIRED" });
    if (this.connections.has(socket)) return;

    const claims = await verifyToken(message.token, this.env);
    if (!claims) return this.send(socket, { type: "error", code: "INVALID_TOKEN" });

    if (!isTier(claims.betTier)) return this.send(socket, { type: "error", code: "INVALID_TIER" });

    // Reject if same player already queued on a different socket
    for (const [existingSocket, entry] of this.connections) {
      if (entry.playerId === claims.playerId) {
        // Remove the old connection — player is re-queuing
        this.connections.delete(existingSocket);
        try { existingSocket.close(1000, "Replaced"); } catch {}
      }
    }

    this.connections.set(socket, {
      playerId: claims.playerId,
      displayName: claims.displayName,
      wagerContextId: claims.wagerContextId,
      betTier: claims.betTier,
      amount: claims.amount,
    });

    console.log(`[QueueRoom] Player joined: ${claims.playerId}. Total in queue: ${this.connections.size}`);
    this.send(socket, { type: "queueWaiting", betTier: claims.betTier, position: this.connections.size });

    if (this.connections.size >= 2) await this.createMatch();
  }

  private onClose(socket: WebSocket): void {
    this.connections.delete(socket);
  }

  private async createMatch(): Promise<void> {
    const entries = [...this.connections.entries()].slice(0, 2);
    if (entries.length < 2) return;

    const matchId = crypto.randomUUID();
    const players = entries.map(([socket, entry], seat) => ({ socket, ...entry, seat }));

    // Remove both from queue immediately to prevent double-matching
    for (const [socket] of entries) this.connections.delete(socket);

    const match = this.env.MATCH_ROOM.get(this.env.MATCH_ROOM.idFromName(matchId));
    const response = await match.fetch("https://match.internal/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        matchId,
        tier: players[0].betTier,
        amount: players[0].amount,
        players: players.map((p) => ({
          playerId: p.playerId,
          displayName: p.displayName,
          seat: p.seat,
          wagerContextId: p.wagerContextId,
        })),
      }),
    });

    if (!response.ok) {
      console.error(`[QueueRoom] Match creation failed: ${await response.text()}`);
      for (const p of players) this.send(p.socket, { type: "error", code: "MATCH_CREATE_FAILED" });
      return;
    }

    console.log(`[QueueRoom] Match ${matchId} created for ${players[0].playerId} vs ${players[1].playerId}`);
    await this.dispatchStart(matchId, players);
    for (const p of players) {
      this.send(p.socket, { type: "matchFound", matchId, playerId: p.playerId });
      try { p.socket.close(1000, "Matched"); } catch {}
    }
  }

  private send(socket: WebSocket, data: unknown): void {
    try { socket.send(JSON.stringify(data)); } catch { this.connections.delete(socket); }
  }

  private async dispatchStart(matchId: string, players: Array<{ playerId: string; wagerContextId: string; amount: number; betTier: string }>): Promise<void> {
    const body = JSON.stringify({ matchId, status: "match_start", partnerId: this.env.PARTNER_ID, playerIds: players.map((p) => p.playerId), wagerContextIds: players.map((p) => p.wagerContextId), amount: players[0].amount, tier: players[0].betTier, completedAt: new Date().toISOString() });
    const signature = await signBody(body, this.env.INTEGRATION_SECRET);
    const webhookUrl = this.env.WEBHOOK_URL || 'http://www.quacachua.shop/api/battleship/match-result';
    console.log('[Battleship] dispatchStart WEBHOOK_URL:', webhookUrl, 'body length:', body.length);
    try {
      const resp = await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "User-Agent": "Mozilla/5.0 (compatible; Cloudflare-Worker)",
          "X-Battleship-Signature": signature,
          "X-Forwarded-Proto": "https",
          "X-Worker-Webhook": "true",
        },
        body,
      });
      console.log('[Battleship] dispatchStart response:', resp.status, await resp.text());
    } catch (e) {
      console.error('[Battleship] dispatchStart fetch error:', String(e));
    }
  }
}

function isTier(value: string): value is "little" | "middle" | "large" { return value === "little" || value === "middle" || value === "large"; }
