# Battleship Minigame

Standalone Cloudflare Battleship PvP prototype. It does not import, edit, or call the Quả Cà Chua application. `demo-partner/` is a local-only simulator of that future Partner Website integration.

## Run locally

Open two terminals from `battleshipminigame/`:

```powershell
npm install
npm run dev
```

```powershell
npm run demo
```

Open `http://localhost:3000` in two browser tabs. Enter different player names, select the same fleet class, and click **Find opponent** in both tabs.

- **Little:** 10×10 board. The server fairly auto-deploys 5 ships: 5, 4, 3, 3, 2. Each player has unlimited single shots and 2 small cross strikes.
- **Middle:** 10×10 board. Drag-and-drop 5 ships: 5, 4, 3, 3, 2 within 60 seconds. Each player has unlimited single shots and 2 small cross strikes. Bomber is only obtainable from mystery cells (which appear every 10 moves starting at move 6, always awarding bomber).
- **Large:** 20×20 board with the same drag-and-drop deployment for 8 ships: 7, 6, 5, 4, 3, 3, 2, 2 within 2 minutes. Each player has unlimited single shots, 3 small cross strikes, and 1 bomber by default. Mystery cells appear every 14 moves starting at move 8, awarding bomber (75% chance) or diamond (25% chance).

### Ship reveal rules

- **Your own board:** you always see your full fleet. Cells that have been hit show a detailed **damaged ship segment** instead of a plain marker.
- **Enemy board:** enemy ships stay hidden until a ship is **fully sunk**. Only the sunk ship is then revealed in full.

### UI style

The game client intentionally follows the Quả Cà Chua design language in dark mode: Inter typography, dark tile surfaces, single blue accent (#2997ff), pill primary buttons, and minimal shadows. This keeps the embedded iframe visually consistent with the parent website when Quả Cà Chua is in dark mode.

### Fleet placement

During manual placement, drag a ship from the dock and drop it onto your board. The orientation is randomly chosen each time you drop. Ships already on the board can be clicked or dragged again to reposition them, and each re-drop also gets a random orientation. This removes the need for a manual rotate control.

### Mystery cell

In **middle** and **large** modes, after a certain number of moves (6 for middle, 8 for large), a mystery cell marked with "?" appears on a random unshot cell that is not on any ship. Both players can see it. Clicking the mystery cell counts as a single-shot miss and ends the turn, but awards a random bonus area weapon (cross, diamond, or bomber) that is added to the player's toolbar. If the player ignores the mystery cell and shoots elsewhere, it remains on the board for the next turn.

### Bonus single-shot rule

A **single** shot that hits a ship earns another single shot. If the next single shot continues to hit the **same** partially-damaged ship, the chain continues until that ship is fully sunk. Hitting a different ship or missing ends the chain. If the first single shot already sinks the ship, there is no bonus shot. During a bonus chain only single shots are allowed.

Leaving during the 60-second placement phase cancels the match with no settlement. After play begins, a disconnected player has 60 seconds to reconnect; after that the opponent wins with `disconnect_timeout`, and the signed settlement callback is sent.

The Worker is on `http://localhost:8787`; game assets are served by the Worker, just as Cloudflare Workers static assets would be after deployment. The partner demo is on `http://localhost:3000` and embeds the game in an iframe. Tokens travel only by `postMessage`, not via URLs.

## Deployment boundary

- `src/worker.ts`, `QueueRoom`, and `MatchRoom` are the Cloudflare deployable application.
- `public/` is the static iframe game client served alongside the Worker.
- `demo-partner/` is not deployed with Cloudflare and is only for local integration testing.
- The actual Quả Cà Chua source is untouched. Its future backend only needs equivalent token issuance and signed `/match-result` settlement handling.

Before a production `npm run deploy`, replace `INTEGRATION_SECRET`, `PARTNER_ORIGIN`, and `WEBHOOK_URL` with Cloudflare secrets/environment configuration. Do not keep the local secret in a deployed config.
