const workerOrigin = "http://localhost:8787";
const play = document.querySelector("#play");
const wrap = document.querySelector("#game-wrap");
const frame = document.querySelector("#game");
const status = document.querySelector("#state");
let config = null;

play.addEventListener("submit", async event => {
  event.preventDefault();
  const displayName = document.querySelector("#name").value.trim();
  const betTier = document.querySelector("#bet").value;
  if (!displayName) return;
  status.textContent = "Partner backend is issuing your match token...";
  const response = await fetch("/api/battleship/token", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ displayName, betTier }) });
  const data = await response.json();
  const payload = JSON.parse(atob(data.token.split(".")[0].replace(/-/g, "+").replace(/_/g, "/")));
  config = { token: data.token, playerId: payload.playerId, betTier };
  wrap.classList.remove("hidden"); frame.src = workerOrigin;
});
frame.addEventListener("load", () => { if (config) frame.contentWindow.postMessage({ type: "battleship:init", ...config }, workerOrigin); });
window.addEventListener("message", event => { if (event.origin === workerOrigin && event.data?.type === "battleship:ready" && config) frame.contentWindow.postMessage({ type: "battleship:init", ...config }, workerOrigin); });
document.querySelector("#leave").addEventListener("click", () => { frame.src = "about:blank"; wrap.classList.add("hidden"); config = null; });
async function refreshResults() { const results = await fetch("/api/battleship/results").then(response => response.json()); document.querySelector("#results").textContent = results.length ? JSON.stringify(results, null, 2) : "No settled matches."; }
setInterval(refreshResults, 2000); refreshResults();
