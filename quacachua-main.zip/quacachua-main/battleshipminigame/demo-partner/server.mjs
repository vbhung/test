import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { extname, join } from "node:path";

const port = 3000;
const secret = "local-development-secret-change-before-deploy";
const settledMatches = new Map();
const contentTypes = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8" };

const base64url = (value) => Buffer.from(value).toString("base64url");
function issueToken({ playerId, displayName, betTier }) {
  const now = Math.floor(Date.now() / 1000);
  const payload = { version: 1, partnerId: "demo-tomato", playerId, displayName, betTier, wagerContextId: `wager-${randomUUID()}`, issuedAt: now, expiresAt: now + 300, nonce: randomUUID() };
  const encoded = base64url(JSON.stringify(payload));
  return `${encoded}.${createHmac("sha256", secret).update(encoded).digest("base64url")}`;
}
function signatureValid(body, signature) {
  const expected = createHmac("sha256", secret).update(body).digest("hex");
  return Boolean(signature) && timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
}
function json(response, body, status = 200) { response.writeHead(status, { "Content-Type": "application/json" }); response.end(JSON.stringify(body)); }

createServer(async (request, response) => {
  const url = new URL(request.url, `http://localhost:${port}`);
  if (request.method === "POST" && url.pathname === "/api/battleship/token") {
    let raw = ""; for await (const chunk of request) raw += chunk;
    const input = JSON.parse(raw || "{}");
    if (!input.displayName || !input.betTier) return json(response, { error: "Missing displayName or betTier" }, 400);
    return json(response, { token: issueToken({ playerId: `tomato-${randomUUID()}`, displayName: String(input.displayName).slice(0, 30), betTier: String(input.betTier) }) });
  }
  if (request.method === "POST" && url.pathname === "/api/battleship/match-result") {
    let body = ""; for await (const chunk of request) body += chunk;
    if (!signatureValid(body, request.headers["x-battleship-signature"])) return json(response, { error: "Invalid signature" }, 401);
    const result = JSON.parse(body);
    if (!settledMatches.has(result.matchId)) settledMatches.set(result.matchId, { ...result, receivedAt: new Date().toISOString() });
    return json(response, { received: true, idempotent: true });
  }
  if (request.method === "GET" && url.pathname === "/api/battleship/results") return json(response, [...settledMatches.values()].reverse());
  const file = url.pathname === "/" ? "index.html" : url.pathname.slice(1);
  if (file.includes("..")) return response.end("Not found");
  try { const data = await readFile(join(import.meta.dirname, "public", file)); response.writeHead(200, { "Content-Type": contentTypes[extname(file)] ?? "application/octet-stream" }); response.end(data); }
  catch { response.writeHead(404); response.end("Not found"); }
}).listen(port, () => console.log(`Tomato Partner demo: http://localhost:${port}`));
